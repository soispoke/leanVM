#!/usr/bin/env python3
"""Bounded read-only Linux process observations; never execution authority.

CPU rates require two same-boot observations of the same PID/start-tick identity.
Affinity is eligibility, not core occupancy. RSS counts shared pages repeatedly.
The view is non-atomic and cannot discover all transient or hidden processes.
"""
from __future__ import annotations

import argparse
import errno
import json
import math
import os
from pathlib import Path
import time

FLAGS = {"accepted": False, "full_recheck": False, "execution_authorized": False}
MAX_FILE_BYTES = 65536


def _positive_integer(value, label):
    if type(value) is not int or value <= 0:
        raise ValueError(label + " must be a positive exact integer")
    return value


def _read(path):
    with path.open("rb") as stream:
        data = stream.read(MAX_FILE_BYTES + 1)
    if len(data) > MAX_FILE_BYTES:
        raise ValueError("proc field exceeds byte limit")
    return data.decode("utf-8", errors="strict")


def parse_stat(raw):
    """Linux proc_pid_stat: comm can contain spaces, parentheses and newlines."""
    prefix, separator, rest = raw.rpartition(")")
    pid_text, open_paren, _comm = prefix.partition("(")
    if not separator or not open_paren:
        raise ValueError("malformed stat record")
    pid = int(pid_text.strip())
    fields = rest.split()
    if pid <= 0 or len(fields) < 22 or len(fields[0]) != 1:
        raise ValueError("short stat record")
    # Tail starts at field 3 (state); do not include reaped children's CPU.
    result = {"pid": pid, "state": fields[0], "ppid": int(fields[1]),
              "user_ticks": int(fields[11]), "system_ticks": int(fields[12]),
              "start_ticks": int(fields[19]), "rss_pages": int(fields[21])}
    if any(value < 0 for key, value in result.items() if key != "state"):
        raise ValueError("negative stat field")
    return result


def parse_cpu_list(raw):
    cpus = set()
    if not raw.strip():
        raise ValueError("empty CPU affinity")
    for token in raw.strip().split(","):
        endpoints = token.split("-")
        if len(endpoints) not in (1, 2) or any(not x.isdecimal() for x in endpoints):
            raise ValueError("malformed CPU affinity")
        first, last = int(endpoints[0]), int(endpoints[-1])
        if last < first or last > 1048575 or last - first > 65535:
            raise ValueError("CPU affinity range exceeds bound")
        cpus.update(range(first, last + 1))
        if len(cpus) > 65536:
            raise ValueError("CPU affinity exceeds bound")
    return sorted(cpus)


def _status_cpus(raw):
    rows = [line.split(":", 1)[1] for line in raw.splitlines()
            if line.startswith("Cpus_allowed_list:")]
    if len(rows) != 1:
        raise ValueError("missing or duplicate affinity field")
    return parse_cpu_list(rows[0])


def _available(raw):
    rows = [line.split() for line in raw.splitlines() if line.startswith("MemAvailable:")]
    if len(rows) != 1 or len(rows[0]) != 3 or rows[0][2] != "kB":
        raise ValueError("unknown MemAvailable")
    value = int(rows[0][1])
    if value < 0:
        raise ValueError("negative MemAvailable")
    return value * 1024


def capture(proc_root="/proc", *, max_processes=8192):
    """Observe bounded proc records, preserving per-PID failures and read limits.

    A synthetic proc_root is supported for tests. No saved snapshot is a fresh
    process observation until its current boot/PID/start ticks are reobserved.
    """
    _positive_integer(max_processes, "max_processes")
    if max_processes > 65536:
        raise ValueError("max_processes exceeds bound")
    root = Path(proc_root)
    clock_ticks = _positive_integer(os.sysconf("SC_CLK_TCK"), "clock ticks")
    page_bytes = _positive_integer(os.sysconf("SC_PAGE_SIZE"), "page bytes")
    start = time.monotonic_ns()
    boot = _read(root / "sys/kernel/random/boot_id").strip()
    if not boot:
        raise ValueError("unknown boot identity")
    rows, failures, selected = [], [], []
    enumeration_complete = True
    with os.scandir(root) as entries:
        for entry in entries:
            if not entry.name.isdecimal() or int(entry.name) <= 0:
                continue
            if len(selected) >= max_processes:
                enumeration_complete = False
                break
            selected.append(int(entry.name))
    for pid in sorted(selected):
        observed_start = time.monotonic_ns()
        try:
            before = parse_stat(_read(root / str(pid) / "stat"))
            cpus = _status_cpus(_read(root / str(pid) / "status"))
            after = parse_stat(_read(root / str(pid) / "stat"))
            if before["pid"] != pid or after["pid"] != pid or before["start_ticks"] != after["start_ticks"]:
                raise ValueError("PID identity changed during observation")
            rows.append({**after, "boot_id": boot, "leader_allowed_cpus": cpus,
                         "observed_start_ns": observed_start,
                         "observed_end_ns": time.monotonic_ns(),
                         "process_state": "leader_zombie_or_dead" if after["state"] in ("Z", "X", "x") else "live_leader",
                         "rss_bytes": after["rss_pages"] * page_bytes})
        except (OSError, ValueError, UnicodeError) as error:
            reason = ("absent_during_read" if isinstance(error, OSError) and
                      error.errno in (errno.ENOENT, errno.ESRCH) else "unreadable_or_unstable")
            failures.append({"pid": pid, "status": reason, "error_type": type(error).__name__})
    try:
        available = _available(_read(root / "meminfo"))
    except (OSError, ValueError, UnicodeError):
        available = None
    if _read(root / "sys/kernel/random/boot_id").strip() != boot:
        raise ValueError("boot identity changed during capture")
    return {**FLAGS, "schema": "process-observation.v1", "boot_id": boot,
            "clock_ticks_per_second": clock_ticks, "page_bytes": page_bytes,
            "observed_start_ns": start, "observed_end_ns": time.monotonic_ns(),
            "enumeration_complete": enumeration_complete,
            "records_complete": not failures, "processes": rows, "failures": failures,
            "mem_available_bytes": available,
            "scope": "non-atomic read-only observations; leader affinity is not occupancy or sibling-thread affinity; RSS is shared; no admission or cleanup authority"}


def _validate_snapshot(snapshot):
    if type(snapshot) is not dict or snapshot.get("schema") != "process-observation.v1":
        raise ValueError("snapshot schema")
    for flag in FLAGS:
        if snapshot.get(flag) is not False:
            raise ValueError("observation authority flags must remain false")
    _positive_integer(snapshot["clock_ticks_per_second"], "clock ticks")
    _positive_integer(snapshot["page_bytes"], "page bytes")
    if type(snapshot.get("boot_id")) is not str or not snapshot["boot_id"]:
        raise ValueError("snapshot boot identity")
    if type(snapshot.get("processes")) is not list or len(snapshot["processes"]) > 65536:
        raise ValueError("bounded process array")
    for key in ("enumeration_complete", "records_complete"):
        if type(snapshot.get(key)) is not bool:
            raise ValueError("explicit completeness flags required")
    seen_pids = set()
    for row in snapshot["processes"]:
        if type(row) is not dict or row.get("boot_id") != snapshot["boot_id"]:
            raise ValueError("process boot identity mismatch")
        _positive_integer(row.get("pid"), "PID")
        if row["pid"] in seen_pids:
            raise ValueError("duplicate process PID")
        seen_pids.add(row["pid"])
        for key in ("start_ticks", "user_ticks", "system_ticks", "observed_end_ns", "rss_bytes"):
            if type(row.get(key)) is not int or row[key] < 0:
                raise ValueError("invalid process counter: " + key)
        if type(row.get("state")) is not str or len(row["state"]) != 1:
            raise ValueError("invalid process leader state")
        expected = "leader_zombie_or_dead" if row["state"] in ("Z", "X", "x") else "live_leader"
        if row.get("process_state") != expected:
            raise ValueError("leader state classification mismatch")
        cpus = row.get("leader_allowed_cpus")
        if (type(cpus) is not list or not cpus or len(cpus) > 65536 or
                any(type(cpu) is not int or cpu < 0 for cpu in cpus) or cpus != sorted(set(cpus))):
            raise ValueError("invalid leader CPU affinity")


def compare(before, after):
    """Pair exact identities; changed counters/clock/boot remain unmeasured."""
    for snapshot in (before, after):
        _validate_snapshot(snapshot)
    old = {}
    for row in before["processes"]:
        key = (row["boot_id"], row["pid"], row["start_ticks"])
        if key in old:
            raise ValueError("duplicate process identity")
        old[key] = row
    rows, seen = [], set()
    same_clock = (before["boot_id"] == after["boot_id"] and
                  before["clock_ticks_per_second"] == after["clock_ticks_per_second"])
    for row in after["processes"]:
        key = (row["boot_id"], row["pid"], row["start_ticks"])
        if key in seen:
            raise ValueError("duplicate process identity")
        seen.add(key)
        result = {"pid": row["pid"], "boot_id": row["boot_id"],
                  "start_ticks": row["start_ticks"], "state": row["state"],
                  "process_state": row["process_state"], "leader_allowed_cpus": row["leader_allowed_cpus"],
                  "rss_bytes": row["rss_bytes"], "cpu_seconds": None,
                  "elapsed_seconds": None, "average_cpu_equivalents": None,
                  "measurement": "unmatched_identity_or_clock"}
        prior = old.get(key)
        if same_clock and prior is not None:
            elapsed_ns = row["observed_end_ns"] - prior["observed_end_ns"]
            ticks = ((row["user_ticks"] + row["system_ticks"]) -
                     (prior["user_ticks"] + prior["system_ticks"]))
            if elapsed_ns > 0 and ticks >= 0:
                elapsed = elapsed_ns / 1e9
                cpu = ticks / after["clock_ticks_per_second"]
                rate = cpu / elapsed
                if not all(math.isfinite(x) for x in (elapsed, cpu, rate)):
                    raise ValueError("nonfinite rate")
                result.update(cpu_seconds=cpu, elapsed_seconds=elapsed,
                              average_cpu_equivalents=rate, measurement="paired_interval")
            else:
                result["measurement"] = "counter_or_clock_regression"
        rows.append(result)
    return {**FLAGS, "schema": "process-interval.v1", "processes": rows,
            "live_leaders_at_last_observation": sum(row["process_state"] == "live_leader" for row in rows),
            "zombie_or_dead_leaders_at_last_observation": sum(row["process_state"] == "leader_zombie_or_dead" for row in rows),
            "unmeasured_intervals": sum(row["cpu_seconds"] is None for row in rows),
            "before_enumeration_complete": before["enumeration_complete"],
            "after_enumeration_complete": after["enumeration_complete"],
            "before_records_complete": before["records_complete"],
            "after_records_complete": after["records_complete"],
            "mem_available_bytes": after["mem_available_bytes"],
            "scope": "CPU is averaged over each paired process interval, including work before exit; a zombie leader can have live sibling threads; missing processes have unknown outcomes; no free-core or safe-memory inference"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-processes", type=int, default=8192)
    args = parser.parse_args()
    print(json.dumps(capture(max_processes=args.max_processes), sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
