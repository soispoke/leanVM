"""Audit, report and seal exact padding-witness memoization."""
from pathlib import Path
import datetime, hashlib, io, json, subprocess, tarfile
import identity_audit as audit

b = Path(__file__).resolve().parent
repo = b / 'candidate'
dest = repo / 'experiments/pcs-r1cs/evidence/2026-10-23-common-key-padding-witness'
dest.mkdir(exist_ok=True)
screen = audit.series('padding-screen', 'padding', 3)
target_file = b / 'artifacts/padding-target.json'
target = audit.series('padding-target', 'padding', 7) if target_file.exists() else None
qualified = [] if target is None else [m for m in ('total_s', 'creation_s') if
             target['metrics'][m]['paired_reduction_pct'] >= 3 and
             target['metrics'][m]['wins'] >= 6 and
             target['metrics'][m]['bootstrap95_pct'][0] > 0]
companion_ok = target is not None and all(target['metrics'][m]['paired_reduction_pct'] >= -1 for m in ('total_s', 'creation_s'))
retain = bool(qualified) and companion_ok
series = [screen] + ([] if target is None else [target])
rows = [row for s in series for pair in s['rows'] for row in pair.values()]

def receipt(label):
    return json.loads((b / label / 'result.json').read_text())

def sources(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root) and p.endswith(('.rs', '.toml', 'Cargo.lock'))}

control = receipt('joint-target-joint-01')
assert sources(control) == sources(receipt('joint-release-build'))
control_hash = hashlib.sha256((b / 'artifacts/bin/control-v5').read_bytes()).hexdigest()
assert control['file_sha256_before'][control['command'][0]] == control_hash
candidate_sources = sources(receipt('padding-build'))
candidate_hash = hashlib.sha256((b / 'artifacts/bin/padding').read_bytes()).hexdigest()
assert hashlib.sha256((b / 'target/release/examples/closed_tree').read_bytes()).hexdigest() == candidate_hash
intervals = []
for row in rows:
    label = Path(row['path']).parent.parent.name
    r = receipt(label)
    expected = sources(control) if '-control-v5-' in label else candidate_sources
    assert sources(r) == expected, label
    assert r['file_sha256_before'][r['command'][0]] == hashlib.sha256(Path(r['command'][0]).read_bytes()).hexdigest(), label
    assert r['tooling_git']['revision'] == 'ca3f535ffdd9156d529c0c256208cd6d2b355276', label
    intervals.append((datetime.datetime.fromisoformat(r['started_utc']), datetime.datetime.fromisoformat(r['finished_utc'])))
intervals.sort()
assert all(a[1] <= z[0] for a, z in zip(intervals, intervals[1:]))
gates = {}
for label in ('padding-template-targeted', 'padding-full-tests', 'padding-clippy', 'padding-fmt', 'padding-doc', 'padding-build'):
    r = receipt(label)
    assert r['ok'] and r['files_unchanged'] and sources(r) == candidate_sources, label
    gates[label] = hashlib.sha256((b / label / 'result.json').read_bytes()).hexdigest()
for path, digest in candidate_sources.items():
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
assert subprocess.check_output(['git', 'diff'], cwd=repo) == (b / 'artifacts/padding-template.patch').read_bytes()
if not retain:
    subprocess.run(['git', 'restore', '--', 'crates/flock/src/witness.rs', 'crates/flock/src/hash.rs'], cwd=repo, check=True)
    for path, digest in sources(control).items():
        assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
report = {'ok': True, 'retained': retain, 'qualified': qualified, 'companion_ok': companion_ok,
          'all_sizes_shapes_keys_unchanged': True, 'processes': len(rows),
          'certificates': sum(r['proofs'] for r in rows), 'screen': screen, 'target': target,
          'validation': gates, 'baseline': 'f23eddd93d85de3d07342474e031ff619cbdc860',
          'tooling': 'ca3f535ffdd9156d529c0c256208cd6d2b355276',
          'runner_sha256': 'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e',
          'binary_sha256': candidate_hash,
          'scope': 'Local paired performance evidence; no official recursion.fast or formal composition claim.'}
(dest / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Common-key padding-witness template', '',
         ('Retained exact memoization of complete padding witness groups.' if retain else
          'Rejected padding witness memoization under the frozen rule; accepted Rust sources restored.'), '',
         'The control is the accepted hybrid opener at f23eddd9. The prior AVX2 candidate is absent. Each fixture uses chain16 with two or eight leaves, creating and locally verifying every node in the binary tree. These are local research fixtures, not matched new leanVM/Flock benchmarks or shielded-transfer measurements.', '',
         'Unused BLAKE2s slots contain the same valid compression instance, including its pinned constant wire. The generator previously rebuilt each padding instance and transposed each padding group. It now synthesizes one eight-block group and its lincheck stripe once per invocation, then streams those exact bytes to fully padded groups. Mixed groups retain the original per-instance path. Every witness byte, commitment, reduction, verifier, transcript order, key and proof encoding is preserved.', '',
         'The generic reference test reconstructs every output word and every stripe byte independently, covering all 0–32 live-block counts, zero/nonzero/no padding, and block widths64/512/16384 bits. A BLAKE2s differential compares all four output buffers against explicitly materialized real padding blocks for every 0–32 live count. A full materialized input has no template path. Full release validation passes71 Flock,77 native recursion and44 PCS tests (one existing ignore), Clippy with tests/examples and warnings denied, formatting and PCS/native rustdoc. No architecture-specific source changes. The inherited broader Flock rustdoc link failure is documented in the preceding AVX2 experiment.', '']
for title, s in [('Three-pair two-leaf screen', screen)] + ([] if target is None else [('Seven independent eight-leaf confirmation pairs', target)]):
    lines += ['## ' + title, '', '| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins |', '| --- | ---: | ---: | ---: | ---: |']
    for name, key in [('Whole process', 'total_s'), ('All proof creation', 'creation_s'), ('Root creation', 'root_creation_s')]:
        m = s['metrics'][key]
        lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/{s['pairs']} |")
    lines.append('')
if target:
    lo, hi = target['metrics']['creation_s']['bootstrap95_pct']
    lines += [f'Proof-creation paired bootstrap95 interval: {lo:+.2f}% to {hi:+.2f}%.', '']
lines += ['Retention requires at least3% paired median improvement in total or creation, at least6/7 independent target wins, positive bootstrap95 lower bound, no companion total/creation regression over1%, and exact keys/shapes/statements/proof geometry. Every timed observation is retained. Paired reductions are medians of per-pair ratios, which need not equal a ratio of medians.', '',
          'The audit independently reconstructs all leaf and aggregate statements, checks every key and shape plus per-position certificate byte/scalar/Merkle-phase counts against the published common-key baseline, binds each process to its source manifest and frozen build, and rejects overlapping timed intervals. The exact measured source bytes are retained on acceptance; rejected source changes are restored after archiving the patch.', '',
          'Yukon advanced during the preceding phase. This phase pins the latest checked upstream ca3f535; its benchmark runner is unchanged (SHA256 ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e). The added read-only process observation tool is used before/after the measurements for context, with no scheduling authority or speedup claim. The first generic check preceded the upgrade; the stronger two-test check and every full gate/timed process use ca3f535.', '',
          'Rust1.99.1, native CPU plus pclmulqdq,32 workers,CPUs0–63,four Cargo jobs. Build/test budget96GiB, benchmark budget16GiB, host reserve40GiB. The Xeon Gold6230R host is shared; RSS is sampled process-group memory, not cgroup isolation. The existing frozen control is reused only after its build/source/binary identity is checked.', '',
          'The archive preserves exact commands, raw logs, source and binary hashes, frozen-control provenance, candidate patch, predeclared plan, checks and all timing receipts. Run python3 verify-archive.py to verify member hashes without extraction. Formal composition/security proof and official recursion.fast integration remain open. The optimization goal remains active.', '']
(dest / 'README.md').write_text('\n'.join(lines))
(dest / 'verify-archive.py').write_bytes((repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-hybrid-opening/verify-archive.py').read_bytes())
files = {n: (dest / n).read_bytes() for n in ('README.md', 'results.json', 'verify-archive.py')}
for label in ('joint-release-build', 'joint-target-joint-01'):
    files[f'control-reuse/{label}.json'] = (b / label / 'result.json').read_bytes()
for root in b.glob('padding-*'):
    if root.is_dir():
        for p in root.rglob('*'):
            if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in (b / 'artifacts').glob('padding*'):
    if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in b.glob('*padding*.py'):
    files['scripts/' + p.name] = p.read_bytes()
for name in ('run-command.py', 'identity_audit.py'):
    files['scripts/' + name] = (b / name).read_bytes()
files['artifacts/validate-closed-tree.py'] = (b / 'artifacts/validate-closed-tree.py').read_bytes()
files['tooling/process_observation.py'] = Path('/root/yukon-autoresearch/workspaces/yukon-latest-ca3f535/toolkit/tools/process_observation.py').read_bytes()
files['archive-manifest.json'] = json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(files.items())}, indent=2).encode()
with tarfile.open(dest / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name); info.size, info.mtime = len(data), 0
        tar.addfile(info, io.BytesIO(data))
(dest / 'archive.sha256').write_text(hashlib.sha256((dest / 'raw-evidence.tar.gz').read_bytes()).hexdigest() + '  raw-evidence.tar.gz\n')
print(json.dumps({'retained': retain, 'metrics': (target or screen)['metrics']}, indent=2))
