from pathlib import Path
import subprocess,hashlib,json,shutil
b=Path(__file__).resolve().parent
for label,cmd in [
 ('padding-full-tests',['cargo','test','--locked','--release','-p','flock','-p','pcs','-p','format_recursion','--lib']),
 ('padding-clippy',['cargo','clippy','--locked','--release','-p','flock','--all-targets','--','-D','warnings']),
 ('padding-fmt',['cargo','fmt','--all','--','--check']),
 ('padding-doc',['cargo','doc','--locked','--release','-p','pcs','-p','format_recursion','--no-deps']),
 ('padding-build',['cargo','build','--locked','--release','-p','rec_aggregation','--example','closed_tree'])]:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('passed',label,flush=True)
r=json.loads((b/'padding-build/result.json').read_text());assert r['ok'] and r['files_unchanged']
bin=b/'artifacts/bin/padding';assert not bin.exists();shutil.copy2(b/'target/release/examples/closed_tree',bin)
(b/'artifacts/padding-template.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=b/'candidate'))
(b/'artifacts/padding-binary.json').write_text(json.dumps({'binary':str(bin),'sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'build_receipt_sha256':hashlib.sha256((b/'padding-build/result.json').read_bytes()).hexdigest()},indent=2))
print('frozen padding',flush=True)
