use primitives::field::gf2_64x3::F192;
use std::hint::black_box;

fn main() {
    let mut state = 0xdecaf20261023u64;
    let mut next = || {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        state
    };
    let values: Vec<_> = (0..1024)
        .map(|_| {
            let a = F192::new(next(), next(), next());
            let b = F192::new(next(), next(), next());
            (a, b, a.mul_unreduced(b))
        })
        .collect();
    let plan = bench::Plan::new(5, 0);
    let (_, reduction) = plan.warm_then_measure(|_| {
        let mut sum = F192::ZERO;
        for _ in 0..16384 {
            for v in &values {
                sum = sum + black_box(v.2).reduce();
            }
        }
        black_box(sum)
    });
    let (_, product) = plan.warm_then_measure(|_| {
        let mut sum = F192::ZERO;
        for _ in 0..16384 {
            for v in &values {
                sum = sum + black_box(v.0).mul_unreduced(black_box(v.1)).reduce();
            }
        }
        black_box(sum)
    });
    println!("reduction_s={:.9} product_s={:.9}", reduction.mean(), product.mean());
}
