"""Run and independently audit matched native/VM common-key hash-chain trees."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys

B = Path(__file__).resolve().parent
YUKON = Path('/root/yukon-autoresearch/workspaces/yukon-latest-ca11688')
REV = 'ca11688397f1a44d4d55f7fd4f4eeec092ea4a93'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def receipt(label):
    r = json.loads((B / label / 'result.json').read_text())
    assert r['ok'] and r['files_unchanged'], label
    assert len(r['runs']) == 1 and r['runs'][0]['ok'], label
    return r


def source_map(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root) and p.endswith(('.rs', '.py', '.toml', 'Cargo.lock'))}


def bind_sources(tree):
    return subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--',
                                    '*.rs', '*.py', '*.toml', 'Cargo.lock'], cwd=tree, text=True).splitlines()


def check(label, which, depth):
    r = receipt(label)
    assert r['tooling_git']['revision'] == REV
    tree = B / ('control-v6' if which == 'native' else 'vm-common')
    binary = B / 'artifacts/bin' / ('control-v6' if which == 'native' else 'vm-common')
    assert r['file_sha256_before'][str(binary)] == sha(binary)
    manifest = json.loads((B / f'artifacts/common-comparison-{which}-build.json').read_text())
    current_sources = source_map(r)
    for p, h in manifest['sources'].items():
        assert current_sources[p] == h, (label, p)
    assert sha(binary) == manifest['binary_sha256']
    run = r['runs'][0]
    assert run['returncode'] == 0 and run['stop_reason'] is None
    out = B / label / 'run-00/stdout.log'
    assert sha(out) == run['stdout_sha256']
    assert sha(out.with_name('stderr.log')) == run['stderr_sha256']
    events = [json.loads(line) for line in out.read_text().splitlines() if line.startswith('{')]
    assert events[0]['kind'] == 'setup' and events[-1]['kind'] == 'complete'
    setup, complete = events[0], events[-1]
    assert setup['chain'] == complete['chain'] == 16
    assert setup['depth'] == complete['depth'] == depth
    assert setup['official_score'] is False and complete['status'] == 'locally_verified'
    assert setup['key'] == complete['key']
    proofs = events[1:-1]
    assert len(proofs) == (1 << (depth + 1)) - 1
    assert [(p['level'], p['index']) for p in proofs] == [
        (level, index) for level in range(depth + 1) for index in range(1 << (depth - level))]
    found = {}
    for p in proofs:
        level, index = p['level'], p['index']
        assert p['kind'] == 'proof' and p['height'] == level and p['verified'] is True
        if not level:
            start = hashlib.blake2s((index + 20261022).to_bytes(8, 'little')).digest()
            assert bytes(p['start']) == start
            for _ in range(16):
                start = hashlib.blake2s(b'\x43' + start).digest()
            expected = hashlib.blake2s(b'\x4c' + start + (16).to_bytes(8, 'little')).digest()
        else:
            expected = hashlib.blake2s(b'\x4e' + found[level - 1, 2 * index] + found[level - 1, 2 * index + 1]).digest()
        assert bytes(p['statement']) == expected
        found[level, index] = expected
        for k in ['creation_s', 'verification_s']:
            assert math.isfinite(p[k]) and p[k] >= 0
        assert 36 < p['certificate_bytes'] <= 1 << 20
        assert p['stream_scalars'] > 0 and p['merkle_phases'] > 0
        assert len(p['certificate_digest']) == 32
    assert bytes(complete['root']) == found[depth, 0] and complete['height'] == depth
    root = proofs[-1]
    geometry = [{k: p[k] for k in ['level', 'index', 'height', 'statement', 'certificate_bytes',
                                  'certificate_digest', 'stream_scalars', 'merkle_phases']} for p in proofs]
    if which == 'vm':
        for item, p in zip(geometry, proofs):
            item.update({k: p[k] for k in ['base_cycles', 'padded_cycles']})
    shape = ({k: setup[k] for k in ['native_rows', 'public_len', 'blocks', 'block_log',
                                   'connector_start', 'q_offset', 'stack_log']} if which == 'native'
             else {'code_len': setup['code_len'], 'log_inv_rate': setup['log_inv_rate']})
    return {'label': label, 'backend': which, 'depth': depth, 'leaves': 1 << depth, 'proofs': len(proofs),
            'key': setup['key'], 'shape': shape, 'geometry': geometry,
            'total_s': run['wall_seconds'], 'setup_s': setup['setup_s'],
            'creation_s': sum(p['creation_s'] for p in proofs),
            'leaf_creation_s': sum(p['creation_s'] for p in proofs if not p['level']),
            'node_creation_s': sum(p['creation_s'] for p in proofs if p['level']),
            'root_creation_s': root['creation_s'],
            'verification_s': sum(p['verification_s'] for p in proofs),
            'root_verification_s': root['verification_s'],
            'root_certificate_bytes': root['certificate_bytes'],
            'all_certificate_bytes': sum(p['certificate_bytes'] for p in proofs),
            'peak_rss_bytes': run['sampled_group_peak_rss_bytes'],
            'cpu_s': run['user_seconds'] + run['system_seconds'],
            'started_utc': r['started_utc'], 'finished_utc': r['finished_utc']}


def run(which, depth, trial):
    label = f'common-matched-{which}-d{depth}-t{trial}'
    assert not (B / label).exists(), label
    tree = B / ('control-v6' if which == 'native' else 'vm-common')
    binary = B / 'artifacts/bin' / ('control-v6' if which == 'native' else 'vm-common')
    args = ['python3', str(YUKON / 'bin/bench-research.py'), '--cwd', str(tree), '--out', str(B / label),
            '--budget-gib', '16', '--reserve-gib', '40', '--timeout-seconds', '600',
            '--cpus', ','.join(map(str, range(64)))]
    for p in bind_sources(tree):
        args += ['--source', p]
    args += ['--source', str(binary), '--source', str(Path(__file__).resolve()),
             '--source', str(B / 'artifacts/vm-common-comparison-plan.json'),
             '--', str(binary), '--depth', str(depth), '--chain', '16']
    subprocess.run(args, env=dict(os.environ, LEANVM_NUM_THREADS='32'), check=True)
    result = check(label, which, depth)
    print(json.dumps({k: result[k] for k in ['label', 'total_s', 'creation_s', 'root_creation_s']}), flush=True)


def audit():
    rows = [check(f'common-matched-{w}-d{d}-t{t}', w, d)
            for d in [1, 2, 3] for t in [1, 2, 3] for w in ['native', 'vm']]
    intervals = sorted((datetime.datetime.fromisoformat(r['started_utc']),
                        datetime.datetime.fromisoformat(r['finished_utc'])) for r in rows)
    assert all(a[1] <= z[0] for a, z in zip(intervals, intervals[1:]))
    summary = []
    for w in ['native', 'vm']:
        selected = [r for r in rows if r['backend'] == w]
        assert all((r['key'], r['shape']) == (selected[0]['key'], selected[0]['shape']) for r in selected)
        for d in [1, 2, 3]:
            rs = [r for r in selected if r['depth'] == d]
            assert all(r['geometry'] == rs[0]['geometry'] for r in rs)
            metrics = {k: statistics.median(r[k] for r in rs) for k in [
                'total_s', 'setup_s', 'creation_s', 'leaf_creation_s', 'node_creation_s',
                'root_creation_s', 'verification_s', 'root_verification_s', 'root_certificate_bytes',
                'all_certificate_bytes', 'peak_rss_bytes', 'cpu_s']}
            summary.append({'backend': w, 'leaves': 1 << d, 'trials': len(rs), **metrics})
    result = {'ok': True, 'summary': summary, 'rows': rows, 'yukon': REV,
              'runner_sha256': sha(YUKON / 'bin/bench-research.py')}
    (B / 'artifacts/common-comparison-results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'run':
        for d in [1, 2, 3]:
            for t in [1, 2, 3]:
                for w in (['native', 'vm'] if t % 2 else ['vm', 'native']):
                    run(w, d, t)
        audit()
    elif sys.argv[1] == 'audit':
        audit()
    else:
        raise SystemExit('run or audit')
