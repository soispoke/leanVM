"""Freeze, measure and audit the sparse witness opening candidate."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import random
import shutil
import statistics
import subprocess
import sys

B = Path(__file__).resolve().parent
REV = '42e046241e0fe55ba34476c9d5310b5d2590843a'
VARIANTS = ['control', 'candidate']
METRICS = ['total_s', 'setup_s', 'creation_s', 'leaf_creation_s', 'node_creation_s', 'root_creation_s',
           'verification_s', 'root_verification_s', 'peak_rss_bytes', 'cpu_s']


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def receipt(label):
    r = json.loads((B / label / 'result.json').read_text())
    assert r['ok'] and r['files_unchanged'] and len(r['runs']) == 1, label
    assert r['runs'][0]['ok'] and r['runs'][0]['returncode'] == 0
    assert r['tooling_git'] == {'revision': REV, 'dirty': False}
    assert r['source_git']['revision'] == '906015c1b12b447ce4c993723e6879267b1e94c1'
    for p in ['stdout', 'stderr']:
        assert sha(B / label / f'run-00/{p}.log') == r['runs'][0][p + '_sha256']
    return r


def sources(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root)}


def build():
    for variant in VARIANTS:
        label = f'sparse-matched-{variant}-build'
        assert not (B / label).exists()
        subprocess.run(['python3', str(B / 'run-sparse-command.py'), variant, label,
                        'cargo', 'build', '--locked', '--release', '-p', 'rec_aggregation',
                        '--example', 'closed_tree'], check=True)
        r = receipt(label)
        target = B / ('target-vm-common' if variant == 'control' else 'target-opening')
        frozen = B / f'artifacts/bin/opening-{variant}'
        assert not frozen.exists()
        shutil.copy2(target / 'release/examples/closed_tree', frozen)
        save(B / f'artifacts/sparse-{variant}-build.json', {
            'build_label': label, 'build_receipt_sha256': sha(B / label / 'result.json'),
            'binary_sha256': sha(frozen), 'sources': sources(r)})
        print(json.dumps({'built': variant, 'sha256': sha(frozen)}), flush=True)
    a, z = [json.loads((B / f'artifacts/sparse-{v}-build.json').read_text()) for v in VARIANTS]
    assert a['sources'].keys() == z['sources'].keys()
    assert [p for p in a['sources'] if a['sources'][p] != z['sources'][p]] == ['crates/pcs/src/whir/hybrid.rs']


def check(label, variant, depth):
    r = receipt(label)
    manifest = json.loads((B / f'artifacts/sparse-{variant}-build.json').read_text())
    assert sources(r) == manifest['sources'], label
    binary = B / f'artifacts/bin/opening-{variant}'
    assert r['file_sha256_before'][str(binary)] == sha(binary) == manifest['binary_sha256']
    for name in ['run-sparse-command.py', 'sparse-experiment.py', 'artifacts/opening-sparse-matched-plan.json']:
        assert r['file_sha256_before'][str(B / name)] == sha(B / name)
    events = [json.loads(s) for s in (B / label / 'run-00/stdout.log').read_text().splitlines() if s.startswith('{')]
    setup, complete = events[0], events[-1]
    assert setup['kind'] == 'setup' and complete['kind'] == 'complete'
    assert setup['depth'] == complete['depth'] == depth
    assert setup['chain'] == complete['chain'] == 16 and setup['official_score'] is False
    assert setup['key'] == complete['key'] and complete['status'] == 'locally_verified'
    proofs = events[1:-1]
    assert len(proofs) == (1 << (depth + 1)) - 1
    assert [(p['level'], p['index']) for p in proofs] == [
        (level, i) for level in range(depth + 1) for i in range(1 << (depth - level))]
    found = {}
    for p in proofs:
        level, i = p['level'], p['index']
        assert p['kind'] == 'proof' and p['height'] == level and p['verified'] is True
        if level == 0:
            start = hashlib.blake2s((i + 20261022).to_bytes(8, 'little')).digest()
            assert bytes(p['start']) == start
            for _ in range(16):
                start = hashlib.blake2s(b'\x43' + start).digest()
            expected = hashlib.blake2s(b'\x4c' + start + (16).to_bytes(8, 'little')).digest()
        else:
            expected = hashlib.blake2s(b'\x4e' + found[level-1, 2*i] + found[level-1, 2*i+1]).digest()
        assert bytes(p['statement']) == expected
        found[level, i] = expected
        assert 36 < p['certificate_bytes'] <= 1 << 20
        assert p['stream_scalars'] > 0 and p['merkle_phases'] > 0
        assert len(bytes(p['certificate_digest'])) == 32
        assert all(math.isfinite(p[k]) and p[k] >= 0 for k in ['creation_s', 'verification_s'])
    assert bytes(complete['root']) == found[depth, 0] and complete['height'] == depth
    run = r['runs'][0]
    return {'label': label, 'variant': variant, 'depth': depth, 'leaves': 1 << depth,
            'key': setup['key'], 'shape': {k: setup[k] for k in [
                'native_rows', 'public_len', 'blocks', 'block_log', 'connector_start', 'q_offset', 'stack_log']},
            'geometry': [{k: p[k] for k in ['level', 'index', 'height', 'statement', 'certificate_bytes',
                                          'certificate_digest', 'stream_scalars', 'merkle_phases']} for p in proofs],
            'total_s': run['wall_seconds'], 'setup_s': setup['setup_s'],
            'creation_s': sum(p['creation_s'] for p in proofs),
            'leaf_creation_s': sum(p['creation_s'] for p in proofs if not p['level']),
            'node_creation_s': sum(p['creation_s'] for p in proofs if p['level']),
            'root_creation_s': proofs[-1]['creation_s'],
            'verification_s': sum(p['verification_s'] for p in proofs),
            'root_verification_s': proofs[-1]['verification_s'],
            'peak_rss_bytes': run['sampled_group_peak_rss_bytes'],
            'cpu_s': run['user_seconds'] + run['system_seconds'],
            'started_utc': r['started_utc'], 'finished_utc': r['finished_utc']}


def run(phase, variant, trial, depth):
    label = f'sparse-{phase}-{variant}-{trial:02d}'
    assert not (B / label).exists(), label
    binary = B / f'artifacts/bin/opening-{variant}'
    command = ['python3', str(B / 'run-sparse-command.py'), variant, label, str(binary),
               '--depth', str(depth), '--chain', '16']
    if phase == 'equivalence':
        command += ['--certificate-dir', str(B / f'artifacts/sparse-certificates-{variant}')]
    subprocess.run(command, env=dict(os.environ, SPARSE_BUDGET_GIB='16'), check=True)
    result = check(label, variant, depth)
    print(json.dumps({k: result[k] for k in ['label', 'total_s', 'creation_s', 'node_creation_s',
                                           'root_creation_s']}), flush=True)


def audit(phase, count, depth):
    rows = [{v: check(f'sparse-{phase}-{v}-{i:02d}', v, depth) for v in VARIANTS}
            for i in range(1, count + 1)]
    intervals = sorted((datetime.datetime.fromisoformat(r['started_utc']),
                        datetime.datetime.fromisoformat(r['finished_utc'])) for pair in rows for r in pair.values())
    assert all(a[1] <= z[0] for a, z in zip(intervals, intervals[1:]))
    reference = rows[0]['control']
    for pair in rows:
        for r in pair.values():
            for k in ['key', 'shape', 'geometry']:
                assert r[k] == reference[k], (r['label'], k)
    if phase == 'equivalence':
        dirs = [B / f'artifacts/sparse-certificates-{v}' for v in VARIANTS]
        names = sorted(p.name for p in dirs[0].glob('*.bin'))
        assert len(names) == 3 and names == sorted(p.name for p in dirs[1].glob('*.bin'))
        assert all((dirs[0] / n).read_bytes() == (dirs[1] / n).read_bytes() for n in names)
    rng = random.Random(20261023)
    metrics = {}
    for k in METRICS:
        changes = [100 * (1 - p['candidate'][k] / p['control'][k]) for p in rows]
        boot = sorted(statistics.median(rng.choices(changes, k=count)) for _ in range(20000))
        metrics[k] = {'control_median': statistics.median(p['control'][k] for p in rows),
                      'candidate_median': statistics.median(p['candidate'][k] for p in rows),
                      'paired_reduction_pct': statistics.median(changes), 'wins': sum(c > 0 for c in changes),
                      'paired_pct': changes, 'bootstrap95_pct': [boot[499], boot[19499]]}
    total_or_creation = any(metrics[k]['paired_reduction_pct'] >= 3 and metrics[k]['wins'] >= 6
                            and metrics[k]['bootstrap95_pct'][0] > 0 for k in ['total_s', 'creation_s'])
    node = metrics['node_creation_s']
    companion = all(metrics[k]['paired_reduction_pct'] >= -1 for k in ['total_s', 'creation_s', 'root_creation_s'])
    retained = phase == 'target' and total_or_creation and companion and node['wins'] >= 6 \
        and node['paired_reduction_pct'] > 0 and node['bootstrap95_pct'][0] > 0
    result = {'ok': True, 'phase': phase, 'pairs': count, 'retained': retained,
              'certificate_bytes_identical': True, 'metrics': metrics, 'rows': rows,
              'tooling': REV, 'runner_sha256': sha(B.parent / 'yukon-latest-42e0462/bin/bench-research.py')}
    save(B / f'artifacts/sparse-{phase}-audited.json', result)
    print(json.dumps({'phase': phase, 'retained': retained, 'metrics': metrics}, indent=2), flush=True)
    return result


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'build':
        build()
    elif mode in ['equivalence', 'screen', 'target']:
        count, depth = {'equivalence': (1, 1), 'screen': (3, 1), 'target': (7, 3)}[mode]
        for i in range(1, count + 1):
            for variant in VARIANTS if i % 2 else reversed(VARIANTS):
                run(mode, variant, i, depth)
        audit(mode, count, depth)
    elif mode == 'audit':
        phase = sys.argv[2]
        count, depth = {'equivalence': (1, 1), 'screen': (3, 1), 'target': (7, 3)}[phase]
        audit(phase, count, depth)
    else:
        raise SystemExit('build, equivalence, screen, target or audit PHASE')
