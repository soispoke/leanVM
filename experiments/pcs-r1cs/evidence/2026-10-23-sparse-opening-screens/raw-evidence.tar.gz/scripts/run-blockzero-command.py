#!/usr/bin/env python3
from pathlib import Path
import os
import subprocess
import sys

B = Path(__file__).resolve().parent
variant, label, *command = sys.argv[1:]
assert variant in ('control', 'candidate')
tree = B / ('opening-control' if variant == 'control' else 'blockzero-candidate')
target = B / ('target-vm-common' if variant == 'control' else 'target-opening')
env = dict(os.environ, PATH='/root/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:' + os.environ['PATH'],
           RUSTUP_TOOLCHAIN='1.99.1', CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='4',
           RUSTFLAGS='-C target-cpu=native -C target-feature=+pclmulqdq', LEANVM_NUM_THREADS='32')
args = ['python3', '/root/yukon-autoresearch/workspaces/yukon-latest-42e0462/bin/bench-research.py',
        '--cwd', str(tree), '--out', str(B / label), '--budget-gib', os.environ.get('SPARSE_BUDGET_GIB', '96'),
        '--reserve-gib', '40', '--timeout-seconds', '1800', '--cpus', ','.join(map(str, range(64)))]
for name in subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--',
                                     '*.rs', '*.py', '*.toml', 'Cargo.lock'], cwd=tree, text=True).splitlines():
    args += ['--source', name]
for name in ['run-blockzero-command.py', 'blockzero-experiment.py', 'artifacts/opening-blockzero-matched-plan.json']:
    args += ['--source', str(B / name)]
args += ['--', *command]
raise SystemExit(subprocess.run(args, env=env).returncode)
