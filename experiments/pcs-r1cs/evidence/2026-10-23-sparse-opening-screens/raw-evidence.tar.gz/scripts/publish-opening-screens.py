"""Publish rejected opening experiments without changing accepted proving code."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

B = Path(__file__).resolve().parent
MAIN = Path('/root/workspaces/mission-9abcee72/leanvm-opt')
DEST = MAIN / 'experiments/pcs-r1cs/evidence/2026-10-23-sparse-opening-screens'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip() == '906015c1b12b447ce4c993723e6879267b1e94c1'
DEST.mkdir(parents=True, exist_ok=True)
results = {}
for name in ['sparse', 'blockzero']:
    for phase in ['equivalence', 'screen']:
        subprocess.run(['python3', str(B / f'{name}-experiment.py'), 'audit', phase],
                       stdout=subprocess.DEVNULL, check=True)
    results[name] = json.loads((B / f'artifacts/{name}-screen-audited.json').read_text())
    assert results[name]['ok'] and not results[name]['retained']
    tree = B / ('opening-candidate' if name == 'sparse' else 'blockzero-candidate')
    patch = subprocess.check_output(['git', 'diff', '--binary', '--unified=0', '--',
                                     'crates/pcs/src/whir/hybrid.rs'], cwd=tree)
    (DEST / f'{name}.patch').write_bytes(patch)
    harness = subprocess.check_output(['git', 'diff', '--binary', '--unified=0', '--',
                                       'crates/rec_aggregation/examples/closed_tree.rs'], cwd=tree)
    if name == 'sparse':
        (DEST / 'certificate-harness.patch').write_bytes(harness)
    else:
        assert harness == (DEST / 'certificate-harness.patch').read_bytes()

test = json.loads((B / 'opening-sparse-tests/result.json').read_text())
assert test['ok'] and test['files_unchanged']
for p in (B / 'opening-candidate/crates').rglob('*.rs'):
    rel = p.relative_to(B / 'opening-candidate')
    if rel.parts[1] in ['pcs', 'format_recursion', 'primitives', 'parallel', 'fiat_shamir']:
        key = str(B / 'candidate' / rel)
        assert hashlib.sha256(p.read_bytes()).hexdigest() == test['file_sha256_before'][key], str(rel)

report = {'ok': True, 'retained': False, 'base': '906015c1b12b447ce4c993723e6879267b1e94c1',
          'reason': 'Neither candidate passed the small fixture performance screen; no seven pair confirmation was launched.',
          'processes': 16, 'certificates': 48, 'proof_bytes_identical': True,
          'keys_shapes_statements_and_geometry_identical': True,
          'scope': 'Local chain16 two leaf screening, not an official recursion.fast score or a security proof.',
          'experiments': results,
          'checks': {'native_library_passed': 77, 'pcs_library_passed': 44, 'pcs_existing_ignored': 1,
                     'blockzero_complete_proof_differential_passed': True}}
(DEST / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Sparse hybrid opening screens', '',
         'Neither candidate is retained. Both start from the accepted common key native implementation at 906015c1. The first skips individual zero words and substitutes the field identity for one words. The second skips an entire zero tile or window while keeping dense multiplication free of per word branches. Both change prover computation only.', '',
         'Three alternating pairs per candidate use two leaves with 16 hash steps each, 32 workers and separate frozen executables. Each cell is a median; paired percentage changes are computed within each pair. Positive percentages mean faster. Root creation is the one merge in this fixture.', '',
         '| Candidate | Measure | Control (s) | Candidate (s) | Paired reduction | Wins |',
         '| :--- | :--- | ---: | ---: | ---: | ---: |']
for name, label in [('sparse', 'Individual words'), ('blockzero', 'Whole zero blocks')]:
    for metric, title in [('total_s', 'Complete process'), ('creation_s', 'All proof creation'),
                          ('leaf_creation_s', 'Base proof creation'), ('node_creation_s', 'Recursive merge')]:
        m = results[name]['metrics'][metric]
        lines.append(f"| {label} | {title} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/3 |")
lines += ['',
          'The individual word candidate slows all proof creation in all three pairs. The whole zero block candidate has a small positive median but its observed range includes regressions, and neither total nor creation reaches the predeclared threshold. Neither warrants the seven independent eight leaf confirmation pairs. The source patches are archived for reproducibility and are not installed in the accepted implementation.', '',
          'Each candidate first passed a separate complete certificate byte comparison. The three screen pairs also match every complete certificate digest, verification key, circuit shape, statement and proof geometry. Across both experiments, 16 serial timed processes produced 48 locally verified certificates. Python hashlib independently recomputed every statement. Source manifests match the corresponding isolated build, and admitted timing intervals do not overlap within either experiment.', '',
          'The individual word implementation passed all 77 native library tests and 44 PCS library tests, with one existing PCS test ignored. Those checks ran on the earlier candidate checkpoint; all relevant PCS, native, primitive, parallel and transcript Rust source hashes are checked against the matched candidate. The whole zero block variant separately passed the complete proof differential against dense reference openings. That differential includes zero, one and random witness words, a contiguous zero tail, overlapping supports and missing lanes at two rates.', '',
          'Yukon upstream was checked and pinned clean at 42e046241e0fe55ba34476c9d5310b5d2590843a. The runner hash is ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. Measurements use Rust 1.99.1, native CPU plus PCLMUL, CPUs 0 through 63, 32 workers, a 16 GiB sampled process budget and 40 GiB global reserve. Builds and tests use a 96 GiB budget and run outside timed series. The host is shared; these are local screens, not isolated machine records.', '',
          'Recursion.fast remains the primary performance target: base proof creation plus recursive merges, excluding setup and build. These small fixtures screen implementation ideas. The complete defined workload and formal native PCS/Flock composition remain open.']
(DEST / 'README.md').write_text('\n'.join(lines) + '\n')
verify = '''#!/usr/bin/env python3
"""Verify the published archive without extracting executable contents."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parent
archive=root/'raw-evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==(root/'archive.sha256').read_text().split()[0]
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    assert len({m.name for m in members})==len(members)
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    expected=json.load(tar.extractfile('archive-manifest.json'))
    assert set(expected)=={m.name for m in members}-{'archive-manifest.json'}
    for name,digest in expected.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest,name
    assert (root/'results.json').read_bytes()==tar.extractfile('results.json').read()
r=json.loads((root/'results.json').read_text())
assert r['ok'] and not r['retained'] and r['proof_bytes_identical']
assert r['processes']==16 and r['certificates']==48
print(json.dumps({'ok':True,'archive_files':len(expected),'processes':r['processes'],'certificates':r['certificates']}))
'''
(DEST / 'verify-archive.py').write_text(verify)
files = {p.name: p.read_bytes() for p in DEST.iterdir() if p.is_file() and p.name not in [
    'raw-evidence.tar.gz', 'archive.sha256', 'archive-check.json']}
for p in [B / 'publish-opening-screens.py', B / 'run-opening-command.py',
          B / 'run-sparse-command.py', B / 'sparse-experiment.py',
          B / 'run-blockzero-command.py', B / 'blockzero-experiment.py']:
    files['scripts/' + p.name] = p.read_bytes()
for name in ['sparse', 'blockzero']:
    for p in (B / 'artifacts').glob(f'{name}*'):
        if p.is_file():
            files[str(p.relative_to(B))] = p.read_bytes()
        elif p.is_dir() and 'certificates' in p.name:
            for q in p.rglob('*.bin'):
                files[str(q.relative_to(B))] = q.read_bytes()
    p = B / f'artifacts/opening-{name}-matched-plan.json'
    files[str(p.relative_to(B))] = p.read_bytes()
    for pattern in [f'{name}-matched-*-build', f'{name}-equivalence-*-01', f'{name}-screen-*-0[123]']:
        for p in B.glob(pattern):
            for q in p.rglob('*'):
                if q.is_file():
                    files[str(q.relative_to(B))] = q.read_bytes()
for name in ['opening-sparse-tests', 'blockzero-targeted']:
    for p in (B / name).rglob('*'):
        if p.is_file():
            files[str(p.relative_to(B))] = p.read_bytes()
files['archive-manifest.json'] = json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(files.items())}, indent=2).encode()
with tarfile.open(DEST / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
(DEST / 'archive.sha256').write_text(hashlib.sha256((DEST / 'raw-evidence.tar.gz').read_bytes()).hexdigest() + '  raw-evidence.tar.gz\n')
print(json.dumps({'dest': str(DEST), 'archive_files': len(files), 'retained': False}))
