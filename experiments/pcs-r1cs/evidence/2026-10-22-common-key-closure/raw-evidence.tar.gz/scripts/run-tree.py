#!/usr/bin/env python3
from pathlib import Path
import os
import subprocess
import sys
base = Path(__file__).resolve().parent
label, *workload = sys.argv[1:]
tree = base / 'candidate'
binary = base / 'target/release/examples/closed_tree'
env = dict(os.environ, LEANVM_NUM_THREADS=os.environ.get('CLOSURE_THREADS', '32'))
args = ['python3', '/root/yukon-autoresearch/bin/bench-research.py', '--cwd', str(tree), '--out', str(base / label),
        '--budget-gib', '16', '--reserve-gib', '40', '--timeout-seconds', '600', '--cpus', ','.join(map(str, range(64)))]
for name in subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--', '*.rs', '*.toml', 'Cargo.lock'], cwd=tree, text=True).splitlines():
    args += ['--source', name]
args += ['--source', str(binary), '--source', str(Path(__file__).resolve()), '--', str(binary), *workload]
raise SystemExit(subprocess.run(args, env=env).returncode)
