use format_recursion::private_recursion::{self as recursive, Setup};
use fiat_shamir::merkle::hash_to_scalars;
use primitives::hash::hash;
fn main() {
 parallel::init();
 let leaf = recursive::leaf(&[0;32], 2).unwrap();
 let setup = Setup::new(leaf).unwrap();
 let mut kids=Vec::new();
 for i in 0..2u8 { let s=hash(&[i]); let t=recursive::leaf(&s,2).unwrap(); let p=setup.prove(&t,&recursive::outputs(&t)).unwrap(); kids.push((s,p)); }
 let node=recursive::node((&setup,&kids[0].0,&kids[0].1),(&setup,&kids[1].0,&kids[1].1)).unwrap();
 println!("leaf nodes={} node nodes={} setup vars={} shapes?", recursive::leaf(&[0;32],2).unwrap().nodes.len(), node.nodes.len(), setup.bridge.index.shape().0);
 println!("same setup prove node: {}", setup.prove(&node,&recursive::outputs(&node)).is_some());
 let setup2=Setup::new(node).unwrap();
 let p2=setup2.prove(&recursive::node((&setup,&kids[0].0,&kids[0].1),(&setup,&kids[1].0,&kids[1].1)).unwrap(), &recursive::outputs(&node)).is_some();
 println!("setup2 prove same node: {} shape={:?}",p2, setup2.bridge.index.shape());
}
