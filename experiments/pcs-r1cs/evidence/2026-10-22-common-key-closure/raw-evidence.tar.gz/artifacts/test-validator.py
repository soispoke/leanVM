import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

BASE=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('validator',BASE/'artifacts/validate-closed-tree.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
original_path=BASE/'closure-baseline-2-01/run-00/stdout.log'
original_events=[json.loads(x) for x in original_path.read_text().splitlines() if x.startswith('{')]
original_receipt=json.loads((original_path.parent.parent/'result.json').read_text())

class ValidatorControls(unittest.TestCase):
    def fixture(self,events,receipt=None,rebind=True):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name);(root/'run-00').mkdir()
        path=root/'run-00/stdout.log';path.write_text(''.join(json.dumps(e)+'\n' for e in events))
        receipt=copy.deepcopy(original_receipt if receipt is None else receipt)
        if rebind:receipt['runs'][0]['stdout_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        (root/'result.json').write_text(json.dumps(receipt))
        return path
    def test_positive(self):
        self.assertEqual(v.check(self.fixture(original_events))['proofs'],3)
    def test_semantic_rejections(self):
        mutations=[
          lambda e:e.pop(-1),
          lambda e:e.insert(2,copy.deepcopy(e[1])),
          lambda e:e[1]['statement'].__setitem__(0,e[1]['statement'][0]^1),
          lambda e:e[1]['start'].__setitem__(0,e[1]['start'][0]^1),
          lambda e:e[-2]['statement'].__setitem__(0,e[-2]['statement'][0]^1),
          lambda e:e[-1]['root'].__setitem__(0,e[-1]['root'][0]^1),
          lambda e:e[-1].__setitem__('height',0),
          lambda e:e[-1]['key'].__setitem__(0,e[-1]['key'][0]^1),
          lambda e:e[1].__setitem__('verified',False),
          lambda e:e[1].__setitem__('creation_s',float('nan')),
          lambda e:e[1].__setitem__('index',7),
          lambda e:e[1].__setitem__('height',1),
          lambda e:e[0].__setitem__('official_score',True),
        ]
        for mutation in mutations:
            events=copy.deepcopy(original_events);mutation(events)
            with self.subTest(mutation=mutation), self.assertRaises((AssertionError,KeyError,ValueError)):
                v.check(self.fixture(events))
    def test_receipt_rejections(self):
        for name in ('ok','files_unchanged'):
            receipt=copy.deepcopy(original_receipt);receipt[name]=False
            with self.subTest(name=name),self.assertRaises(AssertionError):v.check(self.fixture(original_events,receipt))
        with self.assertRaises(AssertionError):v.check(self.fixture(original_events,rebind=False))

if __name__=='__main__':unittest.main()
