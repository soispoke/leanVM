use bench::{Jemalloc, Plan};
use fiat_shamir::merkle::{hash, hash_to_scalars, Hash};
use format_recursion::private_recursion::{self, Setup};
use serde_json::json;

#[global_allocator]
static ALLOCATOR: Jemalloc = Jemalloc;

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let argument = |key: &str, default| {
        args.windows(2)
            .find(|pair| pair[0] == key)
            .map_or(default, |pair| pair[1].parse::<usize>().unwrap())
    };
    let leaves = argument("--leaves", 8);
    let chain = argument("--chain", 16);
    assert!(leaves.is_power_of_two() && leaves <= 256);
    parallel::init();
    let template = private_recursion::leaf(&[0; 32], chain).unwrap();
    let plan = Plan::new(1, 0);
    let (setup, setup_timing) = plan.measure_quiet(|_| Setup::new(template.clone()).unwrap());
    let public_for = |start: &Hash| {
        let trace = private_recursion::leaf(start, chain).unwrap();
        private_recursion::outputs(&trace)
    };
    println!("{}", json!({
        "kind":"setup", "leaves":leaves, "chain":chain,
        "setup_s":setup_timing.mean(), "key":format!("{:?}", setup.bridge.index.root),
        "native_rows":setup.bridge.verifier_shape().index.log_rows,
        "public_len":setup.bridge.verifier_shape().index.public_len,
        "proof_cap":private_recursion::PROOF_CAP,
    }));
    let mut proofs = Vec::new();
    for i in 0..leaves {
        let start = hash(&(i as u64 + 20261022).to_le_bytes());
        let witness = private_recursion::leaf(&start, chain).unwrap();
        let public = public_for(&start);
        let (proof, timing) = plan.measure_quiet(|_| setup.prove(&witness, &public).unwrap());
        assert!(setup.verify(&public, &proof));
        let bytes = private_recursion::encode(&proof).unwrap();
        println!("{}", json!({
            "kind":"leaf", "index":i, "creation_s":timing.mean(),
            "proof_bytes":bytes.len(), "stream_scalars":proof.stream.len(),
            "merkle_phases":proof.merkle.len(), "verified":true,
        }));
        proofs.push(proof);
    }
    println!("{}", json!({"kind":"complete", "proofs":proofs.len()}));
}
