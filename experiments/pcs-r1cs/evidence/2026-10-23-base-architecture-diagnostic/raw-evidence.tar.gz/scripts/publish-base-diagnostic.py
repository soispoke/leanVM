"""Audit and publish the isolated base circuit diagnostic without rerunning attempts."""
from pathlib import Path
from datetime import datetime
import hashlib
import io
import json
import math
import statistics
import tarfile

B = Path(__file__).resolve().parent
OUT = Path('/root/workspaces/mission-9abcee72/leanvm-opt/experiments/pcs-r1cs/evidence/2026-10-23-base-architecture-diagnostic')
assert not OUT.exists()
files = {}
receipts = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def retain(name, data):
    assert name not in files or files[name] == data, name
    files[name] = data


def read_json(path):
    return json.loads(path.read_text())


def load_receipt(label, success):
    folder = B / label
    r = read_json(folder / 'result.json')
    assert r['ok'] is success and len(r['runs']) == 1, label
    assert r['files_unchanged'], label
    for name in ['stdout', 'stderr']:
        log = folder / f'run-00/{name}.log'
        assert digest(log.read_bytes()) == r['runs'][0][name + '_sha256'], label
    for p in sorted(folder.rglob('*')):
        if p.is_file():
            retain(f'raw/{label}/{p.relative_to(folder)}', p.read_bytes())
    receipts[label] = r
    return r


def events(label):
    return [json.loads(s) for s in (B / label / 'run-00/stdout.log').read_text().splitlines() if s.startswith('{')]


original = read_json(B / 'artifacts/cheap-base-probe-results.json')
assert original['ok'] and not original['integrated_recursive_closure']
assert len(original['rows']) == 12
rows = []
proof_count = 0
identities = {}
for old in original['rows']:
    label = old['label']
    r = load_receipt(label, True)
    assert r['runs'][0]['ok']
    assert r['tooling_git']['revision'] == '42e046241e0fe55ba34476c9d5310b5d2590843a'
    es = events(label)
    setup, complete = es[0], es[-1]
    assert complete['status'] == 'locally_verified' and setup['official_score'] is False
    proofs = es[1:-1]
    leaves = [p for p in proofs if p.get('level', 0) == 0]
    assert len(leaves) == 2
    chain = setup['chain']
    found = {}
    for p in leaves:
        start = hashlib.blake2s((p['index'] + 20261022).to_bytes(8, 'little')).digest()
        assert bytes(p['start']) == start
        for _ in range(chain):
            start = hashlib.blake2s(b'\x43' + start).digest()
        expected = hashlib.blake2s(b'\x4c' + start + chain.to_bytes(8, 'little')).digest()
        assert bytes(p['statement']) == expected and p['verified'] is True
        found[p['index']] = expected
    if old['variant'] == 'control':
        assert len(proofs) == 3
        parent = hashlib.blake2s(b'\x4e' + found[0] + found[1]).digest()
        assert bytes(proofs[-1]['statement']) == parent == bytes(complete['root'])
        assert proofs[-1]['verified'] is True and proofs[-1]['height'] == 1
    else:
        assert len(proofs) == 2 and complete['proofs'] == 2
    signature = (setup['key'], [{k: p[k] for k in [
        'index', 'statement', 'certificate_bytes', 'certificate_digest', 'stream_scalars', 'merkle_phases']} for p in proofs])
    ident = (chain, old['variant'])
    if ident in identities:
        assert identities[ident] == signature, ident
    identities[ident] = signature
    base_s = sum(p['creation_s'] for p in leaves)
    assert base_s == old['base_creation_s']
    assert [p['creation_s'] for p in leaves] == old['per_base_s']
    assert [p['certificate_bytes'] for p in leaves] == old['base_proof_bytes']
    shape = {k: setup[k] for k in old['shape']}
    assert shape == old['shape']
    rows.append(dict(old, all_creation_s=sum(p['creation_s'] for p in proofs),
                     merge_creation_s=sum(p['creation_s'] for p in proofs if p.get('level', 0)),
                     root_bytes=proofs[-1]['certificate_bytes'],
                     root_verification_s=proofs[-1]['verification_s']))
    proof_count += len(proofs)
    manifest_name = 'sparse-control-build.json' if old['variant'] == 'control' else 'cheap-base-v1-build.json'
    manifest = read_json(B / 'artifacts' / manifest_name)
    measured = {str(Path(p).relative_to(r['cwd'])): h for p, h in r['file_sha256_before'].items()
                if Path(p).is_relative_to(r['cwd'])}
    assert measured == manifest['sources']
    assert r['file_sha256_before'][r['command'][0]] == manifest['binary_sha256']

for s in original['summary']:
    selected = [r for r in rows if (r['chain'], r['variant']) == (s['chain'], s['variant'])]
    assert len(selected) == s['trials'] == 3
    assert statistics.median(r['base_creation_s'] for r in selected) == s['two_base_creation_s']
    assert statistics.median(r['base_creation_s'] / 2 for r in selected) == s['mean_per_base_s']

intervals = sorted((datetime.fromisoformat(receipts[r['label']]['started_utc']),
                    datetime.fromisoformat(receipts[r['label']]['finished_utc'])) for r in rows)
assert all(end <= later for (_, end), (later, _) in zip(intervals, intervals[1:]))
failed_memory = load_receipt('cheap-base-probe-control-c16384-t1', False)
assert failed_memory['runs'][0]['stop_reason'] == 'sampled process-group RSS budget'
assert not any(e.get('kind') == 'proof' for e in events('cheap-base-probe-control-c16384-t1'))
vm_failure = load_receipt('vm-common-full-length-c16384-t1', False)
assert vm_failure['runs'][0]['returncode'] == 101
vm_events = events('vm-common-full-length-c16384-t1')
assert len(vm_events) == 3 and all(p['verified'] for p in vm_events[1:])
assert 'ChildOutOfRange { log_committed: 30 }' in (B / 'vm-common-full-length-c16384-t1/run-00/stderr.log').read_text()
scaffold = load_receipt('leaf-architecture-build', False)
assert scaffold['runs'][0]['returncode'] != 0
load_receipt('cheap-base-build', True)
load_receipt('hash-packing-census-build', True)
load_receipt('hash-packing-census-count', True)
load_receipt('hash-packing-census-clippy', True)
census = events('hash-packing-census-count')
assert [e['chain'] for e in census] == [0, 1, 2, 16, 256]
for e in census:
    assert e['arithmetic_rows'] == 781 + 774 * e['chain']
    assert e['boolean_rows'] == 256 * (e['chain'] + 1)
    assert e['witness_satisfied']
full_rows = 781 + 774 * 16384
full_connectors = math.ceil((128 + full_rows) / 32768) * 32768
assert full_connectors == next(s for s in original['summary'] if s['chain'] == 16384 and s['variant'] == 'specialized')['shape']['connector_start']

for name in ['cheap-base-probe.py', 'cheap-base-probe-continuation.py', 'run-cheap-base-command.py',
             'vm-full-length-probe.py', 'run-base-census-command.py', 'publish-base-diagnostic.py']:
    retain('scripts/' + name, (B / name).read_bytes())
for name in ['cheap-base-probe-results.json', 'cheap-base-probe-progress.json', 'cheap-base-v1-build.json',
             'sparse-control-build.json', 'common-comparison-vm-build.json', 'cheap-base-architecture-plan.json',
             'hash-packing-census-build.json']:
    retain('artifacts/' + name, (B / 'artifacts' / name).read_bytes())
for p in sorted((B / 'artifacts/leaf-only-initial-scaffold').rglob('*')):
    if p.is_file():
        retain('initial-scaffold/' + str(p.relative_to(B / 'artifacts/leaf-only-initial-scaffold')), p.read_bytes())
for p in sorted((B / 'artifacts').glob('*cheap-base*controller.log')):
    retain('artifacts/' + p.name, p.read_bytes())
retain('artifacts/vm-full-length-probe-controller.log', (B / 'artifacts/vm-full-length-probe-controller.log').read_bytes())

# Preserve all successful observed source bytes, deduplicated by content hash.
# Failed historical attempts retain their original manifests even if a scaffold moved.
source_maps = {}
binary_omissions = {}
for label, r in receipts.items():
    if not r['ok']:
        continue
    source_maps[label] = {}
    for path, h in r['file_sha256_before'].items():
        data = Path(path).read_bytes()
        assert digest(data) == h, path
        if b'\0' in data[:4096]:
            binary_omissions[path] = h
            continue
        name = 'source-blobs/' + h
        retain(name, data)
        source_maps[label][path] = name
    tooling = B.parent / ('yukon-latest-1834430' if label.startswith('hash-packing') else 'yukon-latest-42e0462')
    runner = (tooling / 'bin/bench-research.py').read_bytes()
    assert digest(runner) == r['harness_sha256']
    retain('tooling/' + r['harness_sha256'] + '/bench-research.py', runner)
retain('source-maps.json', (json.dumps(source_maps, indent=2) + '\n').encode())
retain('binary-omissions.json', (json.dumps(binary_omissions, indent=2) + '\n').encode())

result = dict(original, rows=rows, census=census, census_full_length_rows_extrapolation=full_rows,
              audited_complete_processes=len(rows), audited_certificates=proof_count,
              whole_tree_speedup_established=False, retained_proving_change=False,
              vm_comparison={'status':'failed', 'reason':'ChildOutOfRange { log_committed: 30 }',
                             'completed_leaves':2, 'complete_trees':0, 'rerun':False},
              next_actions=['Reduce bit packing and private chain connection overhead without changing tagged hash semantics.',
                            'Integrate specialized base verification with one recursively reused node key, and measure all merges.',
                            'Extend the VM adapter dispatch range with correctness checks before a fresh full length comparison.'],
              goal_status='active')
result_bytes = (json.dumps(result, indent=2) + '\n').encode()
retain('results.json', result_bytes)
manifest = {name:digest(data) for name,data in files.items()}
retain('archive-manifest.json', (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode())
OUT.mkdir()
(OUT / 'results.json').write_bytes(result_bytes)
with tarfile.open(OUT / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = 0
        tar.addfile(entry, io.BytesIO(data))
(OUT / 'archive.sha256').write_text(digest((OUT / 'raw-evidence.tar.gz').read_bytes()) + '  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True, 'path':str(OUT), 'members':len(files), 'proofs':proof_count,
                  'census_extra_rows_per_hash':774, 'vm_failure_reconciled':True}))
