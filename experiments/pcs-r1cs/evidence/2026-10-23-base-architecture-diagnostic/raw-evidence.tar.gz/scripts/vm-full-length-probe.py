"""Diagnostic full length VM comparison; independent serial medians, not paired gains."""
from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess

B = Path(__file__).resolve().parent
Y = B.parent / 'yukon-latest-42e0462/bin/bench-research.py'
manifest = json.loads((B / 'artifacts/common-comparison-vm-build.json').read_text())
exe = B / 'artifacts/bin/vm-common'
tree = B / 'vm-common'
assert hashlib.sha256(exe.read_bytes()).hexdigest() == manifest['binary_sha256']
rows = []
for trial in range(1, 4):
    label = f'vm-common-full-length-c16384-t{trial}'
    assert not (B / label).exists()
    args = ['python3', str(Y), '--cwd', str(tree), '--out', str(B / label), '--budget-gib', '96',
            '--reserve-gib', '40', '--timeout-seconds', '600', '--cpus', ','.join(map(str, range(64)))]
    for name in manifest['sources']:
        args += ['--source', name]
    args += ['--source', str(exe), '--source', str(Path(__file__).resolve()), '--', str(exe),
             '--chain', '16384', '--depth', '1']
    subprocess.run(args, env=dict(os.environ, LEANVM_NUM_THREADS='32'), check=True)
    r = json.loads((B / label / 'result.json').read_text())
    assert r['ok'] and r['files_unchanged'] and r['runs'][0]['ok']
    for p, h in manifest['sources'].items():
        assert r['file_sha256_before'][str(tree / p)] == h
    assert r['file_sha256_before'][str(exe)] == manifest['binary_sha256']
    events = [json.loads(s) for s in (B / label / 'run-00/stdout.log').read_text().splitlines() if s.startswith('{')]
    setup, complete = events[0], events[-1]
    proofs = events[1:-1]
    assert len(proofs) == 3 and setup['chain'] == 16384 and setup['depth'] == 1
    assert complete['status'] == 'locally_verified' and setup['key'] == complete['key']
    found = {}
    for p in proofs:
        if p['level'] == 0:
            start = hashlib.blake2s((p['index'] + 20261022).to_bytes(8, 'little')).digest()
            assert bytes(p['start']) == start
            for _ in range(16384):
                start = hashlib.blake2s(b'\x43' + start).digest()
            expected = hashlib.blake2s(b'\x4c' + start + (16384).to_bytes(8, 'little')).digest()
        else:
            expected = hashlib.blake2s(b'\x4e' + found[0, 0] + found[0, 1]).digest()
        assert p['verified'] is True and bytes(p['statement']) == expected
        found[p['level'], p['index']] = expected
    assert bytes(complete['root']) == found[1, 0]
    row = {'label': label, 'base_creation_s': sum(p['creation_s'] for p in proofs if not p['level']),
           'merge_creation_s': proofs[-1]['creation_s'], 'all_creation_s': sum(p['creation_s'] for p in proofs),
           'root_verification_s': proofs[-1]['verification_s'], 'root_bytes': proofs[-1]['certificate_bytes'],
           'key': setup['key'], 'geometry': [{k: p[k] for k in [
               'level', 'index', 'statement', 'certificate_bytes', 'certificate_digest', 'base_cycles', 'padded_cycles']} for p in proofs],
           'setup_s': setup['setup_s'], 'process_s': r['runs'][0]['wall_seconds'],
           'peak_rss_bytes': r['runs'][0]['sampled_group_peak_rss_bytes']}
    rows.append(row)
    print(json.dumps({k: row[k] for k in row if k not in ['key', 'geometry']}), flush=True)
    (B / 'artifacts/vm-full-length-probe-progress.json').write_text(json.dumps(rows, indent=2) + '\n')
assert all((r['key'], r['geometry']) == (rows[0]['key'], rows[0]['geometry']) for r in rows)
result = {'ok': True, 'leaves': 2, 'chain': 16384, 'trials': 3, 'scope': 'Full length diagnostic, not the256 leaf official workload',
          'summary': {k: statistics.median(r[k] for r in rows) for k in [
              'base_creation_s', 'merge_creation_s', 'all_creation_s', 'root_verification_s', 'root_bytes',
              'setup_s', 'process_s', 'peak_rss_bytes']}, 'rows': rows}
(B / 'artifacts/vm-full-length-probe-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['summary'], indent=2))
