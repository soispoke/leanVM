"""Compare base creation only; specialized base proofs are not integrated yet."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

B = Path(__file__).resolve().parent
Y = B.parent / 'yukon-latest-42e0462/bin/bench-research.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_map(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root)}


def receipt(label):
    r = json.loads((B / label / 'result.json').read_text())
    assert r['ok'] and r['files_unchanged'] and len(r['runs']) == 1
    assert r['runs'][0]['ok'] and r['tooling_git']['revision'] == '42e046241e0fe55ba34476c9d5310b5d2590843a'
    for name in ['stdout', 'stderr']:
        assert sha(B / label / f'run-00/{name}.log') == r['runs'][0][name + '_sha256']
    return r


build = receipt('cheap-base-build')
binary = B / 'artifacts/bin/cheap-base-v1'
assert not binary.exists()
shutil.copy2(B / 'target-vm-common/release/examples/cheap_base', binary)
manifest = {'build_receipt_sha256': sha(B / 'cheap-base-build/result.json'),
            'binary_sha256': sha(binary), 'sources': source_map(build)}
(B / 'artifacts/cheap-base-v1-build.json').write_text(json.dumps(manifest, indent=2) + '\n')
control = json.loads((B / 'artifacts/sparse-control-build.json').read_text())
rows = []
for chain in [16, 16384]:
    for trial in range(1, 4):
        for variant in (['control', 'specialized'] if trial % 2 else ['specialized', 'control']):
            label = f'cheap-base-probe-{variant}-c{chain}-t{trial}'
            assert not (B / label).exists()
            tree = B / ('opening-control' if variant == 'control' else 'leaf-architecture-candidate')
            exe = B / ('artifacts/bin/opening-control' if variant == 'control' else 'artifacts/bin/cheap-base-v1')
            expected = control if variant == 'control' else manifest
            args = ['python3', str(Y), '--cwd', str(tree), '--out', str(B / label),
                    '--budget-gib', '16', '--reserve-gib', '40', '--timeout-seconds', '600',
                    '--cpus', ','.join(map(str, range(64)))]
            for name in expected['sources']:
                args += ['--source', name]
            args += ['--source', str(exe), '--source', str(Path(__file__).resolve()),
                     '--source', str(B / 'artifacts/cheap-base-architecture-plan.json'),
                     '--', str(exe), '--chain', str(chain)]
            args += ['--depth', '1'] if variant == 'control' else ['--leaves', '2']
            subprocess.run(args, env=dict(os.environ, LEANVM_NUM_THREADS='32'), check=True)
            r = receipt(label)
            assert source_map(r) == expected['sources']
            assert sha(exe) == expected['binary_sha256'] == r['file_sha256_before'][str(exe)]
            events = [json.loads(s) for s in (B / label / 'run-00/stdout.log').read_text().splitlines() if s.startswith('{')]
            setup, complete = events[0], events[-1]
            assert setup['kind'] == 'setup' and setup['chain'] == chain and setup['official_score'] is False
            assert complete['kind'] == 'complete' and complete['status'] == 'locally_verified'
            leaves = [p for p in events[1:-1] if p.get('level', 0) == 0]
            assert len(leaves) == 2
            for p in leaves:
                start = hashlib.blake2s((p['index'] + 20261022).to_bytes(8, 'little')).digest()
                assert bytes(p['start']) == start
                for _ in range(chain):
                    start = hashlib.blake2s(b'\x43' + start).digest()
                assert bytes(p['statement']) == hashlib.blake2s(b'\x4c' + start + chain.to_bytes(8, 'little')).digest()
                assert p['verified'] is True
            row = {'label': label, 'variant': variant, 'chain': chain, 'trial': trial,
                   'base_creation_s': sum(p['creation_s'] for p in leaves),
                   'per_base_s': [p['creation_s'] for p in leaves],
                   'base_verification_s': sum(p['verification_s'] for p in leaves),
                   'base_proof_bytes': [p['certificate_bytes'] for p in leaves],
                   'key': setup['key'], 'shape': {k: setup[k] for k in [
                       'native_rows', 'public_len', 'blocks', 'block_log', 'connector_start', 'q_offset', 'stack_log']},
                   'setup_s': setup['setup_s'], 'process_s': r['runs'][0]['wall_seconds'],
                   'peak_rss_bytes': r['runs'][0]['sampled_group_peak_rss_bytes']}
            rows.append(row)
            (B / 'artifacts/cheap-base-probe-progress.json').write_text(json.dumps(rows, indent=2) + '\n')
            print(json.dumps({k: row[k] for k in ['label', 'base_creation_s', 'base_proof_bytes', 'shape']}), flush=True)
summary = []
for chain in [16, 16384]:
    for variant in ['control', 'specialized']:
        selected = [r for r in rows if r['chain'] == chain and r['variant'] == variant]
        assert all((r['key'], r['shape'], r['base_proof_bytes']) ==
                   (selected[0]['key'], selected[0]['shape'], selected[0]['base_proof_bytes']) for r in selected)
        summary.append({'chain': chain, 'variant': variant, 'trials': 3,
                        'two_base_creation_s': statistics.median(r['base_creation_s'] for r in selected),
                        'mean_per_base_s': statistics.median(r['base_creation_s'] / 2 for r in selected),
                        'base_proof_bytes': selected[0]['base_proof_bytes'], 'shape': selected[0]['shape']})
result = {'ok': True, 'integrated_recursive_closure': False,
          'scope': 'Specialized base creation diagnostic only; key, shape and proof geometry differ. No whole tree gain established.',
          'summary': summary, 'rows': rows}
(B / 'artifacts/cheap-base-probe-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(summary, indent=2))
