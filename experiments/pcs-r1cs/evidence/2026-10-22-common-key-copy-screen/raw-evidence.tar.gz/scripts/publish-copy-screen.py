from pathlib import Path
import datetime, hashlib, io, json, tarfile
import identity_audit as audit

b = Path(__file__).resolve().parent
repo = b / 'candidate'
dest = repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-copy-screen'
dest.mkdir(exist_ok=True)
s = audit.series('identity-chunk-screen', 'identity-chunk', 3)
assert all(s['metrics'][key]['paired_reduction_pct'] < 3 for key in ('total_s', 'creation_s'))
intervals = []
rows = [row for pair in s['rows'] for row in pair.values()]

def receipt(label):
    return json.loads((b / label / 'result.json').read_text())

def sources(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root) and p.endswith(('.rs', '.toml', 'Cargo.lock'))}

accepted = receipt('joint-target-joint-01')
assert sources(accepted) == sources(receipt('joint-release-build'))
assert accepted['file_sha256_before'][accepted['command'][0]] == hashlib.sha256((b / 'artifacts/bin/control-v5').read_bytes()).hexdigest()
for row in rows:
    label = Path(row['path']).parent.parent.name
    r = receipt(label)
    control = '-control-v5-' in label
    assert sources(r) == sources(receipt('joint-release-build' if control else 'identity-chunk-build-v2'))
    binary = r['command'][0]
    assert r['file_sha256_before'][binary] == hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    intervals.append((datetime.datetime.fromisoformat(r['started_utc']), datetime.datetime.fromisoformat(r['finished_utc'])))
intervals.sort()
assert all(a[1] <= z[0] for a, z in zip(intervals, intervals[1:]))
assert receipt('identity-chunk-native-v2')['ok']
for path, digest in sources(receipt('joint-release-build')).items():
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
report = {'ok': True, 'retained': False, 'reason': 'Small screen did not reach 3% in total or creation; no confirmation budget spent.',
          'all_sizes_shapes_keys_unchanged': True, 'processes': len(rows), 'certificates': sum(r['proofs'] for r in rows),
          'screen': s, 'baseline': 'f23eddd93d85de3d07342474e031ff619cbdc860',
          'latest_yukon': '1ffa172ef1ccec3fe91256bb733c060222805731',
          'runner_sha256': 'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e',
          'native_source_restored': True, 'excluded_prechecks': json.loads((b / 'artifacts/identity-chunk-excluded.json').read_text())}
(dest / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Native copy-fingerprint chunk screen', '',
         'Rejected increasing the parallel copy-fingerprint chunk width from 256 to 1024. The accepted hybrid opener at f23eddd9 remains unchanged.', '',
         'Three alternating two-leaf fresh-process pairs, chain16. Each process creates and locally verifies three certificates and rejects changed roots/heights. The callback chunk offset was updated consistently with its width in the measured candidate. Positive paired reductions mean faster.', '',
         '| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins |',
         '| --- | ---: | ---: | ---: | ---: |']
for name, key in (('Whole process', 'total_s'), ('All creation', 'creation_s'), ('Root creation', 'root_creation_s')):
    m = s['metrics'][key]
    lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/3 |")
lines += ['', 'The screen does not justify the frozen target retention threshold of at least 3% paired median total or creation improvement, 6/7 independent target wins, a positive bootstrap95 lower bound, and no companion regression over 1%. No eight-leaf confirmation was run. All exact keys, shapes, independently recomputed statements and per-position certificate sizes/scalar/Merkle-phase counts match the published common-key baseline.', '',
          'The corrected fingerprint test passes against the independent scalar reference, including zero, one and extension-field cells. A fresh release build passes. An initial width-only edit left the callback stride at256; its targeted test failed. The shell driver continued to a build, which was terminated and is excluded. The failed source patch, receipts and corrected patch are preserved. No timed observation was excluded.', '',
          'A prior proposed implicit identity-tree edit was abandoned at source preflight: the accepted code already uses vec![F192::ONE]. Its no-op test was removed without a performance claim. The chunk test was deliberately cheap: the traced copy-leaf stage was only about14ms, so large whole-prover gains were unlikely.', '',
          'Yukon upstream was checked at phase start and isolated at1ffa172ef1ccec3fe91256bb733c060222805731. Its current benchmark runner SHA256 remains ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. The new checked-build admission API is opt-in and has no qualified real runner here; the standard source-bound benchmark runner remains in use. No pipeline speedup is claimed for that API.', '',
          'Rust1.99.1, native CPU plus pclmulqdq, 32 workers, CPUs0-63, four Cargo jobs, serial timed jobs. Build/test budget96GiB, benchmark16GiB, host reserve40GiB. The shared Xeon Gold6230R host is not dedicated; RSS is sampled process-group memory, not cgroup isolation. Controls reuse the exact frozen hybrid executable after source/binary identity checks. Every timed receipt is bound to its exact source manifest, build and executable. The audit rejects overlapping recorded intervals and verifies that accepted Rust/Cargo sources were restored.', '',
          'The archive contains both source patches, exact commands, raw logs, source/binary hashes, plan, failed checks and passing replacement receipts. Run python3 verify-archive.py here for integrity without extraction. This is local performance evidence, not official recursion.fast certification or a formal composition/security proof. The optimization goal remains active.', '']
(dest / 'README.md').write_text('\n'.join(lines))
(dest / 'verify-archive.py').write_bytes((repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-hybrid-opening/verify-archive.py').read_bytes())
files = {name: (dest / name).read_bytes() for name in ('README.md', 'results.json', 'verify-archive.py')}
for label in ('joint-release-build', 'joint-target-joint-01'):
    files[f'control-reuse/{label}.json'] = (b / label / 'result.json').read_bytes()
for root in b.glob('identity*'):
    if root.is_dir():
        for p in root.rglob('*'):
            if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in (b / 'artifacts').glob('identity*'):
    if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in b.glob('*.py'): files['scripts/' + p.name] = p.read_bytes()
files['artifacts/validate-closed-tree.py'] = (b / 'artifacts/validate-closed-tree.py').read_bytes()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}
files['archive-manifest.json'] = json.dumps(manifest, indent=2, sort_keys=True).encode()
with tarfile.open(dest / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name); info.size, info.mtime = len(data), 0
        tar.addfile(info, io.BytesIO(data))
(dest / 'archive.sha256').write_text(hashlib.sha256((dest / 'raw-evidence.tar.gz').read_bytes()).hexdigest() + '  raw-evidence.tar.gz\n')
print(json.dumps({'ok': True, 'retained': False, 'processes': report['processes'], 'certificates': report['certificates'], 'metrics': s['metrics']}))
