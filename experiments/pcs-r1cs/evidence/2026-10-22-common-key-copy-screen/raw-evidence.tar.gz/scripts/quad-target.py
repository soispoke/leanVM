from pathlib import Path
import importlib.util,json,subprocess
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=[]
for trial in range(1,8):
 pair={}
 for which in (('control-v2','quad') if trial%2 else ('quad','control-v2')):
  label=f'quad-target-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  subprocess.run(['python3',str(b/'run-next-variant.py'),which,label,'--depth','3','--chain','16'],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
 for key in ('key','shape','proof_geometry'):assert pair['control-v2'][key]==pair['quad'][key],key
 rows.append(pair);(b/'artifacts/quad-target.json').write_text(json.dumps(rows,indent=2))
 print('quad',trial,{k:pair[k]['total_s'] for k in pair},flush=True)
