"""Audit source-bound encoding experiments against the published common-key baseline."""
from pathlib import Path
import datetime,hashlib,importlib.util,io,json,random,statistics,tarfile
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
baseline=json.loads((b/'candidate/experiments/pcs-r1cs/evidence/2026-10-22-common-key-closure/results.json').read_text())
base={r['leaves']:r for r in baseline['baseline']}
rng=random.Random(20261022)
def series(prefix,variant,count):
 rows=[]
 for i in range(1,count+1):
  pair={name:v.check(b/f'{prefix}-{name}-{i:02d}/run-00/stdout.log') for name in ('control-v2',variant)}
  for key in ('key','shape','proof_geometry'):
   assert pair['control-v2'][key]==pair[variant][key]==base[pair['control-v2']['leaves']][key],(prefix,i,key)
  rows.append(pair)
 metrics={}
 for m in ('total_s','creation_s','root_creation_s','setup_s','verification_s','root_verification_s','cpu_s','peak_rss_bytes'):
  ratios=[100*(1-p[variant][m]/p['control-v2'][m]) for p in rows]
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(20000))
  metrics[m]={'control_median':statistics.median(p['control-v2'][m] for p in rows),'candidate_median':statistics.median(p[variant][m] for p in rows),'paired_reduction_pct':statistics.median(ratios),'wins':sum(x>0 for x in ratios),'paired_pct':ratios,'bootstrap95_pct':[boot[499],boot[19499]]}
 return {'prefix':prefix,'variant':variant,'pairs':count,'metrics':metrics,'rows':rows}
