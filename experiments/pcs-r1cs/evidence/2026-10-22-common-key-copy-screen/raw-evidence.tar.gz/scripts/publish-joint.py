"""Audit, report and seal the hybrid joint opening experiment."""
from pathlib import Path
import datetime, hashlib, io, json, tarfile
import joint_audit as audit

b = Path(__file__).resolve().parent
repo = b / 'candidate'
dest = repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-hybrid-opening'
dest.mkdir(exist_ok=True)
screen = audit.series('joint-screen', 'joint', 3)
target = audit.series('joint-target', 'joint', 7)
qualified = [m for m in ('total_s', 'creation_s') if
             target['metrics'][m]['paired_reduction_pct'] >= 3 and
             target['metrics'][m]['wins'] >= 6 and
             target['metrics'][m]['bootstrap95_pct'][0] > 0]
companion_ok = all(target['metrics'][m]['paired_reduction_pct'] >= -1 for m in ('total_s', 'creation_s'))
retain = bool(qualified) and companion_ok
rows = [row for series in (screen, target) for pair in series['rows'] for row in pair.values()]
diagnostics = [audit.v.check(b / label / 'run-00/stdout.log')
               for label in ('joint-current-trace', 'joint-candidate-trace')]

def receipt(label):
    return json.loads((b / label / 'result.json').read_text())

def sources(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root) and p.endswith(('.rs', '.toml', 'Cargo.lock'))}

accepted_control = receipt('factor-target-factor-01')
control_digest = accepted_control['file_sha256_before'][accepted_control['command'][0]]
assert sources(accepted_control) == sources(receipt('factor-release-build'))
assert hashlib.sha256((b / 'artifacts/bin/control-v4').read_bytes()).hexdigest() == control_digest
intervals = []
for row in rows + diagnostics:
    label = Path(row['path']).parent.parent.name
    r = receipt(label)
    is_control = '-control-v4-' in label or label == 'joint-current-trace'
    build = 'factor-release-build' if is_control else 'joint-release-build'
    assert sources(r) == sources(receipt(build)), label
    binary = r['command'][0]
    assert r['file_sha256_before'][binary] == hashlib.sha256(Path(binary).read_bytes()).hexdigest(), label
    intervals.append((datetime.datetime.fromisoformat(r['started_utc']),
                      datetime.datetime.fromisoformat(r['finished_utc']), label))
intervals.sort()
for a, z in zip(intervals, intervals[1:]):
    assert a[1] <= z[0], (a, z)
for row in diagnostics:
    for key in ('key', 'shape', 'proof_geometry'):
        assert row[key] == audit.base[row['leaves']][key], key
gates = {}
for label in ('joint-direct-test-v2', 'joint-full-pcs', 'joint-full-native',
              'joint-final-clippy', 'joint-publication-clippy', 'joint-final-proof-test',
              'joint-final-fmt', 'joint-final-doc', 'joint-final-exact-pcs',
              'joint-final-exact-native', 'joint-final-exact-fmt', 'joint-final-exact-doc'):
    r = receipt(label)
    assert r['ok'] and r['files_unchanged'], label
    gates[label] = {'ok': True, 'receipt_sha256': hashlib.sha256((b / label / 'result.json').read_bytes()).hexdigest()}
publication = json.loads((b / 'artifacts/joint-publication-build-identity.json').read_text())
assert publication['identical']
assert publication['frozen_binary_sha256'] == hashlib.sha256((b / 'artifacts/bin/joint').read_bytes()).hexdigest()
assert receipt('joint-publication-build-v2')['ok'] and receipt('joint-publication-build-v2')['files_unchanged']
for path, digest in sources(receipt('joint-publication-build-v2')).items():
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
report = {'ok': True, 'retain_joint': retain, 'qualifying_metrics': qualified, 'companion_ok': companion_ok,
          'screen': screen, 'target': target, 'diagnostics': diagnostics, 'validation': gates,
          'publication_build_identity': publication,
          'all_sizes_shapes_keys_unchanged': True, 'processes': len(rows) + len(diagnostics),
          'certificates': sum(r['proofs'] for r in rows + diagnostics),
          'baseline': 'a77bfd850441af53b8db8d2333e37a0e849a7bfe',
          'latest_yukon': '77d22d1cf5796fa7ec8d94bfe675967afd680c80',
          'runner_sha256': 'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e',
          'scope': 'Local performance and exact-proof implementation evidence; formal composition security and official recursion.fast certification remain open.',
          'rule': 'At least 3% paired median improvement in total or creation, at least 6/7 target wins, positive bootstrap 95% lower bound, no companion regression over 1%, exact keys/shapes/statements/proof geometry.'}
(dest / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Common-key hybrid joint opening', '',
         ('Retained hybrid weights and lazy witness folding for joint opening.' if retain else
          'Rejected the hybrid joint opener under the predeclared retention rule.'), '',
         'The control is the accepted factored-index implementation at a77bfd85. These are chain16 local fixtures, not shielded transfers or new matched leanVM/Flock comparisons. Prover execution changes; keys, circuit shapes, security settings, verifier, transcript order and proof encoding are unchanged.', '',
         '## Mechanism and checks', '',
         'The opener keeps ring-switch and strided weights dense only over the aligned ring support. Point claims are grouped by their equality-table prefix and within-lane offset, with batching powers accumulated in lane coefficients. Small point supports stay small rather than becoming padded full-lane tables. Strided claims outside the ring support use the previous dense path.', '',
         'The first sumcheck rounds fold only the dense support and its corresponding witness. Once that support reaches one lane, each newly encountered partner is folded directly from the original base-field witness using the same challenge prefix. These partner groups are disjoint. The resulting witness includes every committed lane, including lanes with zero initial weight, since those lanes contribute cross terms after challenges. Point messages and dense-support messages are added before each unchanged transcript challenge. Both weight families merge into the original WHIR state after the lane rounds.', '',
         'The dense-reference regression compares the complete Proof object, including scalars and Merkle phases, at rates 1 and 4. It covers full and truncated lane sets, single-lane and multi-lane dense supports, nonzero support offsets, overlapping point supports, missing partner lanes and zero tails. The basis test independently reconstructs combined weights from point/strided definitions and compares every field element. All 44 PCS tests pass, with one pre-existing ignored test, and all 77 native release tests pass, including adversarial composition checks.', '',
         '## Two-leaf screen', '',
         'Three alternating fresh-process pairs. Positive paired reductions mean faster; percentages are medians of paired ratios, not ratios of independent medians.', '',
         '| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins |',
         '| --- | ---: | ---: | ---: | ---: |']
for name, key in (('Whole process', 'total_s'), ('All creation', 'creation_s'), ('Root creation', 'root_creation_s')):
    m = screen['metrics'][key]
    lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/3 |")
lines += ['', '## Independent eight-leaf confirmation', '',
          'Seven fresh alternating pairs, each process creating and locally verifying all 15 certificates. Total includes setup, every creation, explicit verification, reporting/serialization and wrong-root/height rejection. Creation includes recording, child prechecks, witness preparation and proving. Timed jobs are serial.', '',
          '| Measure | Control median | Candidate median | Paired reduction | Wins | Bootstrap 95% interval |',
          '| --- | ---: | ---: | ---: | ---: | ---: |']
for name, key in (('Whole process (s)', 'total_s'), ('All creation (s)', 'creation_s'),
                  ('Root creation (s)', 'root_creation_s'), ('Setup (s)', 'setup_s'),
                  ('Sampled peak RSS (GiB)', 'peak_rss_bytes')):
    m = target['metrics'][key]
    scale = 2**30 if key == 'peak_rss_bytes' else 1
    lo, hi = m['bootstrap95_pct']
    lines.append(f"| {name} | {m['control_median']/scale:.3f} | {m['candidate_median']/scale:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/7 | [{lo:+.2f}, {hi:+.2f}]% |")
lines += ['', f"Decision: {'retain' if retain else 'reject'}. {report['rule']}", '',
          'Every key, shape, independently recomputed statement and per-position certificate length, scalar count and Merkle phase count matches both variants and the published common-key baseline. The two diagnostic tracing processes are excluded from timing medians and included in the provenance/geometry audit.', '',
          '## Provenance and limits', '',
          'Yukon was checked against upstream and pinned in an isolated checkout at 77d22d1cf5796fa7ec8d94bfe675967afd680c80. Its benchmark runner is unchanged, SHA256 ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. The offline advisor correctly withheld isolated utility because the input profile was warm-cache evidence. Selection was a research hypothesis, and direct paired runs determine retention.', '',
          'The control reuses the exact frozen executable from factor-release-build, with normalized Rust/Cargo source hashes checked against control-v4 and the executable hash matched to the accepted factor measurement. Rust 1.99.1, native CPU plus pclmulqdq flags, 32 workers, CPUs 0-63, four Cargo jobs. Build/test budget 96 GiB, benchmark budget 16 GiB, host reserve 40 GiB. This Xeon Gold 6230R host is shared. RSS is sampled process-group memory, not cgroup isolation.', '',
          'Clippy with tests/examples and warnings denied, formatting and strict rustdoc pass. No platform-specific source changed. An initial compile failed on Rust borrow errors and its receipt is preserved; the corrected differential test and full suites pass. Formatting receipts report a mutation because cargo fmt changed source bytes. No timed observation was excluded. An initial control-reuse helper used a wrong JSON key and stopped before copying; the corrected helper verified 239 source files. No interrupted old PGO job was restarted.', '',
          'A post-measurement attempt to correct a comment and strengthen test-only coverage failed the binary identity gate: its fresh release executable differed. That publication attempt was rejected. The exact measured source bytes were restored and checked against the measured source manifest, then rebuilt. The publication build matches the frozen benchmark executable exactly. The strengthened test passed before restoration, but publication retains the exact measured implementation and tests. The archive preserves both build receipts and the explicit hash comparison.', '',
          'The archive retains source and binary hashes, exact commands and tool identities, raw stdout/stderr, predeclared acceptance criteria, candidate patch, check failures and build/check receipts. The audit binds every measured process to its exact build and frozen binary and rejects overlapping recorded intervals. Executables and compiler caches are excluded. Run python3 verify-archive.py here to check archive member hashes without extraction.', '',
          'Reproduce through current Yukon: build closed_tree with the recorded Rust flags, then run frozen control/candidate executables at --depth 1 --chain 16 and --depth 3 --chain 16 in the recorded alternating order using fresh output paths. This is conditional bounded-height implementation closure; the formal composition/security proof and official recursion.fast integration remain open. The optimization goal remains active.', '']
(dest / 'README.md').write_text('\n'.join(lines))
(dest / 'verify-archive.py').write_bytes((repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-factored-index/verify-archive.py').read_bytes())
files = {name: (dest / name).read_bytes() for name in ('README.md', 'results.json', 'verify-archive.py')}
files['control-reuse/accepted-factor-measurement.json'] = (b / 'factor-target-factor-01/result.json').read_bytes()
for root in [*b.glob('joint-*'), b / 'factor-release-build']:
    if root.is_dir():
        for p in root.rglob('*'):
            if p.is_file():
                files[str(p.relative_to(b))] = p.read_bytes()
for p in (b / 'artifacts').glob('joint*'):
    if p.is_file():
        files[str(p.relative_to(b))] = p.read_bytes()
for name in ('EXPERIMENTS.md', 'validate-closed-tree.py'):
    files['artifacts/' + name] = (b / 'artifacts' / name).read_bytes()
for p in b.glob('*.py'):
    files['scripts/' + p.name] = p.read_bytes()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}
files['archive-manifest.json'] = json.dumps(manifest, sort_keys=True, indent=2).encode()
with tarfile.open(dest / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(data), 0
        tar.addfile(info, io.BytesIO(data))
(dest / 'archive.sha256').write_text(hashlib.sha256((dest / 'raw-evidence.tar.gz').read_bytes()).hexdigest() + '  raw-evidence.tar.gz\n')
print(json.dumps({'ok': True, 'retain_joint': retain, 'metrics': target['metrics'],
                  'processes': report['processes'], 'certificates': report['certificates'], 'archive_files': len(manifest)}))
