"""Seal the witness-extension screen and held-out wider-reduction experiment."""
from pathlib import Path
import datetime,hashlib,io,json,tarfile
import followup_audit as audit
b=Path(__file__).resolve().parent
repo=b/'candidate';dest=repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-quad-reduction'
dest.mkdir(exist_ok=True)
screens=[audit.series('extension-screen','extension',3),audit.series('quad-screen','quad',3)]
target=audit.series('quad-target','quad',7)
qualified=[m for m in ('total_s','creation_s') if target['metrics'][m]['paired_reduction_pct']>=3 and target['metrics'][m]['wins']>=6 and target['metrics'][m]['bootstrap95_pct'][0]>0]
companion_ok=all(target['metrics'][m]['paired_reduction_pct']>=-1 for m in ('total_s','creation_s'))
retain=bool(qualified) and companion_ok
rows=[row for series in screens+[target] for pair in series['rows'] for row in pair.values()]
def receipt(label):return json.loads((b/label/'result.json').read_text())
def sources(r):
 root=Path(r['cwd']);return {str(Path(p).relative_to(root)):h for p,h in r['file_sha256_before'].items() if Path(p).is_relative_to(root) and p.endswith(('.rs','.toml','Cargo.lock'))}
intervals=[]
for row in rows:
 r=json.loads((Path(row['path']).parent.parent/'result.json').read_text());label=Path(row['path']).parent.parent.name
 build='extension-baseline-build' if '-control-v2-' in label else 'quad-release-build' if label.startswith('quad-') else 'extension-release-build'
 assert sources(r)==sources(receipt(build)),label
 binary=r['command'][0]
 assert r['file_sha256_before'][binary]==hashlib.sha256(Path(binary).read_bytes()).hexdigest(),label
 start=datetime.datetime.fromisoformat(r['started_utc']);intervals.append((start,start+datetime.timedelta(seconds=r['median_wall_seconds']),label))
intervals.sort()
for a,z in zip(intervals,intervals[1:]):assert a[1]<=z[0],(a,z)
gates={}
if retain:
 for label in ('quad-native-tests','quad-final-pcs','quad-final-clippy','quad-final-fmt','quad-final-doc','quad-final-x86-avx512','quad-final-x86-vpclmul-avx2','quad-final-x86-vpclmul-only','quad-final-x86-pclmul-only'):
  r=receipt(label);assert r['ok'] and r['files_unchanged'],label;gates[label]={'ok':True,'receipt_sha256':hashlib.sha256((b/label/'result.json').read_bytes()).hexdigest()}
report={'ok':True,'retain_quad':retain,'qualifying_metrics':qualified,'companion_ok':companion_ok,'screens':screens,'target':target,'validation':gates,'all_sizes_shapes_keys_unchanged':True,'processes':len(rows),'certificates':sum(r['proofs'] for r in rows),'baseline':'c22831cf64a8126416e89f1e963ae6e949c0c27a','latest_yukon':'83ae1385bfcc5c93f26d117c65f42984cf711028','runner_sha256':'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e','scope':'Local performance evidence, not formal soundness or official benchmark certification.','excluded':['extension-native-tests'],'exclusion_reason':'An edit used the workspace root instead of the candidate path and failed before mutation. An unintended check started, then source changed; that first check was terminated. The correctly bound replacement check extension-native-tests2 completed all76native tests. No benchmark used the excluded attempt.','rule':'At least3% paired median reduction in total or all creation, at least6/7 target wins, positive paired bootstrap95% interval and no companion regression over1%; exact key,shape,statements,per-position certificate lengths/scalars/Merkle phases.'}
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Common-key witness and wider-reduction research','',('Retained the four-element PCLMUL/AVX2 reduction after seven independent eight-leaf pairs.' if retain else 'No additional code change met the predeclared retention rule.'),'','The control is the previously accepted [two-element kernel](../2026-10-22-common-key-encoding-search/README.md), source c22831cf. Measurements below compare fresh controls and candidates within each pair. They do not establish a new matched comparison against leanVM or Flock. Chain16 leaves use the same common circuit at every level.','','## Two-leaf screens','','Three alternating fresh-process pairs, three certificates per process. Positive paired reductions mean faster; paired ratios and independent medians are different statistics.','','| Candidate | Total control / candidate (s) | Total reduction | All creation reduction | Root creation reduction |','| --- | ---: | ---: | ---: | ---: |']
for title,series in zip(('Parallel connector products','Four-element AVX2 reduction'),screens):
 m=series['metrics'];t=m['total_s'];lines.append(f"| {title} | {t['control_median']:.3f} / {t['candidate_median']:.3f} | {t['paired_reduction_pct']:+.2f}% ({t['wins']}/3 wins) | {m['creation_s']['paired_reduction_pct']:+.2f}% | {m['root_creation_s']['paired_reduction_pct']:+.2f}% |")
lines+=['','Parallel connector products replaced the serial helper-value loop with a flat map_collect over independent group/block pairs. It retained full F192 arithmetic and passed all 76 native tests, including malformed connector-limb rejection. The added temporary vector and dispatch did not produce a whole-workload gain; the patch was rejected and restored.','','The retained kernel still uses scalar carry-less multiply instructions, so it works on this host without VPCLMULQDQ. Four products are packed into low/high AVX2 vectors and reduced together by shifts and XORs. The two-element kernel handles pairs and non-AVX2 hosts, and scalar arithmetic handles an odd tail. Existing VPCLMUL and ARM paths are unchanged. Encoder scalar-reference tests cover odd and non-power-of-two lane counts.','','## Independent eight-leaf confirmation','','Seven new alternating pairs, 15 locally verified certificates per process. Total includes setup, every leaf and internal creation, explicit verification, serialization/reporting and wrong-root/height rejection. Creation includes recording, child prechecks, witness preparation and proving. Timed jobs are serial.','','| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins | Bootstrap 95% interval |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,key in (('Whole process','total_s'),('All creation','creation_s'),('Root creation','root_creation_s'),('Setup','setup_s')):
 m=target['metrics'][key];lo,hi=m['bootstrap95_pct'];lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/7 | [{lo:+.2f}, {hi:+.2f}]% |")
lines+=['',f"Decision: {'retain' if retain else 'reject'}. The frozen rule requires at least 3% paired median reduction in total or all creation, at least 6/7 target wins, positive paired bootstrap 95% interval and no companion regression over 1%. Every key, shape, statement and per-position certificate length, scalar count and Merkle phase count matches both variants and the original common-key baseline. The independent Python validator recomputes all leaf/node statements.",'','## Validation and provenance','','All loops use current Yukon, isolated at 83ae1385bfcc5c93f26d117c65f42984cf711028. The control build just before the phase refresh used ab2cc2e. Runner SHA256 is unchanged at ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. Rust 1.99.1, native CPU plus pclmulqdq flags, 32 workers and CPUs 0-63. Build/test budget 96 GiB, benchmark budget 16 GiB, host reserve 40 GiB and four Cargo jobs. The Xeon Gold 6230R host is shared. RSS is a sampled process-group measure, not cgroup isolation. Exact commands, source/build/binary hashes and raw receipts are retained. The formatting mutation receipt reports false because cargo fmt changed source hashes, not because a test failed.','','An initial witness-extension edit used the wrong cwd and failed before changing source. It unintentionally launched a check before the correct edit; that attempt was terminated and excluded. Its replacement bound the edited source correctly, waited for the build lock and passed all 76 native tests. The excluded receipt is preserved and does not support any timing claim.','','For reproduction, build closed_tree through current Yukon with the recorded flags, then run frozen control/candidate binaries at --depth 1 --chain 16 and --depth 3 --chain 16 in alternating order under the source-bound archived wrappers. Use new output paths. Rejected/retained source patches and the predeclared retention plan are in raw-evidence.tar.gz. Run python3 verify-archive.py here to check every archived member hash without extraction. Compiler caches and executable binaries are excluded. The persistent optimization goal remains active; native tests do not settle the formal composition proof or official recursion.fast integration.','']
if retain:
 lines.insert(lines.index('## Validation and provenance')+2,'Final gates pass: 76 native tests, 43 active PCS tests (one existing ignored), Clippy with tests/examples and warnings denied, formatting, strict rustdoc and x86 checks covering AVX-512 VPCLMUL, AVX2 VPCLMUL, VPCLMUL without AVX2 and PCLMUL without AVX2. Cross-feature checks type-check those arms; only the native host arm was executed.\n')
(dest/'README.md').write_text('\n'.join(lines))
(dest/'verify-archive.py').write_bytes((repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-encoding-search/verify-archive.py').read_bytes())
files={name:(dest/name).read_bytes() for name in ('README.md','results.json','verify-archive.py')}
for pattern in ('extension-*','quad-*'):
 for root in b.glob(pattern):
  if root.is_dir():
   for p in root.rglob('*'):
    if p.is_file():files[str(p.relative_to(b))]=p.read_bytes()
for name in ('extension.patch','quad.patch','EXPERIMENTS.md','CONTINUITY.md','validate-closed-tree.py'):
 files['artifacts/'+name]=(b/'artifacts'/name).read_bytes()
for p in b.glob('*.py'):files['scripts/'+p.name]=p.read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())};files['archive-manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with tarfile.open(dest/'raw-evidence.tar.gz','w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(dest/'archive.sha256').write_text(hashlib.sha256((dest/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True,'retain_quad':retain,'target':target['metrics'],'processes':len(rows),'certificates':report['certificates'],'archive_files':len(manifest)}))
