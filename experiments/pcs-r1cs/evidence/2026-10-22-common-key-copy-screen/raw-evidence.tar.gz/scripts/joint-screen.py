from pathlib import Path
import importlib.util,json,subprocess
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=[]
for trial in range(1,4):
 pair={}
 for which in (('control-v4','joint') if trial%2 else ('joint','control-v4')):
  label=f'joint-screen-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  subprocess.run(['python3',str(b/'run-joint-variant.py'),which,label,'--depth','1','--chain','16'],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
 for key in ('key','shape','proof_geometry'):assert pair['control-v4'][key]==pair['joint'][key],key
 rows.append(pair);(b/'artifacts/joint-screen.json').write_text(json.dumps(rows,indent=2))
 print('joint',trial,{k:pair[k]['total_s'] for k in pair},flush=True)
