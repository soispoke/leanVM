from pathlib import Path
import subprocess,shutil,hashlib,json
b=Path(__file__).resolve().parent
for label,cmd in [
 ('joint-full-pcs',['cargo','test','--locked','--release','-p','pcs','--lib']),
 ('joint-full-native',['cargo','test','--locked','--release','-p','format_recursion','--lib']),
 ('joint-release-build',['cargo','build','--locked','--release','-p','rec_aggregation','--example','closed_tree'])]:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('passed',label,flush=True)
shutil.copy2(b/'target/release/examples/closed_tree',b/'artifacts/bin/joint')
(b/'artifacts/joint.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=b/'candidate'))
print('frozen',hashlib.sha256((b/'artifacts/bin/joint').read_bytes()).hexdigest(),flush=True)
