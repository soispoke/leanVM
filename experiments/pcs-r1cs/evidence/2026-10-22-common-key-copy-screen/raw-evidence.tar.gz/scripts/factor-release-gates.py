from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
checks=[
 ('factor-final-clippy',['cargo','clippy','--locked','--release','-p','format_recursion','-p','rec_aggregation','--lib','--tests','--examples','--','-D','warnings']),
 ('factor-final-fmt',['cargo','fmt','--all','--','--check']),
 ('factor-final-doc',['cargo','doc','--locked','--release','-p','format_recursion','--no-deps']),
]
for label,cmd in checks:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('gate passed',label,flush=True)
