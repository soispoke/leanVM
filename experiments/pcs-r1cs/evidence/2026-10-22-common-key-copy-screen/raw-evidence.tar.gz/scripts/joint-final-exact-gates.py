from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
for label,cmd in [
 ('joint-final-exact-pcs',['cargo','test','--locked','--release','-p','pcs','--lib']),
 ('joint-final-exact-native',['cargo','test','--locked','--release','-p','format_recursion','--lib']),
 ('joint-final-exact-fmt',['cargo','fmt','--all','--','--check']),
 ('joint-final-exact-doc',['cargo','doc','--locked','--release','-p','pcs','-p','format_recursion','--no-deps'])]:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('passed',label,flush=True)
