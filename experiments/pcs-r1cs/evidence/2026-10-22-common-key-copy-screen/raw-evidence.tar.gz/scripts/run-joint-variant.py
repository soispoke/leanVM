#!/usr/bin/env python3
from pathlib import Path
import os,subprocess,sys
b=Path(__file__).resolve().parent
which,label,*args=sys.argv[1:]
bin=b/'artifacts/bin'/which
tree=b/('control-v4' if which=='control-v4' else 'candidate')
env=dict(os.environ,LEANVM_NUM_THREADS='32')
cmd=['python3','/root/yukon-autoresearch/workspaces/yukon-latest-77d22d1/bin/bench-research.py','--cwd',str(tree),'--out',str(b/label),'--budget-gib','16','--reserve-gib','40','--timeout-seconds','600','--cpus',','.join(map(str,range(64)))]
for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','*.rs','*.toml','Cargo.lock'],cwd=tree,text=True).splitlines():cmd+=['--source',p]
cmd += ['--source',str(bin),'--source',str(Path(__file__).resolve()),'--',str(bin),*args]
raise SystemExit(subprocess.run(cmd,env=env).returncode)
