import importlib.util,json
from pathlib import Path
b=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('advisor','/root/yukon-autoresearch/workspaces/yukon-latest-77d22d1/toolkit/tools/experiment_advisor.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=m.rank(json.loads((b/'artifacts/joint-advisor-plan.json').read_text()))
(b/'artifacts/joint-advice.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
