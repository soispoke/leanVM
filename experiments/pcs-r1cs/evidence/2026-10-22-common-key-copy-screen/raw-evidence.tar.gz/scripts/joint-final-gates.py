from pathlib import Path
import subprocess,hashlib,json
b=Path(__file__).resolve().parent
for label,cmd in [
 ('joint-final-proof-test',['cargo','test','--locked','--release','-p','pcs','hybrid_proof_matches_dense_with_overlap_and_missing_lanes']),
 ('joint-final-fmt',['cargo','fmt','--all','--','--check']),
 ('joint-final-doc',['cargo','doc','--locked','--release','-p','pcs','-p','format_recursion','--no-deps']),
 ('joint-publication-build',['cargo','build','--locked','--release','-p','rec_aggregation','--example','closed_tree'])]:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('passed',label,flush=True)
frozen=hashlib.sha256((b/'artifacts/bin/joint').read_bytes()).hexdigest()
current=hashlib.sha256((b/'target/release/examples/closed_tree').read_bytes()).hexdigest()
assert frozen==current,(frozen,current)
(b/'artifacts/joint-publication-build-identity.json').write_text(json.dumps({'frozen_binary_sha256':frozen,'publication_binary_sha256':current,'identical':True,'post_measurement_changes':'Comment correction and cfg(test)-only full-random coverage, no production logic changes.'},indent=2))
print('publication binary identical',current,flush=True)
