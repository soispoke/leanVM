"""Bind and seal the independent common-key factored-index experiment."""
from pathlib import Path
import datetime,hashlib,io,json,tarfile
import factor_audit as audit
b=Path(__file__).resolve().parent;repo=b/'candidate';dest=repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-factored-index'
dest.mkdir(exist_ok=True)
screen=audit.series('factor-screen','factor',3);target=audit.series('factor-target','factor',7)
qualified=[m for m in ('total_s','creation_s') if target['metrics'][m]['paired_reduction_pct']>=3 and target['metrics'][m]['wins']>=6 and target['metrics'][m]['bootstrap95_pct'][0]>0]
companion_ok=all(target['metrics'][m]['paired_reduction_pct']>=-1 for m in ('total_s','creation_s'));retain=bool(qualified) and companion_ok
rows=[row for series in (screen,target) for pair in series['rows'] for row in pair.values()]
def receipt(label):return json.loads((b/label/'result.json').read_text())
def sources(r):
 root=Path(r['cwd']);return {str(Path(p).relative_to(root)):h for p,h in r['file_sha256_before'].items() if Path(p).is_relative_to(root) and p.endswith(('.rs','.toml','Cargo.lock'))}
accepted_control=receipt('quad-target-quad-01')
accepted_binary=accepted_control['command'][0]
assert sources(accepted_control)==sources(receipt('quad-release-build'))
control_digest=accepted_control['file_sha256_before'][accepted_binary]
assert hashlib.sha256((b/'artifacts/bin/control-v3').read_bytes()).hexdigest()==control_digest
intervals=[]
for row in rows:
 r=json.loads((Path(row['path']).parent.parent/'result.json').read_text());label=Path(row['path']).parent.parent.name
 build='quad-release-build' if '-control-v3-' in label else 'factor-release-build'
 assert sources(r)==sources(receipt(build)),label
 binary=r['command'][0];assert r['file_sha256_before'][binary]==hashlib.sha256(Path(binary).read_bytes()).hexdigest(),label
 start=datetime.datetime.fromisoformat(r['started_utc']);intervals.append((start,start+datetime.timedelta(seconds=r['median_wall_seconds']),label))
intervals.sort()
for a,z in zip(intervals,intervals[1:]):assert a[1]<=z[0],(a,z)
gates={}
for label in ('factor-direct-proof-test','factor-native-tests',*(('factor-final-clippy','factor-final-fmt','factor-final-doc') if retain else ())):
 r=receipt(label);assert r['ok'] and r['files_unchanged'],label;gates[label]={'ok':True,'receipt_sha256':hashlib.sha256((b/label/'result.json').read_bytes()).hexdigest()}
report={'ok':True,'retain_factor':retain,'qualifying_metrics':qualified,'companion_ok':companion_ok,'screen':screen,'target':target,'validation':gates,'all_sizes_shapes_keys_unchanged':True,'processes':len(rows),'certificates':sum(r['proofs'] for r in rows),'baseline':'a7b0cfa8bfe9186a720f7a8ad84fd487ac6b9f51','latest_yukon':'b6b976274674363634110423c9a85a1652c70bb3','runner_sha256':'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e','scope':'Local performance evidence and differential implementation checks, not a formal soundness proof or official recursion.fast certification.','rule':'At least3% paired median reduction in total or all creation, at least6/7 independent target wins, positive paired bootstrap95% interval and no companion regression over1%; exact key/shape/per-position certificate geometry.'}
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Common-key factored index opening','',('Retained the existing WHIR factored-lane opening path for the native circuit index.' if retain else 'The factored index-opening candidate did not meet the predeclared retention rule and is not retained.'),'','The control is the accepted four-element kernel at a7b0cfa8. This optimization changes prover execution only: circuit/index construction, common setup key, verifier, transcript order, security profiles and serialized proof format are unchanged. These are chain16 local fixtures, not shielded transfers or new matched leanVM/Flock comparisons.','','## What changed','','The four index claims share one multilinear point and cover four aligned columns. The old opener constructs their combined dense F192 weight. The new path splits the shared equality point into a block table and lane selectors, combines the same batching powers into lane coefficients and calls the existing recursive_prover_with_lane_weights API. At the measured index shape, the dense weight alone is 192 MiB; the factored block table is 3 MiB plus tiny lane/selector vectors. The lane prover also avoids materializing the initial dense-weight folds. This allocation comparison is structural, not a claim about the process peak RSS.','','The fast path checks all four claim offsets, dimensions and shared points before sampling any transcript challenge. Other layouts use the original opener. It draws exactly the same batching challenge and target, and the unchanged verifier consumes the same protocol. A differential regression test compares the complete Proof object, including Merkle phases, with the dense reference at rates 1 and 4. Reordered claims exercise the fallback and still produce the exact dense proof. All 77 native release tests pass, including composition and adversarial rejection tests.','','## Two-leaf screen','','Three alternating fresh-process pairs, three locally verified certificates per process. Positive paired reductions mean faster; paired ratios differ from ratios of independent medians.','','| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins |','| --- | ---: | ---: | ---: | ---: |']
for name,key in (('Whole process','total_s'),('All creation','creation_s'),('Root creation','root_creation_s')):
 m=screen['metrics'][key];lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/3 |")
lines+=['','## Independent eight-leaf confirmation','','Seven new alternating pairs, 15 locally verified certificates per process. Total includes common setup, every leaf and internal creation, explicit verification, serialization/reporting and wrong-root/height rejection. Creation includes recording, child prechecks, witness preparation and proving. Timed jobs are serial.','','| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins | Bootstrap 95% interval |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,key in (('Whole process','total_s'),('All creation','creation_s'),('Root creation','root_creation_s'),('Setup','setup_s')):
 m=target['metrics'][key];lo,hi=m['bootstrap95_pct'];lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/7 | [{lo:+.2f}, {hi:+.2f}]% |")
lines+=['',f"Decision: {'retain' if retain else 'reject'}. Retention requires at least 3% paired median reduction in total or all creation, at least 6/7 target wins, a positive paired bootstrap 95% interval and no companion regression over 1%. Every key, shape, independently recomputed statement and per-position certificate length, scalar count and Merkle phase count matches both variants and the published common-key baseline.",'','## Validation and provenance','']
if retain:lines+=['Final targeted Clippy with tests/examples and warnings denied, formatting and strict rustdoc pass. No platform-specific source changed, so the prior kernel feature checks remain applicable. Native and exact-proof differential tests cover the new call path.','']
lines+=['Yukon was refreshed and pinned at b6b976274674363634110423c9a85a1652c70bb3 for this phase. Runner SHA256 remains ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. The control reuses the exact frozen, validated quad-release-build executable from the previous accepted phase; normalized Rust/Cargo source hashes match the clean control-v3 worktree, and its executable hash matches the archived build/measurement binding. No redundant control build is included as a performance result. Rust 1.99.1, native CPU plus pclmulqdq flags, 32 workers, CPUs 0-63 and four Cargo jobs. Build/test budget 96 GiB, benchmark budget 16 GiB and host reserve 40 GiB. The shared Xeon Gold 6230R host is not a dedicated benchmark machine. RSS is sampled process-group memory, not cgroup isolation.','','The archive retains exact commands, source and binary hashes, build/check receipts, all timed stdout/stderr, the source patch and predeclared retention plan. Its audit binds every timed run to the exact corresponding build source and frozen binary and rejects overlapping admitted intervals. The formatting mutation receipt is false because cargo fmt intentionally changed source hashes. No timed run is excluded in this phase.','','Reproduce with the recorded Rust flags and current Yukon: build closed_tree, then run frozen controls/candidates at --depth 1 --chain 16 and --depth 3 --chain 16 in the archived alternating order, using fresh output paths. Run python3 verify-archive.py here to validate archive members and hashes without extraction. Executable binaries and compiler caches are excluded. The long-running performance goal remains active; formal native composition security and official recursion.fast integration remain open.','']
(dest/'README.md').write_text('\n'.join(lines))
(dest/'verify-archive.py').write_bytes((repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-encoding-search/verify-archive.py').read_bytes())
files={name:(dest/name).read_bytes() for name in ('README.md','results.json','verify-archive.py')}
files['control-reuse/accepted-quad-measurement.json']=(b/'quad-target-quad-01/result.json').read_bytes()
for pattern in ('factor-*','quad-release-build'):
 for root in b.glob(pattern):
  if root.is_dir():
   for p in root.rglob('*'):
    if p.is_file():files[str(p.relative_to(b))]=p.read_bytes()
for name in ('factor.patch','EXPERIMENTS.md','CONTINUITY.md','validate-closed-tree.py'):
 files['artifacts/'+name]=(b/'artifacts'/name).read_bytes()
for p in b.glob('*.py'):files['scripts/'+p.name]=p.read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())};files['archive-manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with tarfile.open(dest/'raw-evidence.tar.gz','w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(dest/'archive.sha256').write_text(hashlib.sha256((dest/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True,'retain_factor':retain,'target':target['metrics'],'processes':len(rows),'certificates':report['certificates'],'archive_files':len(manifest)}))
