from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
checks=[
 ('quad-final-pcs',['cargo','test','--locked','--release','-p','pcs','--lib']),
 ('quad-final-clippy',['cargo','clippy','--locked','--release','-p','pcs','-p','format_recursion','-p','rec_aggregation','--lib','--tests','--examples','--','-D','warnings']),
 ('quad-final-fmt',['cargo','fmt','--all','--','--check']),
 ('quad-final-doc',['cargo','doc','--locked','--release','-p','pcs','-p','format_recursion','--no-deps']),
 ('quad-final-x86-avx512',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+avx512f,+avx512bw,+avx512vl,+vpclmulqdq,+pclmulqdq,+gfni,+avx2,+aes','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
 ('quad-final-x86-vpclmul-avx2',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+pclmulqdq,+vpclmulqdq,+avx2','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
 ('quad-final-x86-vpclmul-only',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+pclmulqdq,+vpclmulqdq,-avx2,-avx512f','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
 ('quad-final-x86-pclmul-only',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+pclmulqdq,-avx2,-vpclmulqdq,-avx512f','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
]
for label,cmd in checks:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('gate passed',label,flush=True)
