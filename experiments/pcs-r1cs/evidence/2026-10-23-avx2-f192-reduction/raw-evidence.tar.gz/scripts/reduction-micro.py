from pathlib import Path
import json,re,subprocess,statistics
b=Path(__file__).resolve().parent
rows=[]
for i in range(1,4):
 pair={}
 for variant in (['control-v6','reduction'] if i%2 else ['reduction','control-v6']):
  label=f'reduction-micro-{variant}-{i:02d}'
  assert not (b/label).exists()
  subprocess.run(['python3',str(b/'run-reduction-variant.py'),variant+'-probe',label],check=True)
  r=json.loads((b/label/'result.json').read_text());assert r['ok'] and r['files_unchanged']
  s=(b/label/'run-00/stdout.log').read_text()
  pair[variant]={k:float(v) for k,v in re.findall(r'(reduction_s|product_s)=([0-9.]+)',s)}
 rows.append(pair)
 (b/'artifacts/reduction-micro.json').write_text(json.dumps(rows,indent=2))
 print(i,pair,flush=True)
for key in ['reduction_s','product_s']:
 print(key,'paired percent',statistics.median(100*(1-p['reduction'][key]/p['control-v6'][key]) for p in rows),flush=True)
