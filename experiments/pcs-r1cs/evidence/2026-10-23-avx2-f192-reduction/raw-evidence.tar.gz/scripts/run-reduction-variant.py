#!/usr/bin/env python3
from pathlib import Path
import os,subprocess,sys
b=Path(__file__).resolve().parent
which,label,*args=sys.argv[1:]
assert which in ['control-v6','reduction','control-v6-probe','reduction-probe']
tree=b/('control-v6' if which.startswith('control-v6') else 'candidate')
binary=b/'artifacts/bin'/which
cmd=['python3','/root/yukon-autoresearch/workspaces/yukon-latest-ca3f535/bin/bench-research.py','--cwd',str(tree),'--out',str(b/label),'--budget-gib','16','--reserve-gib','40','--timeout-seconds','600','--cpus',','.join(map(str,range(64)))]
for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','*.rs','*.toml','Cargo.lock'],cwd=tree,text=True).splitlines():cmd+=['--source',p]
cmd += ['--source',str(binary),'--source',str(Path(__file__).resolve()),'--',str(binary),*args]
raise SystemExit(subprocess.run(cmd,env=dict(os.environ,LEANVM_NUM_THREADS='32')).returncode)
