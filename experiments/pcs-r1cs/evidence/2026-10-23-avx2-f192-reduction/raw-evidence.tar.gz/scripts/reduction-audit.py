"""Audit source-bound field-reduction measurements and retention criteria."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,random,statistics
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
base={r['leaves']:r for r in json.loads((b/'candidate/experiments/pcs-r1cs/evidence/2026-10-22-common-key-closure/results.json').read_text())['baseline']}

def receipt(label):
 r=json.loads((b/label/'result.json').read_text())
 assert r['ok'] and r['files_unchanged'],label
 assert r['tooling_git']['revision']=='ca3f535ffdd9156d529c0c256208cd6d2b355276'
 return r

def sources(r):
 root=Path(r['cwd'])
 return {str(Path(p).relative_to(root)):h for p,h in r['file_sha256_before'].items() if Path(p).is_relative_to(root) and p.endswith(('.rs','.toml','Cargo.lock'))}

def series(phase,count):
 rows=[];intervals=[];rng=random.Random(20261023)
 builds={w:sources(receipt(f'reduction-isolated-{w}-build')) for w in ['control-v6','reduction']}
 for i in range(1,count+1):
  pair={};certs={}
  for w in ['control-v6','reduction']:
   label=f'reduction-{phase}-{w}-{i:02d}'
   path=b/label/'run-00/stdout.log'
   pair[w]=v.check(path)
   r=receipt(label)
   assert sources(r)==builds[w],label
   binary=b/'artifacts/bin'/w
   assert r['file_sha256_before'][str(binary)]==hashlib.sha256(binary.read_bytes()).hexdigest()
   intervals.append((datetime.datetime.fromisoformat(r['started_utc']),datetime.datetime.fromisoformat(r['finished_utc'])))
   events=[json.loads(l) for l in path.read_text().splitlines() if l.startswith('{')]
   certs[w]=[p['certificate_digest'] for p in events if p.get('kind')=='proof']
   assert all(len(c)==32 and all(0<=x<256 for x in c) for c in certs[w])
  for k in ['key','shape','proof_geometry']:
   assert pair['control-v6'][k]==pair['reduction'][k]==base[pair['control-v6']['leaves']][k],(phase,i,k)
  assert certs['control-v6']==certs['reduction']
  pair['certificate_digests']=certs['control-v6'];rows.append(pair)
 intervals.sort();assert all(a[1]<=z[0] for a,z in zip(intervals,intervals[1:]))
 metrics={}
 for m in ['total_s','creation_s','root_creation_s','setup_s','verification_s','root_verification_s','cpu_s','peak_rss_bytes']:
  ratios=[100*(1-p['reduction'][m]/p['control-v6'][m]) for p in rows]
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(20000))
  metrics[m]={'control_median':statistics.median(p['control-v6'][m] for p in rows),'candidate_median':statistics.median(p['reduction'][m] for p in rows),'paired_reduction_pct':statistics.median(ratios),'wins':sum(x>0 for x in ratios),'paired_pct':ratios,'bootstrap95_pct':[boot[499],boot[19499]]}
 return {'phase':phase,'pairs':count,'metrics':metrics,'rows':rows}

if __name__=='__main__':
 import sys
 phase=sys.argv[1] if len(sys.argv)>1 else 'screen'
 out=series(phase,7 if phase=='target' else 3)
 (b/f'artifacts/reduction-{phase}-audited.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out['metrics'],indent=2))
