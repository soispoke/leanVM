from pathlib import Path
import hashlib,json,shutil,subprocess
b=Path(__file__).resolve().parent
for tree,variant in [('control-v6','control-v6'),('candidate','reduction')]:
 label=f'reduction-isolated-{variant}-build'
 assert not (b/label).exists()
 target=b/f'target-{variant}'
 subprocess.run(['python3',str(b/'run-command.py'),tree,label,'env',f'CARGO_TARGET_DIR={target}','cargo','build','--locked','--release','-p','primitives','--example','reduction_probe','-p','rec_aggregation','--example','closed_tree'],check=True)
 for src,dst in [('closed_tree',variant),('reduction_probe',f'{variant}-probe')]:
  shutil.copy2(target/'release/examples'/src,b/'artifacts/bin'/dst)
  print(dst,hashlib.sha256((b/'artifacts/bin'/dst).read_bytes()).hexdigest(),flush=True)
