from pathlib import Path
import importlib.util,json,subprocess,hashlib,sys
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=[]
phase=sys.argv[1] if len(sys.argv)>1 else 'screen'
assert phase in ['screen','target','equivalence']
count=7 if phase=='target' else (1 if phase=='equivalence' else 3)
for trial in range(1,count+1):
 pair={};certs={}
 for which in (('control-v6','reduction') if trial%2 else ('reduction','control-v6')):
  label=f'reduction-{phase}-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  args=['--depth','3' if phase=='target' else '1','--chain','16']
  if phase=='equivalence':args+=['--certificate-dir',str(b/'artifacts'/f'reduction-certificates-{which}')]
  subprocess.run(['python3',str(b/'run-reduction-variant.py'),which,label,*args],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
  proofs=[json.loads(l) for l in (b/label/'run-00/stdout.log').read_text().splitlines() if l.startswith('{')]
  certs[which]=[p['certificate_digest'] for p in proofs if p.get('kind')=='proof']
 for key in ('key','shape','proof_geometry'):assert pair['control-v6'][key]==pair['reduction'][key],key
 assert certs['control-v6']==certs['reduction'],'certificate digest mismatch'
 pair['certificate_digests']=certs['control-v6']
 rows.append(pair);(b/f'artifacts/reduction-{phase}.json').write_text(json.dumps(rows,indent=2))
 print(phase,trial,{k:pair[k]['total_s'] for k in ['control-v6','reduction']},flush=True)
if phase=='equivalence':
 control=b/'artifacts/reduction-certificates-control-v6';candidate=b/'artifacts/reduction-certificates-reduction'
 assert {p.name:p.read_bytes() for p in control.iterdir()}=={p.name:p.read_bytes() for p in candidate.iterdir()}
 print('all three complete certificates byte-identical',flush=True)
