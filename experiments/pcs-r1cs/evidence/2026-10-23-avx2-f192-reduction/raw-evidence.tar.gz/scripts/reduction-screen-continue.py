from pathlib import Path
import importlib.util,json,subprocess
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=json.loads((b/'artifacts/reduction-screen.json').read_text())
for trial in (2,3):
 pair={}; certs={}
 for which in (('reduction','control-v6') if trial%2==0 else ('control-v6','reduction')):
  label=f'reduction-screen-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  subprocess.run(['python3',str(b/'run-reduction-variant.py'),which,label,'--depth','1','--chain','16'],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
  events=[json.loads(line) for line in (b/label/'run-00/stdout.log').read_text().splitlines() if line.startswith('{')]
  certs[which]=[p['certificate_digest'] for p in events if p.get('kind')=='proof']
 for key in ('key','shape','proof_geometry'): assert pair['control-v6'][key]==pair['reduction'][key],key
 assert certs['control-v6']==certs['reduction']
 pair['certificate_digests']=certs['control-v6']; rows.append(pair)
 (b/'artifacts/reduction-screen.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('screen',trial,{k:pair[k]['total_s'] for k in ('control-v6','reduction')},flush=True)
