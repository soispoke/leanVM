#!/usr/bin/env python3
from pathlib import Path
import os,subprocess,sys
B=Path(__file__).resolve().parent
T=B/'pgo'
phase,label,*command=sys.argv[1:]
flags='-C target-cpu=native -C target-feature=+pclmulqdq'
if phase=='instrument':flags+=' -Cprofile-generate='+str(B/'pgo-data')
elif phase=='use':flags+=' -Cprofile-use='+str(B/'pgo.profdata')
else:assert phase=='normal'
env=dict(os.environ,PATH='/root/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:'+os.environ['PATH'],RUSTUP_TOOLCHAIN='1.99.1',RUSTUP_HOME='/root/.rustup',CARGO_TARGET_DIR=str(B/'target-pgo'),CARGO_BUILD_JOBS='4',RUSTFLAGS=flags,LEANVM_NUM_THREADS='32',LLVM_PROFILE_FILE=str(B/('pgo-build-profiles' if command[0]=='cargo' else 'pgo-data')/'train-%p-%m.profraw'))
args=['python3','/root/yukon-autoresearch/bin/bench-research.py','--cwd',str(T),'--out',str(B/label),'--budget-gib','96' if command[0]=='cargo' else '8','--reserve-gib','40','--timeout-seconds','1800','--cpus',','.join(map(str,range(64)))]
for name in subprocess.check_output(['git','ls-files','*.rs','*.toml','Cargo.lock'],cwd=T,text=True).splitlines():args+=['--source',str(T/name)]
for source in [Path(__file__).resolve(),B/'pgo-protocol.md',Path('/root/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustc')]:args+=['--source',str(source)]
if phase=='use':args+=['--source',str(B/'pgo.profdata')]
if 'merge' in command: 
 for source in sorted((B/'pgo-data').glob('*.profraw')):args+=['--source',str(source)]
args+=['--',*command]
raise SystemExit(subprocess.run(args,env=env).returncode)
