#!/usr/bin/env python3
from pathlib import Path
import subprocess,os,sys
B=Path(__file__).resolve().parent
ROOT=Path('/root/workspaces/mission-9abcee72/leanvm-opt')
label,*command=sys.argv[1:]
args=['python3','/root/yukon-autoresearch/bin/bench-research.py','--cwd',str(ROOT),'--out',str(B/label),'--budget-gib','4','--reserve-gib','40','--timeout-seconds','300','--cpus',','.join(map(str,range(64)))]
sources=[*B.glob('audit-*.py'),Path(__file__).resolve(),*B.glob('*-freeze.json'),*B.glob('*protocol.md'),*ROOT.joinpath('experiments/pcs-r1cs/recursion').glob('*.py')]
for folder in B.glob('*-depth*-chain256'):
 sources.extend(folder.rglob('*.json'))
 sources.extend(folder.rglob('*.jsonl'))
 sources.extend(folder.rglob('*.log'))
for path in sorted(set(sources)):
 args+=['--source',str(path)]
args+=['--',*command]
raise SystemExit(subprocess.run(args,env=dict(os.environ,LEANVM_NUM_THREADS='32'),check=False).returncode)
