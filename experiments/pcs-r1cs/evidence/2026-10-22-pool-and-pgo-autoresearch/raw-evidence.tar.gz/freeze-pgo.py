#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,shutil
b=Path(__file__).resolve().parent
t=b/'pgo'
binary=b/'private_tree-pgo'
r=json.loads((b/'pgo-use-build/result.json').read_text())
assert r['ok'] and r['files_unchanged']
shutil.copy2(b/'target-pgo/release/examples/private_tree',binary)
base=json.loads((b/'spin-freeze.json').read_text())['specs']['baseline']
files=subprocess.check_output(['git','ls-files','*.rs','*.toml','Cargo.lock'],cwd=t,text=True).splitlines()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=t)
flags='-C target-cpu=native -C target-feature=+pclmulqdq -Cprofile-use='+str(b/'pgo.profdata')
config=dict(specs=dict(baseline=base,candidate=dict(binary=str(binary),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip(),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),env={'RUSTFLAGS':flags})),trees={str(t):{n:hashlib.sha256((t/n).read_bytes()).hexdigest() for n in files},str(b):{n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in ['pgo-protocol.md','restart-protocol.md','pgo.profdata']}},yukon_revision='034f7e7d3dcdbfb8c395bc06ab3dd8069df1fd4b')
(b/'pgo-freeze.json').write_text(json.dumps(config,indent=2)+'\n')
(b/'pgo.patch').write_bytes(subprocess.check_output(['git','diff','39eb2da3','HEAD','--','crates'],cwd=t))
print(json.dumps(config['specs'],indent=2))
