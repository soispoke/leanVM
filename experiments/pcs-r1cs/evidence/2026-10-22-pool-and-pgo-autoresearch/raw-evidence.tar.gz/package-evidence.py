#!/usr/bin/env python3
"""Archive reproducibility inputs and receipts without build caches or binaries."""
from pathlib import Path
import hashlib, io, json, shutil, tarfile
B=Path(__file__).resolve().parent
ROOT=Path('/root/workspaces/mission-9abcee72/leanvm-opt')
DEST=ROOT/'experiments/pcs-r1cs/evidence/2026-10-22-pool-and-pgo-autoresearch'
DEST.mkdir(parents=True,exist_ok=True)
files=set()
for p in B.iterdir():
 if p.is_file() and p.suffix in {'.py','.md','.json','.patch','.profdata'}:files.add(p)
 if p.is_dir() and any((p/n).exists() for n in ['result.json','started.json','plan.json']):
  files.update(f for f in p.rglob('*') if f.is_file())
files.update((B/'pgo-data').glob('*.profraw'))
manifest={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with tarfile.open(DEST/'raw-evidence.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(B)),recursive=False)
 payload=(json.dumps(manifest,indent=2)+'\n').encode()
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(payload)
 tar.addfile(info,io.BytesIO(payload))
for name in ['retention-audit.json','pgo-audit-expanded.json','links-audit-expanded.json','restart-reconciliation.json','restart-protocol.md']:
 shutil.copy2(B/name,DEST/name)
(DEST/'archive.sha256').write_text(hashlib.sha256((DEST/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps(dict(files=len(manifest),bytes=(DEST/'raw-evidence.tar.gz').stat().st_size)))
