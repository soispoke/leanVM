#!/usr/bin/env python3
"""Fixed CPU budget, alternating fresh-process measurements, frozen provenance."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
BASE=Path(__file__).resolve().parent
ROOT=Path('/root/workspaces/mission-9abcee72/leanvm-opt')
PREFIX=sys.argv[1]
CONFIG=json.loads((BASE/(PREFIX+'-freeze.json')).read_text())
DEPTH,CHAIN,TRIALS=map(int,sys.argv[2:5])
OUT=BASE/f'{PREFIX}-depth{DEPTH}-chain{CHAIN}'
OUT.mkdir(exist_ok=True)
SPECS=CONFIG['specs']
for spec in SPECS.values():
 assert hashlib.sha256(Path(spec['binary']).read_bytes()).hexdigest()==spec['sha256']
for tree,files in CONFIG['trees'].items():
 for name,digest in files.items():
  assert hashlib.sha256((Path(tree)/name).read_bytes()).hexdigest()==digest
PLAN=[('warmup',['baseline','candidate'])]+[(f'trial-{i}',['baseline','candidate'] if i%2==0 else ['candidate','baseline']) for i in range(TRIALS)]
(OUT/'plan.json').write_text(json.dumps(dict(depth=DEPTH,chain=CHAIN,trials=TRIALS,plan=PLAN,config=CONFIG,policy='One excluded warmup per variant; alternating fresh processes; 32 workers, CPUs 0-63.'),indent=2)+'\n')
for trial,order in PLAN:
 for name in order:
  label=f'{name}-{trial}'
  guard=OUT/(label+'-guard')
  if (guard/'result.json').exists():
   assert json.loads((guard/'result.json').read_text())['ok']
   continue
  subprocess.run([str(ROOT/'experiments/pcs-r1cs/memguard'),'admit','9'],check=True,stdout=subprocess.DEVNULL)
  spec=SPECS[name]
  env=dict(os.environ,LEANVM_NUM_THREADS='32',RUSTUP_TOOLCHAIN='1.99.1',RUSTFLAGS='-C target-cpu=native -C target-feature=+pclmulqdq')
  env.pop('_RJEM_MALLOC_CONF',None)
  env.update(spec.get('env',{}))
  args=['python3','/root/yukon-autoresearch/bin/bench-research.py','--cwd',str(ROOT),'--out',str(guard),'--budget-gib','8','--reserve-gib','40','--timeout-seconds','300','--sample-seconds','.05','--cpus',','.join(map(str,range(64)))]
  for tree,files in CONFIG['trees'].items():
   for n in files:args+=['--source',str(Path(tree)/n)]
  for source in [Path(spec['binary']),Path(__file__).resolve(),BASE/(PREFIX+'-freeze.json'),BASE/'run-precise.py',BASE/'protocol.md']:
   args+=['--source',str(source)]
  args+=['--','python3',str(BASE/'run-precise.py'),'--out',str(OUT/label),'--budget-gib','8','--binary-source-commit',spec['revision'],'--',spec['binary'],'--depth',str(DEPTH),'--chain',str(CHAIN)]
  print(PREFIX,DEPTH,CHAIN,label,flush=True)
  subprocess.run(args,env=env,check=True,stdout=subprocess.DEVNULL)
print('SERIES COMPLETE',flush=True)
