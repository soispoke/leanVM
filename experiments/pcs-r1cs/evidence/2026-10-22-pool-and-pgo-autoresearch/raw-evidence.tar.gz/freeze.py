#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,shutil,sys
b=Path(__file__).resolve().parent
which,prefix=sys.argv[1:]
t=b/which
binary=b/('private_tree-'+prefix)
shutil.copy2('/root/yukon-autoresearch/workspaces/leanr1cs-full-hunt-20261022/target/release/examples/private_tree',binary)
base=json.loads((b/'spin-freeze.json').read_text())['specs']['baseline']
files=subprocess.check_output(['git','ls-files','*.rs','*.toml','Cargo.lock'],cwd=t,text=True).splitlines()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=t)
config=dict(specs=dict(baseline=base,candidate=dict(binary=str(binary),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip(),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())),trees={str(t):{n:hashlib.sha256((t/n).read_bytes()).hexdigest() for n in files},str(b):{prefix+'-protocol.md':hashlib.sha256((b/(prefix+'-protocol.md')).read_bytes()).hexdigest()}},yukon_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/root/yukon-autoresearch',text=True).strip())
(b/(prefix+'-freeze.json')).write_text(json.dumps(config,indent=2)+'\n')
(b/(prefix+'.patch')).write_bytes(subprocess.check_output(['git','diff','39eb2da3','HEAD','--','crates'],cwd=t))
print(json.dumps(config['specs'],indent=2))
