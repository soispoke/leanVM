#!/usr/bin/env python3
"""Validate frozen source provenance, all trees, environments, shapes and sizes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('series',BASE/'audit-series.py')
series=importlib.util.module_from_spec(spec)
spec.loader.exec_module(series)

def main():
 counts=dict(processes=0,proofs=0,excluded_warmups=0,timed=0)
 results={}
 required=['spin','arena','field','lifetime','cache','pgo','links']
 for prefix in required:
  config=json.loads((BASE/(prefix+'-freeze.json')).read_text())
  output={}
  folders=sorted(BASE.glob(prefix+'-depth*-chain256'))
  assert folders
  assert any(f.name==prefix+'-depth2-chain256' for f in folders)
  for folder in folders:
   plan=json.loads((folder/'plan.json').read_text())
   expected_trials={1:3,2:7,3:9}[plan['depth']]
   assert plan['trials']==expected_trials
   assert plan['chain']==256
   reference=None
   pairs=[]
   for trial,order in plan['plan']:
    assert order==(['baseline','candidate'] if trial=='warmup' or int(trial.split('-')[1])%2==0 else ['candidate','baseline'])
    rows_by_name={}
    for name in order:
     path=folder/f'{name}-{trial}'
     metrics,geometry=series.metrics(path)
     record=json.loads((path/'result.json').read_text())
     frozen=config['specs'][name]
     assert record['source_commit']==frozen['revision']
     assert record['binary_sha256']==frozen['sha256']
     assert record['command']==[frozen['binary'],'--depth',str(plan['depth']),'--chain','256']
     assert record['worker_count']=='32' and record['affinity']==list(range(64))
     assert record['rust_toolchain']=='1.99.1'
     assert record['rustflags']==frozen.get('env',{}).get('RUSTFLAGS','-C target-cpu=native -C target-feature=+pclmulqdq')
     assert record['malloc_conf']==frozen.get('env',{}).get('_RJEM_MALLOC_CONF')
     if reference is None:reference=geometry
     assert geometry==reference
     guard=json.loads(path.with_name(path.name+'-guard').joinpath('result.json').read_text())
     assert guard['ok'] and guard['files_unchanged']
     assert guard['harness_sha256']=='ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e'
     assert guard['tooling_git']['revision']==config['yukon_revision']
     assert guard['limits']['reserve_gib']==40
     for tree,files in config['trees'].items():
      for source,digest in files.items():
       assert guard['file_sha256_before'][str(Path(tree)/source)]==digest
     assert guard['file_sha256_before'][frozen['binary']]==frozen['sha256']
     assert guard['file_sha256_before']==guard['file_sha256_after']
     assert all(r['ok'] for r in guard['runs'])
     assert all(r['user_seconds']>=0 and r['system_seconds']>=0 for r in guard['runs'])
     proof_rows=[json.loads(line) for line in (path/'stdout.jsonl').read_text().splitlines() if json.loads(line)['kind']=='proof']
     counts['proofs']+=len(proof_rows)
     counts['processes']+=1
     counts['excluded_warmups' if trial=='warmup' else 'timed']+=1
     assert len(proof_rows)==(1<<(plan['depth']+1))-1
     assert all(row['verified'] for row in proof_rows)
     rows_by_name[name]=metrics
    if trial!='warmup':pairs.append((rows_by_name['baseline'],rows_by_name['candidate']))
   output[folder.name]=dict(trials=plan['trials'],proof_shapes_and_lengths_unchanged=True,metrics={key:series.paired([(a[key],b[key]) for a,b in pairs]) for key in pairs[0][0]},root_proof_bytes=reference[1][(plan['depth'],0)])
  results[prefix]=output
 report=dict(ok=True,counts=counts,all_proofs_locally_verified=True,independent_statements_checked=True,all_sizes_and_shapes_unchanged=True,results=results)
 (BASE/'retention-audit.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(ok=True,counts=counts),indent=2))
if __name__=='__main__':main()
