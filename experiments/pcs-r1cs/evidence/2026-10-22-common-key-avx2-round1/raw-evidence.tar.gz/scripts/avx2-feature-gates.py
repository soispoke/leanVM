from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
for label,flags in [
 ('avx2-features-wide','-C target-cpu=x86-64 -C target-feature=+avx512f,+avx512bw,+avx512vl,+vpclmulqdq,+pclmulqdq,+gfni,+avx2,+aes'),
 ('avx2-features-avx2-only','-C target-cpu=x86-64 -C target-feature=+avx2,+pclmulqdq,-gfni,-avx512f,-avx512bw'),
 ('avx2-features-scalar','-C target-cpu=x86-64 -C target-feature=+pclmulqdq,-gfni,-avx2,-avx512f,-avx512bw')]:
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,'env','RUSTFLAGS='+flags,'cargo','check','--locked','--release',*(['--workspace'] if label.endswith('wide') else ['-p','flock','--lib']),'--target','x86_64-unknown-linux-gnu'],check=True)
 print('passed',label,flush=True)
