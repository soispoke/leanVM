from pathlib import Path
import subprocess, hashlib, json, shutil
b=Path(__file__).resolve().parent
assert json.loads((b/'avx2-validated-tests/result.json').read_text())['ok']
for label,cmd in [
 ('avx2-final-clippy',['cargo','clippy','--locked','--release','-p','flock','--all-targets','--','-D','warnings']),
 ('avx2-final-fmt',['cargo','fmt','--all','--','--check']),
 ('avx2-final-doc',['cargo','doc','--locked','--release','-p','flock','--no-deps']),
 ('avx2-final-build',['cargo','build','--locked','--release','-p','rec_aggregation','--example','closed_tree'])]:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('passed',label,flush=True)
r=json.loads((b/'avx2-final-build/result.json').read_text());assert r['ok'] and r['files_unchanged']
bin=b/'artifacts/bin/avx2'
shutil.copy2(b/'target/release/examples/closed_tree',bin)
(b/'artifacts/avx2.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=b/'candidate'))
(b/'artifacts/avx2-binary.json').write_text(json.dumps({'binary':str(bin),'sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'build_receipt_sha256':hashlib.sha256((b/'avx2-final-build/result.json').read_bytes()).hexdigest()},indent=2))
print('frozen avx2',flush=True)
