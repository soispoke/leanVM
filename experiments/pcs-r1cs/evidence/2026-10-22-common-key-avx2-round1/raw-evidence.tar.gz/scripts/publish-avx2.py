"""Audit and seal the AVX2 round-one experiment before publishing it."""
from pathlib import Path
import datetime, hashlib, io, json, subprocess, tarfile
import identity_audit as audit

b = Path(__file__).resolve().parent
repo = b / 'candidate'
dest = repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-avx2-round1'
dest.mkdir(exist_ok=True)
screen = audit.series('avx2-screen', 'avx2', 3)
target = audit.series('avx2-target', 'avx2', 7)
qualified = [m for m in ('total_s', 'creation_s') if
             target['metrics'][m]['paired_reduction_pct'] >= 3 and
             target['metrics'][m]['wins'] >= 6 and
             target['metrics'][m]['bootstrap95_pct'][0] > 0]
companion_ok = all(target['metrics'][m]['paired_reduction_pct'] >= -1 for m in ('total_s', 'creation_s'))
retain = bool(qualified) and companion_ok
rows = [row for series in (screen, target) for pair in series['rows'] for row in pair.values()]

def receipt(label):
    return json.loads((b / label / 'result.json').read_text())

def sources(r):
    root = Path(r['cwd'])
    return {str(Path(p).relative_to(root)): h for p, h in r['file_sha256_before'].items()
            if Path(p).is_relative_to(root) and p.endswith(('.rs', '.toml', 'Cargo.lock'))}

control = receipt('joint-target-joint-01')
assert sources(control) == sources(receipt('joint-release-build'))
assert control['file_sha256_before'][control['command'][0]] == hashlib.sha256((b / 'artifacts/bin/control-v5').read_bytes()).hexdigest()
candidate_sources = sources(receipt('avx2-final-build'))
intervals = []
for row in rows:
    label = Path(row['path']).parent.parent.name
    r = receipt(label)
    expected = sources(receipt('joint-release-build')) if '-control-v5-' in label else candidate_sources
    assert sources(r) == expected, label
    assert r['file_sha256_before'][r['command'][0]] == hashlib.sha256(Path(r['command'][0]).read_bytes()).hexdigest(), label
    intervals.append((datetime.datetime.fromisoformat(r['started_utc']), datetime.datetime.fromisoformat(r['finished_utc'])))
intervals.sort()
assert all(a[1] <= z[0] for a, z in zip(intervals, intervals[1:]))
gates = {}
for label in ('avx2-validated-tests', 'avx2-final-clippy', 'avx2-final-fmt', 'avx2-core-doc',
              'avx2-final-build', 'avx2-features-wide', 'avx2-features-avx2-only', 'avx2-features-scalar'):
    r = receipt(label)
    assert r['ok'] and r['files_unchanged'], label
    assert sources(r) == candidate_sources, label
    gates[label] = hashlib.sha256((b / label / 'result.json').read_bytes()).hexdigest()
for path, digest in candidate_sources.items():
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
assert subprocess.check_output(['git', 'diff'], cwd=repo) == (b / 'artifacts/avx2.patch').read_bytes()
if not retain:
    subprocess.run(['git', 'restore', '--', 'crates/flock/src/zerocheck/univariate_skip_optimized.rs'], cwd=repo, check=True)
    for path, digest in sources(control).items():
        assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
report = {'ok': True, 'retained': retain, 'qualified': qualified, 'companion_ok': companion_ok,
          'all_sizes_shapes_keys_unchanged': True, 'processes': len(rows),
          'certificates': sum(r['proofs'] for r in rows), 'screen': screen, 'target': target,
          'validation': gates, 'baseline': 'f23eddd93d85de3d07342474e031ff619cbdc860',
          'tooling': '1ffa172ef1ccec3fe91256bb733c060222805731',
          'runner_sha256': 'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e',
          'exclusions': json.loads((b / 'artifacts/avx2-exclusions.json').read_text()),
          'scope': 'Local paired performance evidence; no official recursion.fast or formal composition claim.'}
(dest / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['# Common-key AVX2 round-one zerocheck', '',
         ('Retained packed AVX2 multiplication in the non-GFNI round-one kernel.' if retain else
          'Rejected packed AVX2 multiplication under the frozen retention rule; accepted Rust sources restored.'), '',
         'The control is the accepted hybrid opener at f23eddd9. These are chain16 local fixtures. Both variants use the same verifier, keys, circuit shapes, security settings, statements, transcript order and certificate encoding.', '',
         'Eight carryless bit steps multiply 32 independent AES-field bytes in parallel, followed by the same widened shift/reduction. AVX2 is selected only for x86 builds without GFNI. NEON, GFNI and scalar paths remain available.', '',
         'Every one of the 65,536 byte products matches the scalar field oracle. Kernel checks cover edge values, random data, unaligned offsets and medium positions; complete zerocheck Proof objects, claims and the next transcript challenge match the scalar kernel. The full run passes 72 Flock, 77 native and 44 PCS tests (one pre-existing PCS ignore), Clippy, formatting and PCS/native rustdoc. Explicit RUSTFLAGS checks cover wide GFNI/AVX-512 workspace, AVX2-only and scalar configurations.', '',
         'Broader Flock rustdoc has a pre-existing broken Keccak-f[1600] link. It fails identically on both variants with identical keccak.rs bytes; it is recorded rather than reported as passing.', '']
for title, series in [('Three-pair two-leaf screen', screen), ('Seven independent eight-leaf confirmation pairs', target)]:
    lines += ['## ' + title, '', '| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins |', '| --- | ---: | ---: | ---: | ---: |']
    for name, key in [('Whole process', 'total_s'), ('All proof creation', 'creation_s'), ('Root creation', 'root_creation_s')]:
        m = series['metrics'][key]
        lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/{series['pairs']} |")
    lines.append('')
lines += ['The predeclared retention bar is at least3% paired median improvement in total or creation, at least6/7 target wins, a positive bootstrap95 lower bound, no companion total/creation regression over1%, and exact keys/shapes/statements/proof geometry. The 2.97% total screen was treated as promising, not a retention pass; confirmation uses seven new pairs.', '',
          'Every process is fresh, locally verifies every certificate, and is checked against independently recomputed statements plus the published common-key geometry. Timed jobs alternate order and have no overlapping recorded intervals. Positive paired reductions mean faster; median ratios need not equal the ratio of medians. No timed observations are removed.', '',
          'Yukon upstream was checked and pinned at1ffa172. Rust1.99.1, native CPU plus pclmulqdq, 32 workers, CPUs0-63, four Cargo jobs. Build/test budget96GiB, timed budget16GiB, reserve40GiB. The Xeon Gold6230R host is shared. Memory is sampled process-group RSS, not cgroup isolation. No new matched leanVM or original Flock speedup is claimed.', '',
          'The archive records failed drafts, formatting mutation, interrupted checks, corrected gates and the architecture flag-precedence correction. Initial per-target flag checks were shadowed by the runner RUSTFLAGS; only the later explicit-env checks establish the feature matrix. Early compile failures and interrupted gates were excluded before timing. The interrupted old PGO command was not restarted; its resumed build and use-build receipts were already present.', '',
          'The source patch, predeclared plan, exact commands, raw logs, source/binary hashes, frozen-control build reuse receipts, exclusions and all timed receipts are preserved. Run python3 verify-archive.py for archive integrity without extraction. Formal composition/security proof and official recursion.fast integration remain open. The optimization goal remains active.', '']
(dest / 'README.md').write_text('\n'.join(lines))
(dest / 'verify-archive.py').write_bytes((repo / 'experiments/pcs-r1cs/evidence/2026-10-22-common-key-hybrid-opening/verify-archive.py').read_bytes())
files = {n: (dest / n).read_bytes() for n in ('README.md', 'results.json', 'verify-archive.py')}
for label in ('joint-release-build', 'joint-target-joint-01', 'zerocheck-baseline-build', 'zerocheck-baseline-tests'):
    for p in (b / label).rglob('*'):
        if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for root in b.glob('avx2-*'):
    if root.is_dir():
        for p in root.rglob('*'):
            if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for label in ('avx512-targeted-test',):
    for p in (b / label).rglob('*'):
        if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in (b / 'artifacts').glob('avx*'):
    if p.is_file(): files[str(p.relative_to(b))] = p.read_bytes()
for p in b.glob('*avx2*.py'):
    files['scripts/' + p.name] = p.read_bytes()
for name in ('run-command.py', 'identity_audit.py'):
    files['scripts/' + name] = (b / name).read_bytes()
files['artifacts/validate-closed-tree.py'] = (b / 'artifacts/validate-closed-tree.py').read_bytes()
files['archive-manifest.json'] = json.dumps({n: hashlib.sha256(d).hexdigest() for n, d in sorted(files.items())}, indent=2).encode()
with tarfile.open(dest / 'raw-evidence.tar.gz', 'w:gz') as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name); info.size, info.mtime = len(data), 0
        tar.addfile(info, io.BytesIO(data))
(dest / 'archive.sha256').write_text(hashlib.sha256((dest / 'raw-evidence.tar.gz').read_bytes()).hexdigest() + '  raw-evidence.tar.gz\n')
print(json.dumps({'retained': retain, 'metrics': target['metrics']}, indent=2))
