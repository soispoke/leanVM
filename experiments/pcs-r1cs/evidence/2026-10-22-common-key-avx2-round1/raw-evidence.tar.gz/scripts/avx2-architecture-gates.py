from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
for label,flags in [
 ('avx2-cfg-avx2-only','-C target-cpu=x86-64 -C target-feature=+avx2,+pclmulqdq,-gfni,-avx512f,-avx512bw'),
 ('avx2-cfg-scalar','-C target-cpu=x86-64 -C target-feature=+pclmulqdq,-gfni,-avx2,-avx512f,-avx512bw')]:
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,'env','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS='+flags,'cargo','check','--locked','--release','-p','flock','--lib','--target','x86_64-unknown-linux-gnu'],check=True)
 print('passed',label,flush=True)
