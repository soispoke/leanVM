from pathlib import Path
import importlib.util,json,subprocess
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=[]
for trial in range(1,4):
 pair={}
 for which in (('control-v5','avx2') if trial%2 else ('avx2','control-v5')):
  label=f'avx2-screen-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  subprocess.run(['python3',str(b/'run-avx2-variant.py'),which,label,'--depth','1','--chain','16'],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
 for key in ('key','shape','proof_geometry'):assert pair['control-v5'][key]==pair['avx2'][key],key
 rows.append(pair);(b/'artifacts/avx2-screen.json').write_text(json.dumps(rows,indent=2))
 print('avx2',trial,{k:pair[k]['total_s'] for k in pair},flush=True)
