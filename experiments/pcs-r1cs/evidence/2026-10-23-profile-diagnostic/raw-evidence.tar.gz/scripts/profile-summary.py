from pathlib import Path
import hashlib,importlib.util,json,re
b=Path(__file__).resolve().parent
p=b/'profile-counts-trace/run-00/stdout.log'
r=json.loads((p.parent.parent/'result.json').read_text());assert r['ok'] and r['files_unchanged']
assert r['file_sha256_before'][r['command'][0]]==hashlib.sha256(Path(r['command'][0]).read_bytes()).hexdigest()
assert hashlib.sha256(p.read_bytes()).hexdigest()==r['runs'][0]['stdout_sha256']
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
v.check(p)
names=['Private prove','Compile witness','Arithmetic witness','Hash witness','Joint commitment','Arithmetic reduction','Native zerocheck','Native gate evaluations','Native copy leaves','Native copy product','Native copy evaluations','Hash reduction','Zerocheck','Round 1','Bit rounds','Table rounds','Lincheck','Joint opening','Index opening']
pat=re.compile(r'(?P<name>'+ '|'.join(names) +r') \[\s*(?P<t>[0-9.]+)(?P<u>µs|ms|s)')
rows=[];current={};counts={}
for line in p.read_text().splitlines():
 line=re.sub(r'\x1b\[[0-9;]*m','',line)
 m=pat.search(line)
 if m:
  current[m['name']]=float(m['t'])*{'s':1000,'ms':1,'µs':.001}[m['u']]
  for name,value in re.findall(r'(native_rows|actual_gates|actual_blocks|padded_slots): (\d+)',line):counts[name]=int(value)
 if line.startswith('{'):
  e=json.loads(line)
  if e.get('kind')=='proof':
   rows.append({'level':e['level'],'index':e['index'],'creation_s':e['creation_s'],'counts':counts,'stage_ms':current});current={};counts={}
assert len(rows)==3
out={'scope':'single diagnostic process; first proof is colder than remaining proofs; no paired performance claim','rows':rows,'root':rows[-1]}
(b/'artifacts/profile-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['root'],indent=2))
