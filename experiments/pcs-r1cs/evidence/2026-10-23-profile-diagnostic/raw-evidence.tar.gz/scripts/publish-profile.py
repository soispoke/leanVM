from pathlib import Path
import hashlib,importlib.util,io,json,tarfile
import identity_audit as a
b=Path(__file__).resolve().parent
p=b/'candidate/experiments/pcs-r1cs/evidence/2026-10-23-profile-diagnostic'
r=json.loads((b/'profile-counts-trace/result.json').read_text());v=a.v.check(b/'profile-counts-trace/run-00/stdout.log')
for k in ('key','shape','proof_geometry'):assert v[k]==a.base[2][k],k
assert r['file_sha256_before'][r['command'][0]]==hashlib.sha256(Path(r['command'][0]).read_bytes()).hexdigest()
report={'ok':True,'all_sizes_shapes_keys_unchanged':True,'processes':1,'certificates':3,'profile':json.loads((b/'artifacts/profile-summary.json').read_text()),'binary_sha256':hashlib.sha256(Path(r['command'][0]).read_bytes()).hexdigest(),'scope':'single diagnostic; not a paired timing comparison; source restored'}
(p/'results.json').write_text(json.dumps(report,indent=2)+'\n')
(p/'commands.json').write_text(json.dumps({'build':['python3','run-command.py','candidate','profile-counts-build','cargo','build','--locked','--release','-p','rec_aggregation','--example','closed_tree'],'trace_env':{'BENCH_TRACING':'1','RUST_LOG':'info'},'trace':['python3','run-padding-variant.py','profile-counts','profile-counts-trace','--depth','1','--chain','16']},indent=2)+'\n')
files={n:(p/n).read_bytes() for n in ('README.md','results.json','commands.json','diagnostic.patch','summary.json','verify-archive.py')}
for label in ('profile-counts-build','profile-counts-run','profile-counts-trace'):
 for f in (b/label).rglob('*'):
  if f.is_file():files[str(f.relative_to(b))]=f.read_bytes()
for name in ('profile-exclusions.json','profile-plan.json','profile-binary.json'):
 files['artifacts/'+name]=(b/'artifacts'/name).read_bytes()
for name in ('profile-summary.py','run-command.py','run-padding-variant.py','publish-profile.py'):
 files['scripts/'+name]=(b/name).read_bytes()
files['artifacts/validate-closed-tree.py']=(b/'artifacts/validate-closed-tree.py').read_bytes()
files['archive-manifest.json']=json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())},indent=2).encode()
with tarfile.open(p/'raw-evidence.tar.gz','w:gz') as t:
 for n,d in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(d);i.mtime=0;t.addfile(i,io.BytesIO(d))
(p/'archive.sha256').write_text(hashlib.sha256((p/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print('Profile sealed; certificates',report['certificates'])
