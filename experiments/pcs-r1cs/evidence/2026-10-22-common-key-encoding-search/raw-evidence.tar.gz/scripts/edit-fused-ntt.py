from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'candidate/crates/pcs/src/ntt/additive_ntt_f64.rs';s=p.read_text()
needle='impl AdditiveNttF64 {'
reader='''#[derive(Clone, Copy)]
struct EncodeMessage {
    ptr: parallel::SendPtr<F64>,
    lane_rows: Option<usize>,
}

impl EncodeMessage {
    fn copy_rows(self, dst: &mut [F64], first_row: usize, lanes: usize) {
        if let Some(rows) = self.lane_rows {
            assert_eq!(dst.len() % lanes, 0);
            assert!(first_row + dst.len() / lanes <= rows);
            for lane in 0..lanes {
                // SAFETY: the caller validated one complete immutable message,
                // and this contiguous lane lies inside that message.
                let src = unsafe { std::slice::from_raw_parts(self.ptr.add((lanes - 1 - lane) * rows), rows) };
                for (i, row) in dst.chunks_exact_mut(lanes).enumerate() {
                    row[lane] = src[first_row + i];
                }
            }
        } else {
            // SAFETY: transform's sub-block bounds stay within one replica.
            dst.copy_from_slice(unsafe { std::slice::from_raw_parts(self.ptr.add(first_row * lanes), dst.len()) });
        }
    }
}

'''
assert needle in s;s=s.replace(needle,reader+needle,1)
s=s.replace('let msg = parallel::SendPtr(data.as_mut_ptr());','let msg = EncodeMessage { ptr: parallel::SendPtr(data.as_mut_ptr()), lane_rows: None };')
s=s.replace('let msg = parallel::SendPtr(msg.as_ptr().cast_mut());','let msg = EncodeMessage { ptr: parallel::SendPtr(msg.as_ptr().cast_mut()), lane_rows: None };')
needle='    /// Run layers `start..d` of a `2^d`-row transform in as few sweeps of the buffer as possible.'
method='''    /// Encode reversed lane-major input without materializing its row-major transpose.
    /// The message is immutable and separate from the output; finished rows follow
    /// the same callback contract as the row-major encoder.
    pub fn encode_lane_major_with(
        &self,
        data: &mut [F64],
        msg: &[F64],
        lanes: usize,
        log_inv_rate: usize,
        on_rows: &RowSink<'_>,
    ) {
        assert!(lanes > 0 && lanes <= 4096);
        assert_eq!(msg.len() % lanes, 0);
        let rows = msg.len() / lanes;
        assert!(rows.is_power_of_two());
        assert_eq!(msg.len().checked_shl(log_inv_rate as u32), Some(data.len()));
        let msg = EncodeMessage { ptr: parallel::SendPtr(msg.as_ptr().cast_mut()), lane_rows: Some(rows) };
        self.transform(data, lanes, log_inv_rate, Some(msg), Some(on_rows));
    }

'''
assert needle in s;s=s.replace(needle,method+needle,1)
s=s.replace('msg: Option<parallel::SendPtr<F64>>,','msg: Option<EncodeMessage>,')
s=s.replace('std::ptr::eq(m.0, data.as_mut_ptr())','std::ptr::eq(m.ptr.0, data.as_mut_ptr())')
s=s.replace('replicate(data, m, data.len() >> start);','replicate(data, m, data.len() >> start, num_ntts);')
old='scratch.copy_from_slice(unsafe { std::slice::from_raw_parts(m.add(off), sub_len) });'
assert old in s;s=s.replace(old,'m.copy_rows(scratch, off / num_ntts, num_ntts);')
# A lane-major first gathered pass reads directly from the original columns.
old='''                    for (i, dst) in scratch.chunks_exact_mut(num_ntts).enumerate() {'''
new='''                    if let Some(EncodeMessage { ptr, lane_rows: Some(lane_rows) }) = msg {
                        for lane in 0..num_ntts {
                            // SAFETY: lane_rows and num_ntts describe the entire immutable message.
                            let src = unsafe { std::slice::from_raw_parts(ptr.add((num_ntts - 1 - lane) * lane_rows), lane_rows) };
                            for i in 0..rows {
                                scratch[i * num_ntts + lane] = src[r + (i << log_step)];
                            }
                        }
                    } else {
                    for (i, dst) in scratch.chunks_exact_mut(num_ntts).enumerate() {'''
assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace('Some(m) => std::slice::from_raw_parts(m.add(row(i)), num_ntts),','Some(m) => std::slice::from_raw_parts(m.ptr.add(row(i)), num_ntts),')
needle='''                    // Transform: a (layer + g)-layer domain whose sub-block index is the global block.'''
assert needle in s;s=s.replace(needle,'                    }\n'+needle,1)
old='fn replicate(data: &mut [F64], msg: parallel::SendPtr<F64>, msg_len: usize) {'
new='''fn replicate(data: &mut [F64], msg: EncodeMessage, msg_len: usize, lanes: usize) {
    if let Some(rows) = msg.lane_rows {
        let chunk_rows = rows.min(128);
        parallel::chunks_mut(data, lanes * chunk_rows, |i, dst| {
            msg.copy_rows(dst, (i * chunk_rows) % rows, lanes);
        });
        return;
    }
    let msg = msg.ptr;'''
assert old in s;s=s.replace(old,new,1)
p.write_text(s)
p=b/'candidate/crates/pcs/src/whir.rs';s=p.read_text()
old='''        crate::ntt::transpose_lane_major(&mut codeword[..message.len()], message, n_lanes, log_rows);
        let ntt = AdditiveNttF64::standard(k_code);
        ntt.encode_interleaved_in_place_with(&mut codeword, n_lanes, log_inv_rate, &|row, rows| {'''
new='''        let ntt = AdditiveNttF64::standard(k_code);
        ntt.encode_lane_major_with(&mut codeword, message, n_lanes, log_inv_rate, &|row, rows| {'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''    // `transpose_lane_major` covers every word of the message region (its tiles are
    // asserted to), and `encode_interleaved_in_place` writes every other replica from
    // it before transforming that region in place.''','''    // The lane-major encoder initializes every output row from the immutable
    // message before any transform reads it.''')
p.write_text(s)
