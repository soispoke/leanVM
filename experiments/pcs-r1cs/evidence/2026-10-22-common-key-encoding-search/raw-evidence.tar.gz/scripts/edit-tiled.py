from pathlib import Path
b=Path(__file__).resolve().parent
for f in ('run-command.py','run-variant.py','run-fused-variant.py'):
 p=b/f;p.write_text(p.read_text().replace('yukon-latest-bec1483','yukon-latest-ab2cc2e'))
p=b/'candidate/crates/pcs/src/ntt/additive_ntt_f64.rs'
s=p.read_text()
old='''        let mut msg = msg;
        let mut layer = start;
        while layer < deep_start {'''
new='''        let mut msg = msg;
        let mut layer = start;
        if let Some(m @ EncodeMessage { lane_rows: Some(rows), .. }) = msg {
            const TILE_LOG: usize = 5;
            let remaining = deep_start - start;
            let tiled_g = fit2.saturating_sub(TILE_LOG).min(remaining);
            let same_passes = tiled_g > 0
                && remaining.div_ceil(fit2.max(1)) == 1 + (remaining - tiled_g).div_ceil(fit2.max(1));
            if same_passes {
                self.gathered_lane_tiles(data, log_d, num_ntts, start, tiled_g, TILE_LOG, m, stream);
                layer += tiled_g;
                msg = None;
            } else {
                // A separate transpose preserves the original sweep count for smaller transforms.
                let len = rows * num_ntts;
                // SAFETY: the lane-major message is immutable, complete and disjoint from data.
                let source = unsafe { std::slice::from_raw_parts(m.ptr.0, len) };
                super::transpose_lane_major(&mut data[..len], source, num_ntts, rows.ilog2() as usize);
                msg = Some(EncodeMessage { ptr: parallel::SendPtr(data.as_mut_ptr()), lane_rows: None });
            }
        }
        while layer < deep_start {'''
assert old in s;s=s.replace(old,new)
marker='''    /// Run a range of layers in place over one sub-block of the domain.'''
method='''    #[allow(clippy::too_many_arguments)]
    fn gathered_lane_tiles(
        &self,
        data: &mut [F64],
        log_d: usize,
        lanes: usize,
        layer: usize,
        g: usize,
        tile_log: usize,
        msg: EncodeMessage,
        stream: bool,
    ) {
        let lane_rows = msg.lane_rows.expect("lane-major input");
        let log_step = log_d - layer - g;
        let tile_log = tile_log.min(log_step);
        let tile = 1usize << tile_log;
        let rows = 1usize << g;
        let group_len = rows * lanes;
        let base = parallel::SendPtr(data.as_mut_ptr());
        parallel::for_each_chunk(1usize << (log_step - tile_log), |lo, hi| {
            with_scratch(tile * group_len, |scratch| {
                let stream = stream.then(Stream::new);
                for task in lo..hi {
                    let first = task * tile;
                    for block in (0..1usize << layer).rev() {
                        for lane in 0..lanes {
                            // SAFETY: the external message contains exactly lanes complete columns.
                            let source = unsafe {
                                std::slice::from_raw_parts(msg.ptr.add((lanes - 1 - lane) * lane_rows), lane_rows)
                            };
                            for i in 0..rows {
                                let source = &source[first + (i << log_step)..][..tile];
                                for (r, &value) in source.iter().enumerate() {
                                    scratch[r * group_len + i * lanes + lane] = value;
                                }
                            }
                        }
                        for group in scratch.chunks_exact_mut(group_len) {
                            self.run_layers(group, layer + g, lanes, layer, layer + g, layer, block);
                        }
                        let block_row = block << (log_d - layer);
                        for i in 0..rows {
                            for r in 0..tile {
                                let row = block_row + first + r + (i << log_step);
                                let source = &scratch[r * group_len + i * lanes..][..lanes];
                                // SAFETY: each task owns disjoint residues in every output block.
                                let dest = unsafe { base.slice(row * lanes, lanes) };
                                match &stream {
                                    Some(s) => s.copy(dest, source),
                                    None => dest.copy_from_slice(source),
                                }
                            }
                        }
                    }
                }
            });
        });
    }

'''
assert marker in s;s=s.replace(marker,method+marker)
p.write_text(s)
