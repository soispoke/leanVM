from pathlib import Path
import datetime,hashlib,importlib.util,io,json,statistics,subprocess,tarfile
b=Path(__file__).resolve().parent
repo=b/'candidate'; dest=repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-closure'
s=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
exclusions=json.loads((b/'artifacts/exclusions.json').read_text())
rows=[];summary=[]
for n in (2,4,8):
 trial=[]
 for i in range(1,4):
  label=f'closure-baseline-{n}-{i:02d}'+('-retry' if i==3 and n in (4,8) else '')
  trial.append(v.check(b/label/'run-00/stdout.log'))
 for r in trial:
  for key in ('shape','key','proof_geometry'):assert r[key]==trial[0][key]
 rows+=trial
 summary.append({'leaves':n,'chain':16,'trials':3,**{k:statistics.median(r[k] for r in trial) for k in ('total_s','setup_s','creation_s','verification_s','root_creation_s','root_verification_s','root_certificate_bytes','peak_rss_bytes')},'proof_geometry':trial[0]['proof_geometry'],'shape':trial[0]['shape'],'key':trial[0]['key']})
workers=[]
for c,prefix in [('64','closure-workers'),('16','closure-worker16')]:
 pairs=[]
 for i in range(1,4):
  pair={w:v.check(b/f'{prefix}-{w}-{i:02d}/run-00/stdout.log') for w in ('32',c)}
  for key in ('shape','key','proof_geometry'):assert pair['32'][key]==pair[c][key]
  rows+=list(pair.values());pairs.append(pair)
 workers.append({'workers':int(c),'pairs':3,'decision':'reject','metrics':{m:{'control':statistics.median(r['32'][m] for r in pairs),'candidate':statistics.median(r[c][m] for r in pairs),'paired_pct':100*statistics.median(1-r[c][m]/r['32'][m] for r in pairs),'wins':sum(r[c][m]<r['32'][m] for r in pairs)} for m in ('total_s','root_creation_s','creation_s')},'rows':pairs})
for label in ('closure-depth1-chain4','closure-trace-serial-2-chain16'):rows.append(v.check(b/label/'run-00/stdout.log'))
# All admitted benchmark intervals must be serial. Failed and contended receipts remain excluded.
intervals=[]
for row in rows:
 d=json.loads((Path(row['path']).parent.parent/'result.json').read_text()); start=datetime.datetime.fromisoformat(d['started_utc']);end=start+datetime.timedelta(seconds=d['median_wall_seconds'])
 intervals.append((start,end,row['path']))
intervals.sort()
for a,z in zip(intervals,intervals[1:]):assert a[1]<=z[0],(a[2],z[2])
gates={}
for label in ('closure-all-native-tests','closure-final-clippy','closure-final-fmt','closure-doc2','closure-build','closure-validator-tests'):
 d=json.loads((b/label/'result.json').read_text());assert d['ok'] and d['files_unchanged'];gates[label]={'ok':True,'seconds':d['median_wall_seconds']}
# The only post-measurement Rust edit is a rustdoc markup correction.
measured=(b/'artifacts/private_bridge-measured.rs').read_bytes();current=(repo/'crates/format_recursion/src/private_bridge.rs').read_bytes()
assert current==measured.replace(b'/// The order is CV[4], output[4], message[8], counter, flags.',b'/// The order is `CV[4]`, `output[4]`, `message[8]`, counter, flags.')
first=json.loads((b/'closure-baseline-2-01/result.json').read_text())
for name,digest in first['file_sha256_before'].items():
 p=Path(name)
 if p.is_relative_to(repo):
  data=measured if name.endswith('/private_bridge.rs') else p.read_bytes()
  assert hashlib.sha256(data).hexdigest()==digest,name
report={'ok':True,'scope':'local implementation and timing evidence, not formal soundness or official certification','baseline':summary,'worker_screens':workers,'gates':gates,'admitted_tree_processes':len(rows),'admitted_tree_certificates':sum(r['proofs'] for r in rows),'excluded':exclusions,'baseline_all_sizes_and_shapes_unchanged':True,'source_note':'After measurement, private_bridge rustdoc array notation was marked as code to fix -D warnings; all other measured Rust/Cargo source bytes match the published source.','tooling_revision':first['tooling_git']['revision'],'runner_sha256':first['harness_sha256']}
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n')
(dest/'validate-closed-tree.py').write_bytes((b/'artifacts/validate-closed-tree.py').read_bytes())
# Raw bytes include successful, failed, contended and interrupted jobs.
files={}
for directory in b.iterdir():
 if directory.is_dir() and (directory/'started.json').exists():
  for p in directory.rglob('*'):
   if p.is_file():files[str(p.relative_to(b))]=p.read_bytes()
for p in (b/'artifacts').iterdir():
 if p.is_file() and p.suffix!='.pyc':files['artifacts/'+p.name]=p.read_bytes()
for p in b.glob('*.py'):files['scripts/'+p.name]=p.read_bytes()
files['results.json']=(dest/'results.json').read_bytes()
# Record the full implementation delta, including new source modules.
subprocess.run(['git','add','--','crates/format_recursion','crates/rec_aggregation/examples/closed_tree.rs','crates/rec_aggregation/examples/closure_probe.rs'],cwd=repo,check=True)
files['source.patch']=subprocess.check_output(['git','diff','--cached','--binary'],cwd=repo)
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['archive-manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with tarfile.open(dest/'raw-evidence.tar.gz','w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(dest/'archive.sha256').write_text(hashlib.sha256((dest/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True,'processes':len(rows),'certificates':report['admitted_tree_certificates'],'archive_files':len(manifest),'archive_bytes':(dest/'raw-evidence.tar.gz').stat().st_size}))
