from pathlib import Path
import datetime,hashlib,importlib.util,io,json,tarfile
import encoding_audit as audit
b=Path(__file__).resolve().parent
repo=b/'candidate';dest=repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-encoding-search'
dest.mkdir(exist_ok=True)
screens=[audit.series('tiled-screen','tiled',3),audit.series('pair-screen','pair',3)]
target=audit.series('pair-target','pair',7)
qualified=[m for m in ('total_s','creation_s') if target['metrics'][m]['paired_reduction_pct']>=3 and target['metrics'][m]['wins']>=6 and target['metrics'][m]['bootstrap95_pct'][0]>0]
companion_ok=all(target['metrics'][m]['paired_reduction_pct']>=-1 for m in ('total_s','creation_s'))
retain=bool(qualified) and companion_ok
rows=[row for series in screens+[target] for pair in series['rows'] for row in pair.values()]
intervals=[]
control_build=json.loads((b/'closure-baseline-rebuild/result.json').read_text())
pair_build=json.loads((b/'pair-guard-build/result.json').read_text())
def source_map(receipt):
 root=Path(receipt['cwd'])
 return {str(Path(p).relative_to(root)):h for p,h in receipt['file_sha256_before'].items() if Path(p).is_relative_to(root) and p.endswith(('.rs','.toml','Cargo.lock'))}
# Bind every admitted run to its exact benchmark executable and the expected source.
for row in rows:
 receipt=json.loads((Path(row['path']).parent.parent/'result.json').read_text())
 start=datetime.datetime.fromisoformat(receipt['started_utc']);end=start+datetime.timedelta(seconds=receipt['median_wall_seconds']);intervals.append((start,end,row['path']))
 binary=receipt['command'][0]
 assert binary in receipt['file_sha256_before']
 if 'pair-target-' in row['path'] and '/pair-target-pair-' in row['path']:
  assert source_map(receipt)==source_map(pair_build),'target source/build mismatch'
  assert receipt['file_sha256_before'][binary]==hashlib.sha256((b/'artifacts/bin/pair').read_bytes()).hexdigest()
 if '/control-' in row['path'] or '-control-' in row['path']:
  assert source_map(receipt)==source_map(control_build),'control source/build mismatch'
intervals.sort()
for a,z in zip(intervals,intervals[1:]):assert a[1]<=z[0],(a[2],z[2])
gates={}
for label in ('pair-final-pcs','pair-final-native','pair-final-clippy','pair-final-fmt','pair-final-doc','pair-final-x86-avx512','pair-final-x86-vpclmul-avx2','pair-final-x86-vpclmul-only'):
 r=json.loads((b/label/'result.json').read_text());assert r['ok'] and r['files_unchanged'],label;gates[label]={'ok':True,'receipt_sha256':hashlib.sha256((b/label/'result.json').read_bytes()).hexdigest()}
report={'validation':gates,'ok':True,'scope':'Local development performance evidence, not a formal soundness proof or official benchmark result.','screens':screens,'target':target,'retain_pair':retain,'qualifying_metrics':qualified,'companion_ok':companion_ok,'all_sizes_shapes_keys_unchanged':True,'processes':len(rows),'certificates':sum(r['proofs'] for r in rows),'excluded':['fused-screen-control','fused-screen-fused'],'exclusion_reason':'Initial naive fusion smoke used the candidate cwd/source binding for both variants; executable hashes identify the true binaries but this pair is excluded from timing claims.','latest_yukon':'ab2cc2ec9b55c35d6d5b6858170512d232b0d3c6','runner_sha256':'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e','rule':'At least3% paired median improvement in total or all creation, at least6/7 target wins and positive paired bootstrap95% interval, no companion regression over1%, exact key/shape/per-position certificate geometry.'}
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Common-key encoder research','',('Retained the PCLMUL pair kernel after repeated whole-tree measurements.' if retain else 'No encoder optimization met the predeclared retention rule. The published prover implementation remains unchanged.'),'','The experiment keeps the common circuit, setup key, transcript, security parameters, statements and every per-position certificate byte length, scalar count and Merkle phase count unchanged. These are chain16 local fixtures, not shielded-transfer workloads or matched leanVM/Flock comparisons.','','## Screens','','Three alternating fresh-process pairs, two leaves and three certificates per process. Positive reductions mean faster. Medians of paired ratios differ from ratios of the displayed medians.','','| Candidate | Total control / candidate (s) | Paired total reduction | All creation reduction | Root creation reduction |','| --- | ---: | ---: | ---: | ---: |']
for name,series in zip(('Tiled transpose/NTT fusion','PCLMUL pair kernel'),screens):
 m=series['metrics'];t=m['total_s'];lines.append(f"| {name} | {t['control_median']:.3f} / {t['candidate_median']:.3f} | {t['paired_reduction_pct']:+.2f}% ({t['wins']}/3) | {m['creation_s']['paired_reduction_pct']:+.2f}% | {m['root_creation_s']['paired_reduction_pct']:+.2f}% |")
lines+=['','Naive fusion replaced the row-major transpose with strided column reads. A preliminary smoke was slower, but is excluded because its original wrapper bound the control run to the candidate source directory. The original wrapper, executable hashes and logs are preserved. Tiled fusion reads adjacent source residues together, uses cache-bounded scratch and falls back to the original transpose when tiling would add a gathered sweep. Direct full-codeword and callback exact-coverage tests cover replication, fallback and tiled plans, odd/non-power-of-two lane counts and repeated gathered passes. All 44 active PCS tests passed (one existing ignored test). Its small end-to-end gain was insufficient for confirmation.','','The pair kernel targets x86 with PCLMULQDQ but without the AVX2 VPCLMUL path. It issues two carry-less products, packs their high/low halves and reduces both field elements together with SIMD shifts/XORs. The existing vector kernels and scalar field arithmetic are unchanged. Five encoder reference tests and all 76 native tests passed. A later compile-time guard broadening covers VPCLMUL without AVX2; targeted encoder tests and the rebuilt executable passed after that change. Screen source and the formatted target source have separate preserved patches.','','## Independent eight-leaf confirmation','','Seven new alternating pairs, 15 locally verified certificates per process. Each process includes common setup, every proof creation, explicit verification, serialization/reporting and wrong-root/height rejection checks. Creation includes recording, child prechecks, witness preparation and proving. No timed jobs overlap.','','| Measure | Control median (s) | Candidate median (s) | Paired reduction | Wins | Bootstrap 95% interval |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,key in (('Whole process','total_s'),('All creation','creation_s'),('Root creation','root_creation_s'),('Setup','setup_s')):
 m=target['metrics'][key];lo,hi=m['bootstrap95_pct'];lines.append(f"| {name} | {m['control_median']:.3f} | {m['candidate_median']:.3f} | {m['paired_reduction_pct']:+.2f}% | {m['wins']}/7 | [{lo:+.2f}, {hi:+.2f}]% |")
lines+=['',f"Decision: {'retain' if retain else 'reject'}. Retention requires at least 3% paired median reduction in total or all creation, at least 6/7 target wins, a positive paired bootstrap 95% interval and no companion regression over 1%. Root-only gains do not qualify. All keys, shapes and corresponding proof lengths match the published common-key baseline. The independent validator recomputes each leaf/node statement.",'','Final target-source release gates pass: 76 native tests, 43 active PCS tests (one existing ignored), Clippy with tests/examples and warnings denied, formatting, strict rustdoc, and x86 checks covering AVX-512 VPCLMUL, AVX2 VPCLMUL and VPCLMUL without AVX2. Cross-feature checks type-check the arms; only the native host configuration was executed.', '', '## Provenance and reproduction','','Yukon is pinned at ab2cc2ec9b55c35d6d5b6858170512d232b0d3c6 for tiled and pair experiments; earlier naive checks use bec1483300f5d052a31db3a5be75e1496742c7d0. The runner SHA256 stayed ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e. Rust 1.99.1, native CPU flags plus pclmulqdq, 32 workers, CPUs 0-63, four Cargo build jobs. Build/test budget 96 GiB, benchmark budget 16 GiB and host reserve 40 GiB. The shared Xeon Gold 6230R host is not a dedicated benchmark host. RSS is sampled process-group memory, not cgroup isolation. Source/binary/runner hashes and exact commands remain in receipts. The formatting mutation receipt is intentionally false because source hashes changed during cargo fmt, not because a semantic test failed.','','Build through current Yukon with cargo build --locked --release -p rec_aggregation --example closed_tree, then run the frozen control/candidate executables at --depth 1 --chain 16 and --depth 3 --chain 16 in the archived alternating order. Use fresh output directories. The wrappers bind sources and executable hashes. The target differs from the screen only in formatting and compile-time guards inactive on this host. Exact original source patches are preserved.','','The archive excludes compiler caches and executable binaries. Run python3 verify-archive.py for member/digest verification. results.json contains every admitted row; raw-evidence.tar.gz includes logs, receipts, rejected patches, scripts, the predeclared plan and excluded smoke. The broader persistent performance goal remains active; implementation tests do not settle the formal composition proof or official recursion.fast integration.','']
(dest/'README.md').write_text('\n'.join(lines))
(dest/'verify-archive.py').write_bytes((repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-memory-search/verify-archive.py').read_bytes())
files={name:(dest/name).read_bytes() for name in ('results.json','README.md','verify-archive.py')}
for pattern in ('fused-*','tiled-*','pair-*','closure-baseline-rebuild'):
 for root in b.glob(pattern):
  if root.is_dir():
   for p in root.rglob('*'):
    if p.is_file():files[str(p.relative_to(b))]=p.read_bytes()
for name in ('fused-naive.patch','tiled.patch','pclmul-pair.patch','pclmul-pair-final.patch','run-fused-smoke-original.py','EXPERIMENTS.md','validate-closed-tree.py'):
 files['artifacts/'+name]=(b/'artifacts'/name).read_bytes()
for p in b.glob('*.py'):files['scripts/'+p.name]=p.read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['archive-manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with tarfile.open(dest/'raw-evidence.tar.gz','w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(dest/'archive.sha256').write_text(hashlib.sha256((dest/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True,'retain_pair':retain,'target':target['metrics'],'processes':len(rows),'certificates':report['certificates'],'archive_files':len(manifest)}))
