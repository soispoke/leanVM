from pathlib import Path
import importlib.util,json
b=Path(__file__).resolve().parent
p=Path('/root/yukon-autoresearch/workspaces/yukon-latest-20261022/toolkit/tools/experiment_advisor.py')
s=importlib.util.spec_from_file_location('advisor',p);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
print(json.dumps(v.rank(json.loads((b/'artifacts/next-plan.json').read_text())),indent=2))
