from pathlib import Path
import subprocess
import json
base=Path(__file__).resolve().parent
for trial in range(1,4):
    for depth in (1,2,3):
        label=f'closure-baseline-{1<<depth}-{trial:02d}'
        if (base/label/'result.json').exists():
            d=json.loads((base/label/'result.json').read_text())
            assert d['ok'] and d['files_unchanged'], label
        else:
            assert not (base/label).exists(), f'incomplete run needs reconciliation: {label}'
            subprocess.run(['python3',str(base/'run-tree.py'),label,'--depth',str(depth),'--chain','16'],check=True)
        subprocess.run(['python3',str(base/'artifacts/validate-closed-tree.py'),str(base/label/'run-00/stdout.log')],stdout=(base/'artifacts'/f'{label}.json').open('w'),check=True)
    print(f'Finished baseline trial {trial}',flush=True)
print('baseline measurements complete',flush=True)
