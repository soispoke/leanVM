from pathlib import Path
import importlib.util,json,subprocess,statistics
b=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
screen=json.loads((b/'artifacts/first-touch-screen.json').read_text())
qualifies=any(statistics.median(1-r['candidate'][m]/r['control'][m] for r in screen)>=.03 and sum(r['candidate'][m]<r['control'][m] for r in screen)>=2 for m in ('total_s','creation_s'))
assert qualifies,'screen does not qualify'
rows=[]
for trial in range(1,8):
 pair={}
 for which in (('candidate','control') if trial%2 else ('control','candidate')):
  label=f'first-touch-confirm-{which}-{trial:02d}'
  assert not (b/label).exists(),label
  subprocess.run(['python3',str(b/'run-variant.py'),which,label,'--depth','3','--chain','16'],check=True)
  pair[which]=v.check(b/label/'run-00/stdout.log')
 for key in ('key','shape','proof_geometry'):assert pair['control'][key]==pair['candidate'][key],key
 rows.append(pair);(b/'artifacts/first-touch-confirm.json').write_text(json.dumps(rows,indent=2))
 print('pair',trial,{k:pair[k]['total_s'] for k in pair},flush=True)
