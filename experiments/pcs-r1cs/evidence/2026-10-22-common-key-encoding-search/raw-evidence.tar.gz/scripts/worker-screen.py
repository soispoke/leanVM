from pathlib import Path
import subprocess,os,json,importlib.util
base=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',base/'artifacts/validate-closed-tree.py'); v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
rows=[]
for trial in range(1,4):
    pair={}
    for workers in ((32,64) if trial%2 else (64,32)):
        label=f'closure-workers-{workers}-{trial:02d}'
        assert not (base/label).exists(),label
        subprocess.run(['python3',str(base/'run-tree.py'),label,'--depth','1','--chain','16'],env=dict(os.environ,CLOSURE_THREADS=str(workers)),check=True)
        pair[workers]=v.check(base/label/'run-00/stdout.log')
    for name in ('key','shape','proof_geometry'):
        assert pair[32][name]==pair[64][name],name
    rows.append({str(k):val for k,val in pair.items()})
    (base/'artifacts/worker-screen.json').write_text(json.dumps(rows,indent=2))
    print('pair',trial,{k:pair[k]['total_s'] for k in pair},flush=True)
