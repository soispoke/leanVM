from pathlib import Path
T=Path(__file__).resolve().parent/'candidate/crates/format_recursion/src'
p=T/'verifier.rs';s=p.read_text().replace('    compressed: Option<&\'a Proof>,','    compressed: Option<&\'a Proof>,\n    placeholder: bool,')
s=s.replace('            compressed: None,','            compressed: None,\n            placeholder: false,')
s=s.replace('            compressed: Some(proof),','            compressed: Some(proof),\n            placeholder: false,')
pos=s.index('    pub(crate) fn round(')
s=s[:pos]+'''    /// Generate dummy inputs for a branch whose verification equations the
    /// caller explicitly disables. This does not accept or verify a proof.
    pub(crate) fn placeholder(state: [S; 2]) -> Self {
        Self {
            proof: std::borrow::Cow::Owned(RawProof { stream: Vec::new(), merkle: Vec::new() }),
            compressed: None,
            placeholder: true,
            state,
            cursor: 0,
            phase: 0,
        }
    }

'''+s[pos:]
s=s.replace('''        let x = S::input(self.proof.stream[self.cursor]);''','''        let x = S::input(if self.placeholder { F192::ZERO } else { self.proof.stream[self.cursor] });''')
s=s.replace('''        let paths = if let Some(proof) = self.compressed {''','''        let paths = if self.placeholder {
            expanded = queries.iter().map(|query| fiat_shamir::merkle::RawMerklePath {
                leaf_index: query.value().c0 as usize,
                leaf_data: vec![primitives::field::F64::ZERO; if base { lanes } else { 3 * lanes }],
                path: vec![[0; 32]; depth],
            }).collect::<Vec<_>>();
            self.phase += queries.len();
            expanded.as_slice()
        } else if let Some(proof) = self.compressed {''')
s=s.replace('''    pub(crate) fn finish(&self) {
        assert_eq!''','''    pub(crate) fn finish(&self) {
        if self.placeholder { return; }
        assert_eq!''');p.write_text(s)
p=T/'trace.rs';s=p.read_text();pos=s.index('pub fn mark(')
s=s[:pos]+'''pub(crate) fn check_count() -> usize {
    TRACE.with(|t| t.borrow().checks.len())
}

/// Gate existing equations only; arithmetic and hash computation remain bound.
pub(crate) fn gate_checks_since(start: usize, enabled: S) {
    let checks = TRACE.with(|t| t.borrow_mut().checks.split_off(start));
    for (left, right) in checks {
        (enabled * (left + right)).assert_eq(S::u(0));
    }
}

'''+s[pos:];p.write_text(s)
p=T/'private_recursion.rs';s=p.read_text().replace('''        let mut prepared = private_trace::PreparedProgram::new(program)?;''','''        Self::new_with_context(program, primitives::hash::hash(b"format-private-recursion-v1"))
    }

    pub(crate) fn new_with_context(program: Trace, context: Hash) -> Option<Self> {
        let mut prepared = private_trace::PreparedProgram::new(program)?;''',1)
s=s.replace('''            context: primitives::hash::hash(b"format-private-recursion-v1"),''','''            context,''',1);p.write_text(s)
