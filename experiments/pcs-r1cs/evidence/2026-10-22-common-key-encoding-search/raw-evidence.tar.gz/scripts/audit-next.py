from pathlib import Path
import datetime,hashlib,importlib.util,io,json,random,statistics,tarfile
b=Path(__file__).resolve().parent
repo=b/'candidate';dest=repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-memory-search'
dest.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('v',b/'artifacts/validate-closed-tree.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
published=json.loads((repo/'experiments/pcs-r1cs/evidence/2026-10-22-common-key-closure/results.json').read_text())
baselines={r['leaves']:r for r in published['baseline']}
rng=random.Random(20261022)

def series(prefix,count):
 rows=[]
 for i in range(1,count+1):
  pair={which:v.check(b/f'{prefix}-{which}-{i:02d}/run-00/stdout.log') for which in ('control','candidate')}
  for key in ('key','shape','proof_geometry'):
   assert pair['control'][key]==pair['candidate'][key],(prefix,i,key)
   assert pair['control'][key]==baselines[pair['control']['leaves']][key],(prefix,i,key,'published')
  rows.append(pair)
 metrics={}
 for m in ('total_s','creation_s','root_creation_s','setup_s','verification_s','root_verification_s','cpu_s','peak_rss_bytes'):
  ratios=[100*(1-r['candidate'][m]/r['control'][m]) for r in rows]
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(20000))
  metrics[m]={'control_median':statistics.median(r['control'][m] for r in rows),'candidate_median':statistics.median(r['candidate'][m] for r in rows),'paired_reduction_pct':statistics.median(ratios),'wins':sum(x>0 for x in ratios),'bootstrap95_pct':[boot[499],boot[19499]],'paired_pct':ratios}
 return {'prefix':prefix,'pairs':count,'metrics':metrics,'rows':rows}

screens=[series(p,3) for p in ('allocation-screen','first-touch-screen','chunk-screen')]
target=series('chunk-target',7)
qualified=[]
for name in ('total_s','creation_s'):
 m=target['metrics'][name]
 if m['paired_reduction_pct']>=3 and m['wins']>=6 and m['bootstrap95_pct'][0]>0:qualified.append(name)
# A companion metric regression over 1% is material for retention.
companion_ok=all(target['metrics'][name]['paired_reduction_pct']>=-1 for name in ('total_s','creation_s'))
retain=bool(qualified) and companion_ok
all_rows=[r for series_ in screens+[target] for pair in series_['rows'] for r in pair.values()]
intervals=[]
for row in all_rows:
 d=json.loads((Path(row['path']).parent.parent/'result.json').read_text());start=datetime.datetime.fromisoformat(d['started_utc']);end=start+datetime.timedelta(seconds=d['median_wall_seconds']);intervals.append((start,end,row['path']))
intervals.sort()
for a,z in zip(intervals,intervals[1:]):assert a[1]<=z[0],(a[2],z[2])
report={'ok':True,'scope':'local development evidence, not formal soundness or official certification','screens':screens,'target':target,'retain_chunk':retain,'qualifying_metrics':qualified,'companion_ok':companion_ok,'rule':'At least3% paired median improvement in whole process or all creation, at least6/7wins and positive paired bootstrap95% interval, no companion regression over1%; proof geometry and key match published baseline.','all_sizes_shapes_keys_unchanged':True,'processes':len(all_rows),'certificates':sum(r['proofs'] for r in all_rows),'latest_yukon':'34331e85f931c5bffa85a1200f11429a3e00a499','runner_sha256':'ccfa389f297eba6f0adcac80a41c15302ac6a749019f464f371e6be990970c9e'}
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n')
files={'results.json':(dest/'results.json').read_bytes(),'README.md':(dest/'README.md').read_bytes(),'verify-archive.py':(dest/'verify-archive.py').read_bytes()}
for prefix in ('allocation','first-touch','chunk','latest-advisor','closure-baseline-rebuild'):
 for p in b.glob(prefix+'*/**/*'):
  if p.is_file() and 'candidate' not in p.relative_to(b).parts and 'control' not in p.relative_to(b).parts:
   files[str(p.relative_to(b))]=p.read_bytes()
for name in ('allocation.patch','first-touch.patch','chunk.patch','EXPERIMENTS.md','CONTINUITY.md','allocation-decision.json','first-touch-decision.json','run-command-before-tool-update.py','run-variant-before-tool-update.py','validate-closed-tree.py'):
 files['artifacts/'+name]=(b/'artifacts'/name).read_bytes()
for p in b.glob('*.py'):files['scripts/'+p.name]=p.read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['archive-manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with tarfile.open(dest/'raw-evidence.tar.gz','w:gz') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
(dest/'archive.sha256').write_text(hashlib.sha256((dest/'raw-evidence.tar.gz').read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
print(json.dumps({'ok':True,'retain_chunk':retain,'target':target['metrics'],'archive_files':len(manifest),'processes':len(all_rows),'certificates':report['certificates']}))
