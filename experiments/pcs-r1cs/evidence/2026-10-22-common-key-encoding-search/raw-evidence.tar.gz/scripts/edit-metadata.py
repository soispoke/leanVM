from pathlib import Path
T=Path(__file__).resolve().parent/'candidate/crates/format_recursion/src'
p=T/'native_arithmetic.rs';s=p.read_text();at=s.index('pub struct Index {')
s=s[:at]+'''#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ArithmeticShape {
    pub log_rows: usize,
    pub public_log: usize,
    pub public_len: usize,
    pub index_log_inv_rate: usize,
}

'''+s[at:]
s=s.replace('    pub fn public_values(&self, values: &[F192]) -> Vec<F192> {','''    pub fn verifier_shape(&self) -> ArithmeticShape {
        ArithmeticShape {
            log_rows: self.log_rows,
            public_log: self.public_log,
            public_len: self.circuit.public.len(),
            index_log_inv_rate: self.index_log_inv_rate,
        }
    }
    pub fn public_values(&self, values: &[F192]) -> Vec<F192> {''');p.write_text(s)
p=T/'native_verifier.rs';s=p.read_text().replace('native_arithmetic::Index,','native_arithmetic::{ArithmeticShape, Index},')
needle='''    assert_eq!(public.len(), index.shape().2);
    assert!(public.len() >= 2);'''
s=s.replace(needle,'''    reduce_shape(index.verifier_shape(), public, t)
}

pub(crate) fn reduce_shape(index: ArithmeticShape, public: &[S], t: &mut Transcript<'_>) -> (Vec<Claim>, Vec<Claim>) {
    assert_eq!(public.len(), index.public_len);
    assert!(public.len() >= 2);''');p.write_text(s)
p=T/'private_bridge.rs';s=p.read_text().replace('self, Circuit, Index','self, ArithmeticShape, Circuit, Index')
at=s.index('/// Trusted preprocessing')
s=s[:at]+'''/// Fixed verifier metadata, without a commitment or prover allocation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PrivateShape {
    pub index: ArithmeticShape,
    pub n_blocks: usize,
    pub block_log: usize,
    pub connector_start: usize,
    pub q_offset: usize,
    pub stack_log: usize,
}

impl PrivateShape {
    pub fn for_circuit(rows: usize, public_len: usize, n_blocks: usize) -> Option<Self> {
        if n_blocks == 0 || n_blocks > MAX_BLOCKS || public_len < 2 {
            return None;
        }
        let full_public = public_len.checked_add(18)?;
        let public_rows = full_public.checked_next_power_of_two()?;
        let blocks = n_blocks.max(MIN_BLOCKS).checked_next_power_of_two()?;
        let block_log = blocks.trailing_zeros() as usize;
        let connector_start = public_rows.checked_add(rows)?.checked_next_multiple_of(blocks)?;
        let count = connector_start.checked_add(6 * blocks)?;
        let log_rows = (count.checked_next_power_of_two()?.trailing_zeros() as usize).max(13);
        if log_rows > native_arithmetic::MAX_LOG_ROWS {
            return None;
        }
        let q_log = K_LOG - LOG_PACKING + block_log;
        let (q_offset, stack_log) = joint_layout(log_rows, q_log);
        Some(Self {
            index: ArithmeticShape { log_rows, public_log: public_rows.trailing_zeros() as usize,
                public_len: full_public, index_log_inv_rate: INDEX_LOG_INV_RATE },
            n_blocks, block_log, connector_start, q_offset, stack_log,
        })
    }

    pub fn committed_lanes(&self) -> usize {
        let q_log = K_LOG - LOG_PACKING + self.block_log;
        let lane_words = 1usize << (self.stack_log - INITIAL_FOLDING_FACTOR);
        (self.q_offset + (1usize << q_log)).div_ceil(lane_words)
    }

    pub(crate) fn compact_native_offset(&self, offset: usize, low_log: usize) -> usize {
        let n = 1usize << self.index.log_rows;
        assert!(low_log <= self.index.log_rows, "native claim exceeds its column");
        let slot = offset / n;
        let within = offset % n;
        assert!(slot < 16 && slot % 4 < 3, "claim addresses an unused native limb slot");
        let width = 1usize << low_log;
        assert!(offset.is_multiple_of(width) && within + width <= n, "unaligned native claim");
        (3 * (slot / 4) + slot % 4) * n + within
    }

    pub(crate) fn connector_offset(&self, slot: usize, limb: usize) -> usize {
        assert!(slot < 18 && limb < 3, "invalid connector coordinate");
        let n = 1usize << self.index.log_rows;
        (3 * (slot / 6) + limb) * n + self.connector_start + ((slot % 6) << self.block_log)
    }
}

'''+s[at:]
s=s.replace('''    pub fn committed_lanes(&self) -> usize {
        let q_log = K_LOG - LOG_PACKING + self.block_log;
        let lane_words = 1usize << (self.stack_log - INITIAL_FOLDING_FACTOR);
        (self.q_offset + (1usize << q_log)).div_ceil(lane_words)
    }

    pub fn new''','''    pub fn verifier_shape(&self) -> PrivateShape {
        PrivateShape { index: self.index.verifier_shape(), n_blocks: self.n_blocks,
            block_log: self.block_log, connector_start: self.connector_start,
            q_offset: self.q_offset, stack_log: self.stack_log }
    }

    pub fn committed_lanes(&self) -> usize {
        self.verifier_shape().committed_lanes()
    }

    pub fn new''')
a=s.index('    pub(crate) fn compact_native_offset(',s.index('impl PrivateBridge'))
z=s.index('    pub(crate) fn public(',a)
s=s[:a]+'''    pub(crate) fn compact_native_offset(&self, offset: usize, low_log: usize) -> usize {
        self.verifier_shape().compact_native_offset(offset, low_log)
    }

    pub(crate) fn connector_offset(&self, slot: usize, limb: usize) -> usize {
        self.verifier_shape().connector_offset(slot, limb)
    }

'''+s[z:];p.write_text(s)
p=T/'private_verifier.rs';s=p.read_text().replace('JOINT_LOG_INV_RATE, PrivateBridge','JOINT_LOG_INV_RATE, PrivateBridge, PrivateShape')
s=s.replace('''    let mut label = literal(b"format-private-bridge-v5");''','''    label_shape(bridge.verifier_shape(), index_root, context, public)
}

pub(crate) fn label_shape(bridge: PrivateShape, index_root: [S; 2], context: [S; 2], public: &[S]) -> Vec<(S, usize)> {
    let mut label = literal(b"format-private-bridge-v5");''',1)
s=s.replace('''    let root = t.root();
    let (mut claims, index_claims) = native_verifier::reduce(&bridge.index, public, t);''','''    verify_shape(bridge.verifier_shape(), index_root, public, t);
}

pub(crate) fn verify_shape(bridge: PrivateShape, index_root: [S; 2], public: &[S], t: &mut Transcript<'_>) {
    let root = t.root();
    let (mut claims, index_claims) = native_verifier::reduce_shape(bridge.index, public, t);''',1);p.write_text(s)
