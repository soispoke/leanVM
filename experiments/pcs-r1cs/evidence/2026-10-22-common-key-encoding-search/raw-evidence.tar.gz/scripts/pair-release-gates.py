from pathlib import Path
import subprocess
b=Path(__file__).resolve().parent
checks=[
 ('pair-final-pcs',['cargo','test','--locked','--release','-p','pcs','--lib']),
 ('pair-final-native',['cargo','test','--locked','--release','-p','format_recursion','--lib']),
 ('pair-final-clippy',['cargo','clippy','--locked','--release','-p','pcs','-p','format_recursion','-p','rec_aggregation','--lib','--tests','--examples','--','-D','warnings']),
 ('pair-final-fmt',['cargo','fmt','--all','--','--check']),
 ('pair-final-doc',['cargo','doc','--locked','--release','-p','pcs','-p','format_recursion','--no-deps']),
 ('pair-final-x86-avx512',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+avx512f,+avx512bw,+avx512vl,+vpclmulqdq,+pclmulqdq,+gfni,+avx2,+aes','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
 ('pair-final-x86-vpclmul-avx2',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+pclmulqdq,+vpclmulqdq,+avx2','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
 ('pair-final-x86-vpclmul-only',['env','RUSTFLAGS=-C target-cpu=x86-64 -C target-feature=+pclmulqdq,+vpclmulqdq,-avx2,-avx512f','cargo','check','--locked','--release','-p','pcs','--target','x86_64-unknown-linux-gnu']),
]
for label,cmd in checks:
 assert not (b/label).exists(),label
 subprocess.run(['python3',str(b/'run-command.py'),'candidate',label,*cmd],check=True)
 print('gate passed',label,flush=True)
